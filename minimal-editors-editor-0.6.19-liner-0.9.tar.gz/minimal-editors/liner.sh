#!/bin/sh
# liner 0.9 - a small line editor for configuration files.
# Run: sh liner.sh [FILE]       Help: sh liner.sh --help
# Requires /bin/sh, awk, and ordinary Linux/OpenBSD base utilities.
# No compiler, curses, readline, Python, Bash, or another editor is used.
# A private temporary directory holds exact-byte undo snapshots.
# Writes are staged beside the destination. Symlinks and multiple hard
# links require saving to a new filename. No power-loss durability claim.

ln_version=0.9
ln_commands='show page change insert delete undo redo write help manual about quit quit!'
ln_help() { printf '%s\n' "$ln_commands"; }

ln_about() {
    printf 'liner %s\n' "$ln_version"
    cat <<'ABOUT'
A small line editor for configuration files.
design by remfan1994
published by ThatIAm.vip

BLOODGUILT CURSE
Cows aren't killers, and beef is the bloodshed of the innocent.  www.bloodguiltcurse.net has the Bible study

One file, typed commands, undo and redo.
Uses /bin/sh, awk, and ordinary base utilities; no curses or readline.
ABOUT
}

ln_manual() {
    printf 'liner %s - one file, typed commands, undo and redo\n' "$ln_version"
    cat <<'HELP'
Usage: sh liner.sh [--plain] [--] [FILE]
Options: --help, --manual, --about, --version, --check
--plain disables all terminal control sequences and special-key input.
--check probes required utilities in a private temporary directory.

show [FIRST [LAST]]  Show all lines, one line, or an inclusive range.
page [FIRST [LAST]]  Browse the same text in an optional scrolling pager.
change LINE         Edit replacement text for one existing line.
insert LINE         Edit text to insert before LINE.
                    Use the line count plus one to append.
delete FIRST [LAST]  Delete one line or an inclusive range.
undo                Undo one change.
redo                Redo one change.
write [FILE]        Save; FILE is literal text, including spaces.
help                Show the command names on one line.
manual              Show these full instructions.
about               Show the version, credits, and BLOODGUILT CURSE warning.
quit                Leave if saved.
quit!               Discard unsaved changes and leave.

At Text>, the draft starts empty. Arrows move; Home/End reach line ends.
Backspace/Delete erase bytes and can join draft lines.
Enter accepts the whole draft; Ctrl-J inserts a newline.
Esc, Ctrl-C, or Ctrl-D cancels the draft. An empty draft is valid text.
Bracketed pastes stay in the draft, including their line breaks.
Pasted CRLF and CR become draft newlines. A trailing newline creates
a final blank draft line. Each accepted draft is one undoable change.
Draft display and cursor editing are byte-oriented, like show.
With --plain, redirected input/output, unset TERM, TERM=dumb, or missing
optional terminal utilities, Text> reads one line and page behaves like show.
At the command prompt, a partial name plus Enter suggests matching names.
For example, ch suggests change; q suggests quit and quit!.
Suggestions do not run commands. Type the full command to use it.
In page: Up/Down scroll one row; Page Up/Page Down scroll one screen.
Enter or Space goes forward one screen; q returns to commands immediately.
Hold a scrolling key to repeat. The pager stays open at either end.
Progress counts wrapped display rows within the requested range.
The percentage shows how far the bottom of the visible text has reached.
Text that fits on one screen is printed without entering the pager.
show remains unpaused. Paging is skipped when input/output is redirected.
Do not add shell quotes around a filename in the write command.
Display escapes backslashes, tabs, control and non-ASCII bytes.
Text entered at Text> is literal: backslashes are not escape codes.

Unchanged text and its line endings are preserved.
Inserted lines use the first existing newline style (LF for new files).
Missing final newlines stay absent unless the final line becomes empty.
A blank final line needs a terminating newline to remain a line.
8 MiB file limit. NUL bytes in input files are refused.
Undo survives writes; up to 128 previous states and 64 MiB of numbered
snapshots are kept. Oldest undo states are pruned when either limit is reached.
An unexpected exit keeps accepted unsaved edits in a private directory.
CURRENT identifies the selected numbered snapshot even after a forced kill.
An unfinished Text> draft is not part of those recovery snapshots.
New files are private (mode 600); existing permissions are copied,
except set-user-ID and set-group-ID bits are removed on replacement.
Save-as does not overwrite an unrelated existing file.

Example session:
  show 1 10
  change 3
  setting = value
  undo
  redo
  write
  quit

Run sh liner.sh FILE again to edit a different file.
See docs/liner.txt or the liner(1) manual page for the full user manual.
HELP
    printf '\n'
    ln_about
}

ln_plain=no
ln_check=no
case ${1-} in
    -h|--help|--manual) ln_manual; exit 0 ;;
    --about) ln_about; exit 0 ;;
    --version) printf 'liner %s\n' "$ln_version"; exit 0 ;;
    --check) [ "$#" -eq 1 ] || exit 2; ln_check=yes; shift ;;
    --plain) ln_plain=yes; shift ;;
esac
[ "${1-}" != -- ] || shift
if [ "$#" -gt 1 ]; then
    printf '%s\n' 'Usage: sh liner.sh [--plain] [--] [FILE]' >&2; exit 2
fi

LC_ALL=C
export LC_ALL
IFS=' 	
'
set -f
umask 077
ln_work=
ln_stage=
ln_file=
ln_current=0
ln_last=0
ln_floor=0
ln_snapshot_bytes=0
ln_history_blocked=no
ln_ready=no
ln_discard=no
ln_existing=no
ln_saved_meta=
ln_tty=
ln_key_pid=
ln_page_pid=
ln_page_input=no
ln_alt=no
ln_bracketed=no
ln_text_screen=no
ln_newline='
'
ln_cr=$(printf '\r')

ln_say() { printf '%s\n' "$*"; }
ln_error() { printf 'liner: %s\n' "$*" >&2; }
ln_dirty() { ! cmp -s "$ln_work/$ln_current" "$ln_work/saved"; }

# Publish a small pointer before acknowledging a change, undo or redo.
# Numbered snapshots are immutable while selected. A kill between candidate
# creation and pointer publication leaves the previous accepted selection.
# This is an atomic name replacement, not a power-loss durability promise.
ln_select() {
    if (printf '%s\n' "$1" > "$ln_work/CURRENT.next") &&
        mv -f "$ln_work/CURRENT.next" "$ln_work/CURRENT"; then
        ln_current=$1
        return 0
    fi
    rm -f "$ln_work/CURRENT.next"
    ln_error 'Cannot update recovery pointer; previous selection retained.'
    return 1
}

# Keep the line-command interface available without terminal utilities.
ln_missing=no
for ln_tool in awk cat chmod cmp cp ln ls mktemp mv od rm tail tr wc; do
    if ! command -v "$ln_tool" >/dev/null 2>&1; then
        ln_error "Missing required utility: $ln_tool"; ln_missing=yes
    fi
done
[ "$ln_missing" = no ] || exit 1
case ${TERM-} in ''|dumb) ln_plain=yes ;; esac
for ln_tool in stty dd mkfifo; do
    if ! command -v "$ln_tool" >/dev/null 2>&1; then ln_plain=yes; fi
done
if [ ! -t 0 ] || [ ! -t 1 ]; then ln_plain=yes; fi


ln_suggest() {
    ln_matches=
    for ln_known in $ln_commands; do
        case $ln_known in
            "$ln_command"*) ln_matches=${ln_matches:+$ln_matches }$ln_known ;;
        esac
    done
    if [ -n "$ln_matches" ]; then ln_say "Suggestions: $ln_matches"
    else ln_error 'Unknown command. Type help.'
    fi
}

ln_page_restore() {
    # Stop children before restoring cooked input or leaving the display.
    if [ -n "$ln_key_pid" ]; then
        kill "$ln_key_pid" 2>/dev/null
        wait "$ln_key_pid" 2>/dev/null
        ln_key_pid=
    fi
    if [ -n "$ln_page_pid" ]; then
        kill "$ln_page_pid" 2>/dev/null
        wait "$ln_page_pid" 2>/dev/null
        ln_page_pid=
    fi
    if [ "$ln_page_input" = yes ]; then exec 4<&-; ln_page_input=no; fi
    if [ -n "$ln_tty" ]; then stty "$ln_tty" 2>/dev/null; ln_tty=; fi
    if [ "$ln_bracketed" = yes ]; then printf '\033[?2004l'; ln_bracketed=no; fi
    if [ "$ln_text_screen" = yes ]; then printf '\033[0m\033[?25h'; ln_text_screen=no; fi
    if [ "$ln_alt" = yes ]; then printf '\033[?1049l'; ln_alt=no; fi
}

ln_cleanup() {
    ln_status=$?
    trap - 0 HUP INT QUIT TERM PIPE
    ln_page_restore
    if [ -n "$ln_stage" ]; then rm -f "$ln_stage"; fi
    if [ -n "$ln_work" ] && [ -d "$ln_work" ]; then
        # A signal may arrive after publishing CURRENT but before updating
        # the shell variable. Use the committed pointer in cleanup too.
        if [ -f "$ln_work/CURRENT" ] && IFS= read -r ln_selected < "$ln_work/CURRENT"; then
            case $ln_selected in ''|*[!0-9]*) ;; *) ln_current=$ln_selected ;; esac
        fi
        if [ "$ln_ready" = yes ] && [ "$ln_discard" != yes ] && ln_dirty; then
            printf '\nUnsaved text kept at: %s/%s\n' "$ln_work" "$ln_current" >&2
            printf 'Undo snapshots are in the same private directory.\n' >&2
        else
            rm -rf "$ln_work"
        fi
    fi
    exit "$ln_status"
}
trap ln_cleanup 0
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 131' QUIT
trap 'exit 143' TERM
trap 'exit 141' PIPE

# Normalize the parent without interpreting the final name as shell code.
ln_path() {
    case $1 in
        ''|*"$ln_newline"*|*"$ln_cr"*) return 1 ;;
        /*) ln_path_input=$1 ;;
        *) ln_path_input=$(pwd -P)/$1 ;;
    esac
    ln_parent=${ln_path_input%/*}
    ln_base=${ln_path_input##*/}
    [ -n "$ln_base" ] || return 1
    ln_parent=$(CDPATH= cd -P "$ln_parent" 2>/dev/null && pwd -P) || return 1
    printf '%s/%s\n' "${ln_parent%/}" "$ln_base"
}

# Numeric ls fields work with both Linux and OpenBSD; names are not parsed.
ln_metadata() {
    ln_listing=$(ls -idn "$1" 2>/dev/null) || return 1
    printf '%s\n' "$ln_listing" | awk 'NR == 1 {print $1, $2, $3, $4, $5, $6; exit}'
}

# Prefix relative TMPDIR paths so a leading dash cannot become an option.
ln_tmp=${TMPDIR:-/tmp}
case $ln_tmp in /*) ;; *) ln_tmp=$(pwd -P)/$ln_tmp ;; esac
ln_work=$(mktemp -d "$ln_tmp/liner.XXXXXXXX") || { ln_error 'Cannot create private temporary directory.'; exit 1; }
case $ln_work in /*) ;; *) ln_work=$(pwd -P)/$ln_work ;; esac
if [ "$ln_check" = yes ]; then
    # A small functional probe, not just a list of installed executable names.
    if printf 'probe\r\n' > "$ln_work/probe" &&
        chmod 600 "$ln_work/probe" && cp -p "$ln_work/probe" "$ln_work/copy" &&
        cmp -s "$ln_work/probe" "$ln_work/copy" &&
        [ "$(wc -c < "$ln_work/probe" | awk '{print $1}')" = 7 ] &&
        [ "$(tail -c 1 "$ln_work/probe" | od -An -tu1 | awk '{print $1}')" = 10 ] &&
        tr -d '\000' < "$ln_work/probe" > "$ln_work/filtered" &&
        cmp -s "$ln_work/probe" "$ln_work/filtered" &&
        ln_metadata "$ln_work/probe" >/dev/null &&
        ln "$ln_work/copy" "$ln_work/link" && mv "$ln_work/link" "$ln_work/moved" &&
        cmp -s "$ln_work/probe" "$ln_work/moved"; then
        ln_say 'PASS: core utility and temporary-filesystem probe.'
        ln_say "Plain terminal mode selected: $ln_plain"
        ln_say 'Destination filesystems must separately support safe staged saves.'
        exit 0
    fi
    ln_error 'Core utility or temporary-filesystem probe failed.'; exit 1
fi
if [ $# -eq 1 ]; then
    ln_file=$(ln_path "$1") || { ln_error 'Cannot resolve filename or parent directory.'; exit 1; }
    if [ -e "$ln_file" ] || [ -L "$ln_file" ]; then
        [ -f "$ln_file" ] && [ -r "$ln_file" ] || { ln_error 'Input must be a readable regular file.'; exit 1; }
        ln_size=$(wc -c < "$ln_file") || exit 1
        [ "$ln_size" -le 8388608 ] || { ln_error 'File limit: 8 MiB.'; exit 1; }
        ln_saved_meta=$(ln_metadata "$ln_file") || exit 1
        cp "$ln_file" "$ln_work/0" || exit 1
        ln_read_meta=$(ln_metadata "$ln_file") || exit 1
        if [ "$ln_read_meta" != "$ln_saved_meta" ] || ! cmp -s "$ln_file" "$ln_work/0"; then
            ln_error 'Input changed during opening; retry.'; exit 1
        fi
        ln_existing=yes
    else
        : > "$ln_work/0" || exit 1
    fi
else
    : > "$ln_work/0" || exit 1
fi
chmod 600 "$ln_work/0" || exit 1
ln_size=$(wc -c < "$ln_work/0") || exit 1
[ "$ln_size" -le 8388608 ] || { ln_error 'File limit: 8 MiB.'; exit 1; }
tr -d '\000' < "$ln_work/0" > "$ln_work/checked" || exit 1
cmp -s "$ln_work/0" "$ln_work/checked" || { ln_error 'NUL byte or read error; input refused.'; exit 1; }
mv "$ln_work/checked" "$ln_work/saved" || exit 1
ln_select 0 || exit 1
ln_ready=yes
ln_snapshot_bytes=$ln_size

# Count/check need only the number of records. Other operations retain one
# input and one output record, not arrays proportional to the line count.
# The last byte distinguishes an unterminated record from a terminated one.
# Replacement text travels in a file, never in awk -v or shell source code.
ln_engine() {
    case $1 in
        count|check)
            LINER_MODE=$1 LINER_OP=${2-} LINER_FIRST=${3-} LINER_LAST=${4-} \
            awk '
            END {
                if (ENVIRON["LINER_MODE"] == "count") { print NR + 0; exit }
                first = ENVIRON["LINER_FIRST"]; last = ENVIRON["LINER_LAST"]
                maximum = NR + (ENVIRON["LINER_OP"] == "insert")
                if (first !~ /^[0-9]+$/ || length(first) > 10 ||
                    last !~ /^[0-9]+$/ || length(last) > 10 ||
                    first + 0 < 1 || last + 0 < first + 0 || last + 0 > maximum) {
                    print "liner: Line range must be between 1 and " maximum "." > "/dev/stderr"
                    exit 1
                }
            }' "$ln_work/$ln_current"
            return ;;
    esac
    if [ "$1" = show ] && [ -n "${3-}" ]; then
        ln_engine check show "$3" "${4:-$3}" || return
    fi
    ln_end_byte=$(tail -c 1 "$ln_work/$ln_current" | od -An -tu1)
    LINER_MODE=$1 LINER_OP=${2-} LINER_FIRST=${3-} LINER_LAST=${4-} \
    LINER_END_BYTE=$ln_end_byte LINER_INPUT=$ln_work/input \
    awk '
    function error(s) { failed = 1; print "liner: " s > "/dev/stderr"; exit 1 }
    function number(s) { return s ~ /^[0-9]+$/ && length(s) <= 10 }
    function show(s,    i, c, v, result) {
        # Printable ASCII is common; avoid per-byte work for ordinary lines.
        if (s !~ /[^ -~\\]/) { printf "%s\n", s; return }
        result = ""
        for (i = 1; i <= length(s); i++) {
            c = substr(s, i, 1); v = byte[c]
            if (c == "\\") result = result "\\\\"
            else if (c == "\t") result = result "\\t"
            else if (v < 32 || v > 126) result = result sprintf("\\x%02X", v)
            else result = result c
            if (length(result) >= 1024) { printf "%s", result; result = "" }
        }
        printf "%s\n", result
    }
    function flush(    amount) {
        if (!have_output) return
        amount = length(out_line) + length(out_end)
        if (amount > 8388608 - size) error("File limit: 8 MiB.")
        size += amount
        printf "%s%s", out_line, out_end
        have_output = 0
    }
    function emit(s, e) {
        flush(); out_line = s; out_end = e; have_output = 1
    }
    # Keep the last replacement record pending so its original/append
    # ending can differ from the preceding replacement records.
    function replacement(e, append,    r, next_r, status) {
        status = getline r < input
        if (status <= 0) error("Cannot read new text.")
        while ((status = getline next_r < input) > 0) {
            emit(r, style); r = next_r
        }
        if (status < 0) error("Cannot read new text.")
        if (close(input) != 0) error("Cannot close new text.")
        emit(r, append && length(r) ? "" : e)
    }
    function record(s, e, idx) {
        if (e != "" && substr(s, length(s), 1) == "\r") {
            s = substr(s, 1, length(s) - 1); e = "\r\n"
        }
        if (idx == 1 && e != "") style = e
        if (mode == "show") {
            if (idx >= first && (all || idx <= last)) {
                printf "%6d  ", idx; show(s)
            }
        } else if (op == "change" && idx == first) replacement(e, 0)
        else if (op == "insert" && idx == first) {
            replacement(style, 0); emit(s, e)
        } else if (op != "delete" || idx < first || idx > last) emit(s, e)
    }
    BEGIN {
        mode = ENVIRON["LINER_MODE"]; op = ENVIRON["LINER_OP"]
        first = ENVIRON["LINER_FIRST"]; last = ENVIRON["LINER_LAST"]
        ended = ENVIRON["LINER_END_BYTE"] + 0 == 10
        input = ENVIRON["LINER_INPUT"]; style = "\n"
        all = mode == "show" && first == ""
        if (all) first = 1
        else {
            if (last == "") last = first
            if (!number(first) || !number(last) || first + 0 < 1 || last + 0 < first + 0)
                error("Invalid line range.")
            first += 0; last += 0
        }
        if (mode == "show") for (i = 1; i <= 255; i++) byte[sprintf("%c", i)] = i
        else if (mode != "edit" || (op != "change" && op != "insert" && op != "delete"))
            error("Invalid operation.")
    }
    {
        if (NR > 1) record(pending, "\n", NR - 1)
        pending = $0
    }
    END {
        if (failed) exit 1
        maximum = NR + (op == "insert")
        if (!all && last > maximum) error("Line range must be between 1 and " maximum ".")
        if (NR) record(pending, ended ? "\n" : "", NR)
        if (mode == "show") {
            if (!NR) print "(empty)"
            else if ((all || last == NR) && !ended) print "(last line has no final newline)"
            exit
        }
        if (op == "insert" && first == NR + 1) {
            if (NR && !ended) out_end = style
            replacement(style, NR && !ended)
        }
        if (op == "delete" && last == NR && !ended && have_output) out_end = ""
        if (have_output && out_end == "" && out_line == "") out_end = style
        flush()
    }' "$ln_work/$ln_current"
}

ln_page_size() {
    set -- $(stty size 2>/dev/null)
    ln_rows=${1-}; ln_columns=${2-}
    case $ln_rows in ''|*[!0-9]*|?????*) ln_rows=24 ;; esac
    case $ln_columns in ''|*[!0-9]*|?????*) ln_columns=80 ;; esac
    ln_rows=${ln_rows#"${ln_rows%%[!0]*}"}
    ln_columns=${ln_columns#"${ln_columns%%[!0]*}"}
    [ "${ln_rows:-0}" -ge 1 ] && [ "$ln_rows" -le 1000 ] || ln_rows=24
    [ "${ln_columns:-0}" -ge 2 ] && [ "$ln_columns" -le 4096 ] || ln_columns=80
    ln_height=$((ln_rows > 2 ? ln_rows - 2 : 1))
    ln_width=$((ln_columns - 1))
}

ln_read_key() {
    # Exactly one byte: a continuous reader could steal the next command.
    # Waiting for a tracked child also lets TERM interrupt a blocked read.
    dd bs=1 count=1 <&4 > "$ln_work/key" 2>/dev/null &
    ln_key_pid=$!
    if wait "$ln_key_pid"; then ln_key_status=0; else ln_key_status=$?; fi
    ln_key_pid=
    [ "$ln_key_status" -eq 0 ] && [ -s "$ln_work/key" ] || return 1
    ln_key=
    if IFS= read -r ln_key < "$ln_work/key"; then ln_key_number=10
    elif [ -n "$ln_key" ]; then ln_key_number="'$ln_key"
    else ln_key_number=0
    fi
}

ln_page() {
    if [ "$ln_plain" = yes ]; then ln_engine show '' "$1" "$2"; return; fi
    ln_engine show '' "$1" "$2" > "$ln_work/page-text" || return
    ln_page_size
    # A short result needs no screen takeover or immediate-key input.
    if awk -v h="$ln_height" -v w="$ln_width" '
        { rows += int((length($0) + w - 1) / w); if (rows > h) exit 1 }
    ' "$ln_work/page-text"; then cat "$ln_work/page-text"; return; fi
    rm -f "$ln_work/page-events"
    mkfifo "$ln_work/page-events" || { ln_error 'Cannot start pager.'; return; }
    ln_tty=$(stty -g) || { cat "$ln_work/page-text"; return; }
    exec 4<&0
    ln_page_input=yes
    if ! stty -echo -echonl -icanon -ixon min 1 time 0; then ln_page_restore; return; fi
    ln_alt=yes
    printf '\033[?1049h\033[H\033[J'
    # The renderer never reads the terminal. It keeps unpadded rows in memory,
    # so each held-key redraw costs only a screenful, even near the file end.
    LINER_PAGE_TEXT=$ln_work/page-text LINER_PAGE_EVENTS=$ln_work/page-events awk '
    function draw(height, next_width, move, screen_rows,
                  i, at, anchor, offset, last_top, bottom, percent, progress, hint) {
        if (width != next_width) {
            anchor = source[top]; offset = start[top]
            for (i in row) { delete row[i]; delete source[i]; delete start[i] }
            width = next_width; count = 0; top = 1
            for (i = 1; i <= n; i++) {
                for (at = 1; at <= length(text[i]); at += width) {
                    row[++count] = substr(text[i], at, width)
                    source[count] = i; start[count] = at
                    if (i == anchor && at <= offset) top = count
                }
            }
        }
        if (move == 2) top += height
        else if (move == -2) top -= height
        else top += move
        last_top = count - height + 1
        if (last_top < 1) last_top = 1
        if (top > last_top) top = last_top
        if (top < 1) top = 1
        printf "\033[H"
        for (i = top; i <= count && i < top + height; i++) printf "%s\033[K\r\n", row[i]
        hint = "Up/Down: row  PgUp/PgDn: screen  Enter/Space: next  q: return"
        if (length(hint) > width) hint = "Up/Down PgUp/PgDn q: return"
        if (length(hint) > width) hint = "q: return"
        printf "\033[J%s", substr(hint, 1, width)
        if (screen_rows >= 3 && width >= 4) {
            bottom = top + height - 1
            if (bottom > count) bottom = count
            percent = count ? int(bottom * 100 / count) : 100
            progress = sprintf("Rows %d-%d of %d (%d%%)", top, bottom, count, percent)
            if (length(progress) > width)
                progress = sprintf("%d-%d/%d %d%%", top, bottom, count, percent)
            if (length(progress) > width) progress = sprintf("%d%%", percent)
            printf "\r\n%s", progress
        }
        printf "\033[K"
        fflush()
    }
    BEGIN {
        file = ENVIRON["LINER_PAGE_TEXT"]; events = ENVIRON["LINER_PAGE_EVENTS"]
        while ((getline s < file) > 0) text[++n] = s
        close(file); top = 1
        # Closing each request also works with awks that buffer pipe input.
        while ((getline request < events) > 0) {
            close(events); split(request, part)
            draw(part[1], part[2], part[3], part[4])
            print "ok" > events; close(events)
        }
    }' < /dev/null &
    ln_page_pid=$!
    ln_move=0
    ln_escape=$(printf '\033')
    while :; do
        ln_page_size
        printf '%s %s %s %s\n' "$ln_height" "$ln_width" "$ln_move" "$ln_rows" > "$ln_work/page-events"
        # Acknowledge before the next request so a fast writer cannot reopen
        # the old pipe and lose an event while the renderer is closing it.
        IFS= read -r ln_ack < "$ln_work/page-events" || break
        ln_read_key || break
        ln_move=0
        case $ln_key in
            q) break ;;
            ''|' '|"$ln_cr") ln_move=2 ;;
            "$ln_escape")
                # A short timeout prevents a lone or partial Escape from hanging.
                stty min 0 time 1 || break
                ln_sequence=
                if ln_read_key; then
                    case $ln_key in
                        '['|O)
                            ln_sequence=$ln_key
                            ln_left=16
                            while [ "$ln_left" -gt 0 ] && ln_read_key; do
                                ln_sequence=$ln_sequence$ln_key
                                case $ln_key in [A-Za-z~]) break ;; esac
                                ln_left=$((ln_left - 1))
                            done ;;
                    esac
                fi
                stty min 1 time 0 || break
                case $ln_sequence in
                    '[A'|OA) ln_move=-1 ;;
                    '[B'|OB) ln_move=1 ;;
                    '[5~') ln_move=-2 ;;
                    '[6~') ln_move=2 ;;
                esac ;;
        esac
    done
    ln_page_restore
}

ln_text_input() {
    if [ "$ln_plain" = yes ]; then
        if [ -t 0 ]; then printf 'Text> '; fi
        IFS= read -r ln_text || return 2
        # Keep an OS file-size-limit signal from killing the parent shell.
        (printf '%s\n' "$ln_text" > "$ln_work/input") || return 3
        return 0
    fi
    rm -f "$ln_work/input-events" "$ln_work/input"
    mkfifo "$ln_work/input-events" || return 3
    ln_tty=$(stty -g) || return 3
    exec 4<&0
    ln_page_input=yes
    if ! stty -echo -echonl -icanon -ixon -isig -iexten -icrnl -inlcr -igncr min 1 time 0; then
        ln_page_restore; return 3
    fi
    ln_alt=yes; ln_bracketed=yes; ln_text_screen=yes
    printf '\033[?1049h\033[?2004h\033[H\033[J'
    LINER_DRAFT_EVENTS=$ln_work/input-events LINER_DRAFT_OUTPUT=$ln_work/input \
    LINER_DRAFT_ORIGINAL=$ln_work/input-original LINER_DRAFT_LABEL="$ln_command $ln_first" \
    awk '
    function shown_byte(c,    value) {
        value = number[c]
        if (c == "\\") return "\\\\"
        if (c == "\t") return "\\t"
        if (value < 32 || value > 126) return sprintf("\\x%02X", value)
        return c
    }
    function layout(    i, c, s, x) {
        for (i in row_text) {
            delete row_text[i]; delete row_first[i]; delete row_last[i]; delete row_wrap[i]
        }
        row_count = 1; row_text[1] = ""; row_first[1] = 0; x = 0
        for (i = 0; i < length(draft); i++) {
            c = substr(draft, i + 1, 1)
            if (c != "\n") {
                s = substr(shown_byte(c), 1, width)
                if (x && x + length(s) > width) {
                    row_last[row_count] = i; row_wrap[row_count] = 1
                    row_count++; row_text[row_count] = ""; row_first[row_count] = i; x = 0
                }
            }
            if (i == cursor) { cursor_row = row_count; cursor_column = x }
            if (c == "\n") {
                row_last[row_count] = i; row_wrap[row_count] = 0
                row_count++; row_text[row_count] = ""; row_first[row_count] = i + 1; x = 0
            } else { row_text[row_count] = row_text[row_count] s; x += length(s) }
        }
        row_last[row_count] = length(draft); row_wrap[row_count] = 0
        if (cursor == length(draft)) { cursor_row = row_count; cursor_column = x }
    }
    function draw(    i, row, hint, title, old) {
        if (screen_rows < header + 2 || width < 8) {
            printf "\033[H\033[J%s\033[1;1H\033[?25h", substr("Text> Enlarge window", 1, width)
            fflush(); return
        }
        if (cursor_row < top) top = cursor_row
        if (cursor_row >= top + height) top = cursor_row - height + 1
        title = "Text> " ENVIRON["LINER_DRAFT_LABEL"]
        printf "\033[?25l\033[1;1H\033[7m%s\033[0m\033[K", substr(title, 1, width)
        if (header == 2) {
            old = "Old: " original
            if (length(old) > width) old = substr(old, 1, width - 3) "..."
            printf "\033[2;1H%s\033[K", old
        }
        for (i = 0; i < height; i++) {
            row = top + i
            printf "\033[%d;1H%s\033[K", header + i + 1, row <= row_count ? row_text[row] : ""
        }
        hint = notice != "" ? notice : "Enter: accept | Ctrl-J: new line | Esc: cancel"
        if (notice == "" && length(hint) > width) hint = "Enter=ok Esc=cancel"
        if (notice == "" && length(hint) > width) hint = "Enter/Esc"
        printf "\033[%d;1H%s\033[K\033[%d;%dH\033[?25h", screen_rows, substr(hint, 1, width), \
               header + cursor_row - top + 1, cursor_column + 1
        fflush()
    }
    function insert_text(s) {
        if (length(draft) + length(s) > limit) { notice = "Draft limit: 8 MiB."; return }
        draft = substr(draft, 1, cursor) s substr(draft, cursor + 1)
        cursor += length(s); goal_set = 0
    }
    function vertical(amount,    target, p, stop, x, cells) {
        if (!goal_set) { goal = cursor_column; goal_set = 1 }
        target = cursor_row + amount
        if (target < 1) target = 1
        if (target > row_count) target = row_count
        p = row_first[target]; stop = row_last[target]; x = 0
        while (p < stop) {
            cells = length(substr(shown_byte(substr(draft, p + 1, 1)), 1, width))
            if (x + cells > goal || (row_wrap[target] && p + 1 == stop)) break
            x += cells; p++
        }
        cursor = p
    }
    function navigation(s) {
        if (s == "A") vertical(-1)
        else if (s == "B") vertical(1)
        else if (s == "5~") vertical(-height)
        else if (s == "6~") vertical(height)
        else {
            goal_set = 0
            if (s == "D" && cursor) cursor--
            else if (s == "C" && cursor < length(draft)) cursor++
            else if (s == "H" || s == "1~" || s == "7~")
                while (cursor && substr(draft, cursor, 1) != "\n") cursor--
            else if (s == "F" || s == "4~" || s == "8~")
                while (cursor < length(draft) && substr(draft, cursor + 1, 1) != "\n") cursor++
            else if (s == "3~" && cursor < length(draft))
                draft = substr(draft, 1, cursor) substr(draft, cursor + 2)
        }
    }
    function paste_add(c) {
        if (paste_error != "") return
        if (length(draft) + paste_length + length(c) > limit) {
            paste_error = "size limit"; return
        }
        if (length(paste_piece[piece]) >= 4096) { piece++; paste_piece[piece] = "" }
        paste_piece[piece] = paste_piece[piece] c; paste_length += length(c)
    }
    function paste_payload(c) {
        if (c == "\r") {
            if (paste_cr) paste_add("\n")
            paste_cr = 1; return
        }
        if (paste_cr) {
            paste_add("\n"); paste_cr = 0
            if (c == "\n") return
        }
        paste_add(c)
    }
    function paste_byte(code,    i, added) {
        if (!code) {
            paste_error = "NUL byte"; paste_hold = ""; return
        }
        paste_hold = paste_hold character[code]
        while (length(paste_hold) && substr(paste_end, 1, length(paste_hold)) != paste_hold) {
            paste_payload(substr(paste_hold, 1, 1))
            paste_hold = substr(paste_hold, 2)
        }
        if (paste_hold != paste_end) return
        if (paste_cr) paste_add("\n")
        if (paste_error == "") {
            added = ""
            for (i = 1; i <= piece; i++) added = added paste_piece[i]
            insert_text(added)
        } else notice = "Paste refused: " paste_error "."
        for (i in paste_piece) delete paste_piece[i]
        pasting = 0; paste_hold = ""; paste_cr = 0
    }
    function input_byte(code,    c, mode) {
        if (pasting) { paste_byte(code); return }
        notice = ""
        if (code == -2) return
        if (code == -1) {
            if (escape == 1) finished = "cancel"
            escape = 0; sequence = ""; return
        }
        if (code == 3 || code == 4) { finished = "cancel"; return }
        c = character[code]
        if (escape == 1) {
            if (code == 91) escape = 2
            else if (code == 79) escape = 3
            else escape = 0
            sequence = ""; return
        }
        if (escape) {
            if (code >= 64 && code <= 126) {
                sequence = sequence c; mode = escape; escape = 0
                if (mode == 2 && sequence == "200~") {
                    pasting = 1; paste_hold = ""; paste_error = ""; paste_cr = 0
                    piece = 1; paste_piece[1] = ""; paste_length = 0
                } else navigation(sequence)
                sequence = ""
            } else if (code >= 32 && code <= 63 && length(sequence) < 32) sequence = sequence c
            else { escape = 0; sequence = "" }
            return
        }
        if (code == 27) escape = 1
        else if (code == 13) finished = "done"
        else if (code == 8 || code == 127) {
            if (cursor) {
                draft = substr(draft, 1, cursor - 1) substr(draft, cursor + 1)
                cursor--; goal_set = 0
            }
        } else if (code == 9 || code == 10 || code >= 32) insert_text(c)
        else if (!code) notice = "NUL byte refused."
    }
    BEGIN {
        events = ENVIRON["LINER_DRAFT_EVENTS"]; destination = ENVIRON["LINER_DRAFT_OUTPUT"]
        source = ENVIRON["LINER_DRAFT_ORIGINAL"]
        if ((getline original < source) < 1) original = ""
        close(source)
        header = original == "" ? 1 : 2
        limit = 8388608; top = 1; cursor = 0; draft = ""
        for (i = 1; i <= 255; i++) {
            character[i] = sprintf("%c", i); number[character[i]] = i
        }
        paste_end = character[27] "[201~"
        while ((getline request < events) > 0) {
            close(events); split(request, field)
            screen_rows = field[2] + 0; width = field[3] - 1
            if (width < 1) width = 1
            height = screen_rows - header - 1
            if (height < 1) height = 1
            if (!pasting) layout()
            input_byte(field[1] + 0)
            if (finished != "") {
                # Reply before writing so a failed write cannot strand the
                # parent opening a FIFO after this worker has already exited.
                print finished > events; close(events)
                if (finished == "done") {
                    printf "%s\n", draft > destination
                    if (close(destination) != 0) exit 1
                }
                exit
            }
            if (!pasting && !escape) { layout(); draw() }
            print (pasting ? "paste" : escape ? "escape" : "key") > events
            close(events)
        }
    }' < /dev/null &
    ln_page_pid=$!
    ln_draft_status=3
    ln_reply=key; ln_wait_mode=key; ln_event=-2
    while :; do
        if [ "$ln_reply" = key ]; then ln_page_size; fi
        printf '%d %s %s\n' "$ln_event" "$ln_rows" "$ln_columns" > "$ln_work/input-events"
        IFS= read -r ln_reply < "$ln_work/input-events" || break
        case $ln_reply in
            done)
                if wait "$ln_page_pid"; then ln_draft_status=0; else ln_draft_status=3; fi
                ln_page_pid=; break ;;
            cancel) ln_draft_status=1; break ;;
        esac
        if [ "$ln_reply" = escape ]; then ln_next_wait=escape; else ln_next_wait=key; fi
        if [ "$ln_next_wait" != "$ln_wait_mode" ]; then
            if [ "$ln_next_wait" = escape ]; then stty min 0 time 1 || break
            else stty min 1 time 0 || break
            fi
            ln_wait_mode=$ln_next_wait
        fi
        if ln_read_key; then ln_event=$ln_key_number
        elif [ "$ln_reply" = escape ]; then ln_event=-1
        else ln_draft_status=2; break
        fi
    done
    ln_page_restore
    return "$ln_draft_status"
}

# Numbered snapshots occupy at most 64 MiB and 129 files (current plus
# 128 undo/redo states). Candidate/saved/staging files are separate overhead.
# Publish the new state first; pruning failure must never lose current text.
ln_commit_edit() {
    if cmp -s "$ln_work/candidate" "$ln_work/$ln_current"; then
        rm -f "$ln_work/candidate"; ln_say 'Unchanged.'; return
    fi
    ln_next=$((ln_current + 1))
    ln_next_size=$(wc -c < "$ln_work/candidate") || return
    ln_old_size=0
    if [ "$ln_next" -le "$ln_last" ]; then
        ln_old_size=$(wc -c < "$ln_work/$ln_next") || return
    fi
    mv -f "$ln_work/candidate" "$ln_work/$ln_next" || { ln_error 'Cannot record change; buffer retained.'; return; }
    ln_snapshot_bytes=$((ln_snapshot_bytes + ln_next_size - ln_old_size))
    ln_remove=$((ln_next + 1)); ln_old_last=$ln_last
    if ! ln_select "$ln_next"; then
        # The candidate may have replaced a redo state; never navigate that
        # uncertain branch. The previous selected snapshot remains intact.
        ln_history_blocked=yes; ln_last=$ln_current
        ln_error 'Save current text and reopen before changing history.'
        return
    fi
    ln_last=$ln_next
    while [ "$ln_remove" -le "$ln_old_last" ]; do
        if ln_old_size=$(wc -c < "$ln_work/$ln_remove") && rm -f "$ln_work/$ln_remove"; then
            ln_snapshot_bytes=$((ln_snapshot_bytes - ln_old_size))
        else ln_history_blocked=yes; break; fi
        ln_remove=$((ln_remove + 1))
    done
    ln_pruned=no
    while [ "$ln_history_blocked" = no ] && [ "$ln_floor" -lt "$ln_current" ] &&
        { [ "$ln_snapshot_bytes" -gt 67108864 ] || [ "$((ln_current - ln_floor))" -gt 128 ]; }; do
        if ln_old_size=$(wc -c < "$ln_work/$ln_floor") && rm -f "$ln_work/$ln_floor"; then
            ln_snapshot_bytes=$((ln_snapshot_bytes - ln_old_size))
            ln_floor=$((ln_floor + 1)); ln_pruned=yes
        else ln_history_blocked=yes; break; fi
    done
    [ "$ln_pruned" = no ] || ln_say 'Old undo states pruned to bound temporary storage.'
    [ "$ln_history_blocked" = no ] || ln_error 'Cannot prune history. Save current text and reopen before editing again.'
    ln_count=$(ln_engine count) || return
    ln_say "Changed. $ln_count lines."
}

ln_disk_matches() {
    [ -f "$1" ] && [ ! -L "$1" ] || return 1
    ln_now_meta=$(ln_metadata "$1") || return 1
    [ "$ln_now_meta" = "$ln_saved_meta" ] && cmp -s "$1" "$ln_work/saved"
}

ln_save() {
    ln_target=$(ln_path "$1") || { ln_error 'Cannot resolve destination or parent directory.'; return; }
    ln_present=no
    if [ -e "$ln_target" ] || [ -L "$ln_target" ]; then
        if [ "$ln_target" != "$ln_file" ] || [ "$ln_existing" != yes ]; then
            ln_error 'Destination exists. Choose a new filename.'; return
        fi
        if [ -L "$ln_target" ]; then
            ln_error 'Symbolic link: use write FILE for a new path.'; return
        fi
        ln_disk_matches "$ln_target" || { ln_error 'File changed on disk; use write FILE for a new path.'; return; }
        [ -w "$ln_target" ] || { ln_error 'File is not writable.'; return; }
        set -- $ln_now_meta
        [ "$3" -eq 1 ] || { ln_error 'Multiple hard links: use write FILE for a new path.'; return; }
        ln_present=yes
    elif [ "$ln_target" = "$ln_file" ] && [ "$ln_existing" = yes ]; then
        ln_error 'File was removed on disk; use write FILE for a new path.'; return
    fi
    cp "$ln_work/$ln_current" "$ln_work/saved.next" || { ln_error 'Cannot prepare saved-state record.'; return; }
    ln_save_dir=${ln_target%/*}
    ln_stage=$(mktemp "$ln_save_dir/.liner-save.XXXXXXXX") || { ln_error 'Cannot create save file.'; return; }
    if [ "$ln_present" = yes ] && ! cp -p "$ln_target" "$ln_stage"; then
        ln_error 'Cannot preserve file attributes; write cancelled.'
    elif ! cat "$ln_work/$ln_current" > "$ln_stage"; then
        ln_error 'Write failed; original and editing buffer retained.'
    elif ! chmod u-s,g-s "$ln_stage"; then
        ln_error 'Cannot remove special privilege bits; write cancelled.'
    elif ! cmp -s "$ln_work/$ln_current" "$ln_stage"; then
        ln_error 'Saved bytes could not be verified; write cancelled.'
    elif [ "$ln_present" = yes ] && ! ln_disk_matches "$ln_target"; then
        ln_error 'File changed during save; write cancelled.'
    else
        ln_written=no
        if [ "$ln_present" = yes ]; then
            if mv -f "$ln_stage" "$ln_target"; then ln_written=yes; fi
        elif ln "$ln_stage" "$ln_target"; then
            ln_written=yes
        fi
        if [ "$ln_written" = yes ] && [ -f "$ln_target" ] && [ ! -L "$ln_target" ] &&
            cmp -s "$ln_target" "$ln_work/$ln_current"; then
            rm -f "$ln_stage"; ln_stage=
            ln_file=$ln_target; ln_existing=yes
            mv -f "$ln_work/saved.next" "$ln_work/saved" || {
                ln_error 'Written, but saved-state update failed. Reopen before another write.'; return;
            }
            ln_saved_meta=$(ln_metadata "$ln_file") || {
                ln_error 'Written, but attributes could not be read. Reopen before another write.'; return;
            }
            ln_say 'Written.'; return
        fi
        ln_error 'Write failed; editing buffer retained.'
    fi
    rm -f "$ln_stage"; ln_stage=
    rm -f "$ln_work/saved.next"
}

ln_count=$(ln_engine count) || exit 1
ln_say "liner $ln_version | $ln_count lines | Type help for commands."
while :; do
    if [ -t 0 ]; then
        if ln_dirty; then printf 'liner*> '; else printf 'liner> '; fi
    fi
    IFS= read -r ln_line || {
        if ln_dirty; then ln_error 'Input ended with unsaved changes.'; exit 1; fi
        exit 0
    }
    ln_line=${ln_line#"${ln_line%%[! 	]*}"}
    ln_command=${ln_line%%[ 	]*}
    ln_args=${ln_line#"$ln_command"}
    ln_args=${ln_args#"${ln_args%%[! 	]*}"}
    case $ln_command in
        '') continue ;;
        show|page)
            set -- $ln_args
            if [ $# -gt 2 ]; then ln_error 'Usage: show/page [FIRST [LAST]]'
            elif [ "$ln_command" = page ]; then ln_page "${1-}" "${2-}"
            else ln_engine show '' "${1-}" "${2-}"
            fi ;;
        change|insert|delete)
            if [ "$ln_history_blocked" = yes ]; then ln_error 'History cleanup failed; save and reopen.'; continue; fi
            set -- $ln_args
            if [ $# -eq 0 ] || [ $# -gt 2 ] || { [ "$ln_command" != delete ] && [ $# -ne 1 ]; }; then
                ln_error 'Use change LINE, insert LINE, or delete FIRST [LAST].'; continue
            fi
            ln_first=$1; ln_final=${2-$1}
            ln_engine check "$ln_command" "$ln_first" "$ln_final" || continue
            if [ "$ln_command" != delete ]; then
                : > "$ln_work/input-original" || { ln_error 'Cannot prepare text input.'; continue; }
                if [ "$ln_command" = change ]; then
                    ln_engine show '' "$ln_first" "$ln_first" > "$ln_work/input-original" || continue
                    cat "$ln_work/input-original"
                fi
                if ln_text_input; then :
                else
                    ln_input_status=$?
                    case $ln_input_status in
                        1) ln_say 'Cancelled.'; continue ;;
                        2) ln_error 'Input ended; change cancelled.'; exit 1 ;;
                        *) ln_error 'Cannot store new text; change cancelled.'; continue ;;
                    esac
                fi
            fi
            if ln_engine edit "$ln_command" "$ln_first" "$ln_final" > "$ln_work/candidate"; then
                ln_commit_edit
            else
                rm -f "$ln_work/candidate"
            fi ;;
        write)
            if [ -n "$ln_args" ]; then ln_save "$ln_args"
            elif [ -n "$ln_file" ]; then ln_save "$ln_file"
            else ln_error 'Use write FILE to name this file.'
            fi ;;
        undo|redo|help|manual|about|quit|quit!)
            if [ -n "$ln_args" ]; then ln_error 'This command takes no argument.'; continue; fi
            case $ln_command in
                undo)
                    if [ "$ln_history_blocked" = yes ]; then ln_error 'History cleanup failed; save and reopen.'
                    elif [ "$ln_current" -gt "$ln_floor" ]; then
                        if ln_select "$((ln_current - 1))"; then ln_say 'Undone.'; fi
                    else ln_say 'Nothing to undo.'; fi ;;
                redo)
                    if [ "$ln_history_blocked" = yes ]; then ln_error 'History cleanup failed; save and reopen.'
                    elif [ "$ln_current" -lt "$ln_last" ]; then
                        if ln_select "$((ln_current + 1))"; then ln_say 'Redone.'; fi
                    else ln_say 'Nothing to redo.'; fi ;;
                help) ln_help ;;
                manual) ln_manual ;;
                about) ln_about ;;
                quit)
                    if ln_dirty; then ln_error 'Unsaved changes. Use write, or quit! to discard.'
                    else ln_discard=yes; exit 0; fi ;;
                quit!) ln_discard=yes; exit 0 ;;
            esac ;;
        *) ln_suggest ;;
    esac
done
