Minimal terminal editors: editor 0.6.19 / liner 0.9
=================================================

READING OR CONTRIBUTING TO THE SOURCE
Start with CONTRIBUTING.txt for a source map, buffer and history ownership,
save commit boundaries, terminal input rules, and the regression-test layout.
editor.c also has a short reading guide and comments beside the relevant code.
See CHANGES.txt and VALIDATION.txt for release changes and test results.
See LONGEVITY.txt for permanent portability and preservation guidelines.

MENU AND SETTINGS (0.6.19)

Type menu at Command> to open the main menu once without changing Esc.
Use toggle-esc to change the saved preference instead. Help > Settings
(or the settings command) now has item 9, Apply / Return to editor.
Successful settings changes save immediately as before; Apply finishes the
menu visit without a second config write or a change to the editing mode.

PERFORMANCE AND ENDURANCE (0.6.18 / liner 0.9)

Liner streams numbered records through awk rather than collecting the
whole document in per-line arrays. Counting, range validation and editing
are bounded by the longest record/draft and a few pending records; this
is not a fixed-memory guarantee for long single lines. Snapshot disk
storage and the 8 MiB document limit remain unchanged. Printable ASCII
lines bypass per-byte escaping, and other display output uses small
chunks without sending untrusted terminal control bytes.

Editor maintains the plain-mode record count across edits and history
steps and avoids doubling the buffer allocation at the exact document
limit. Full-screen rendering, commands and the on-disk journal are
unchanged. For development-only validation:

    python3 tests/streaming.py ./editor --busybox
    cc -std=c99 -O2 -Wall -Wextra -Werror -pedantic tests/plain_count_core.c -o plain-count-core
    ./plain-count-core

Omit --busybox if it is not installed. This test uses Linux resource
limits, Python and optional BusyBox; none is required at runtime.
See VALIDATION.txt for measured workloads and their limitations.

ENVIRONMENTAL RESILIENCE

    ./editor --check
    sh liner.sh --check
    ./editor --plain config.conf
    sh liner.sh --plain config.conf

Plain mode works with ordinary line input, even when TERM=dumb or no
terminal is attached. It accepts show, page, change, insert, delete,
undo, redo, write, help, manual, about, quit and quit!. Change and insert
read one literal line. In plain editor mode, stdin is the command stream,
not document input, and overwrite confirmations are replaced by refusal.
Use a different, new filename when a save conflicts with another writer.
Liner also selects plain mode when its optional terminal tools are absent,
TERM is unset/dumb, or input/output is not a terminal. Its numbered undo
snapshots are pruned at 64 MiB or 128 prior states. Other temporary files
and filesystem overhead are additional. No new runtime dependencies.

Run tests/rescue-smoke.sh for an offline, shell-only smoke test after building.
The larger development test suite uses Python, but neither editor does.
resilience-upgrade.patch updates the two source files from the 0.6.14
commented source package and liner 0.6; the full archive also updates docs.

DATA INTEGRITY AND RECOVERY

    editor --recoveries

Editor attempts an exact private text copy on dirty EOF or handled fatal
signals (HUP, INT, QUIT, TERM), and detected terminal/output failure. The
original document is never overwritten by recovery. The default location
is $XDG_STATE_HOME/editor or ~/.local/state/editor, with TMPDIR (/tmp)
as fallback if the private state location is unavailable or writing fails.
Use the list command to find a copy after a disconnect. Inspect the file
and save to a new path. The clipboard and any parked dirty document are
recovered separately. Deliberate quit! does not create recovery files.
Recovery copies are sensitive plaintext and are not deleted automatically.
SIGKILL, memory exhaustion, storage failure, process bugs and power loss
can still prevent or interrupt recovery; inspect candidate files before use.
No periodic autosave or recovery of unaccepted drafts is implied.

Liner records the selected numbered undo snapshot in a small CURRENT file
inside its existing private temporary directory. An abrupt process kill
can leave this directory; read CURRENT rather than choosing the largest
snapshot number. Inspect and copy the selected file to a new path. Liner
cannot guarantee recovery after temporary storage is cleared or power loss.
See docs/liner.txt for the recovery procedure. Both still support --plain.

EDITOR - SIMPLE TERMINAL TEXT EDITING IN C

BUILD AND INSTALL (FIRST INSTALL OR UPDATE)
Run these commands from this extracted minimal-editors directory, as the
account that will use editor. The && operators stop the sequence if a step
fails, so a failed compilation does not install an older local executable.

    mkdir -p "$HOME/.local/bin" &&
    cc -std=c99 -O2 -Wall -Wextra -pedantic editor.c -o editor &&
    install -m 755 editor "$HOME/.local/bin/editor" &&
    "$HOME/.local/bin/editor" --version

For the standalone source download, substitute editor-0.6.19.c for editor.c
in the compilation command above.

Repeat this build-and-install sequence after each source update. Compiling
creates ./editor in the current directory; it does not update the installed
executable. The install command replaces $HOME/.local/bin/editor.

ONE-TIME PATH SETUP
To run editor by name, $HOME/.local/bin must be on PATH. If it is not already
present, add this line once to ~/.profile for your OpenBSD ksh login:

    export PATH="$HOME/.local/bin:$PATH"

Apply the profile to the current shell:

    . "$HOME/.profile"

Check which executable will run, then check its version:

    command -v editor
    editor --version

The first command should identify $HOME/.local/bin/editor. If it identifies
another copy or a shell alias/function, resolve that before relying on the
bare editor command. The explicit path $HOME/.local/bin/editor bypasses that
name lookup. Other shells may use a different login/startup file. PATH setup
is only needed once; do not append it again for each editor update.

SYSTEM-WIDE OPENBSD INSTALL (ROOT-OWNED)
For users who invoke editor from both a personal login and doas -u root -s,
install the binary once under /usr/local/bin. From the source directory:

    cc -std=c99 -O2 -Wall -Wextra -pedantic editor.c -o editor &&
    doas install -o root -g wheel -m 755 editor /usr/local/bin/editor &&
    /usr/local/bin/editor --version

From an existing root shell, omit doas. This does not update a separate copy
in ~/.local/bin; inspect command -v editor for PATH conflicts.
Never add a writable user's bin directory to root's PATH.

UNINSTALL EDITOR
From the extracted source directory, remove the per-user installation:

    sh uninstall.sh

For the system-wide installation (OpenBSD):

    doas sh uninstall.sh --system

On Linux, use sudo instead of doas if needed; omit it in a root shell.
The default scope is the current account's $HOME/.local/bin/editor.
--system selects /usr/local/bin/editor only. Add --dry-run to preview
or --yes for noninteractive removal. The script prompts before removal
unless --yes is given; repeated removal is harmless. It refuses symlinks,
non-executables and files without the expected editor identification
strings. It never executes the installed program to identify it. Older
or customized builds lacking these markers need manual verification.

The uninstaller removes only the documented installed binary. It does not
remove preferences, custom commands, keymaps, clipboard/undo history,
recovery copies, edited documents, source/build files, liner, guest-jail
copies, manually installed manpages or PATH entries. Exit running editor
sessions before uninstalling. If another editor remains on PATH, verify
with command -v editor (and refresh the shell's command cache if needed).
Do not install and uninstall concurrently.

RUN
    editor config.conf
    editor --menu config.conf

You can still run the uninstalled build as ./editor config.conf.

RESTRICTING EXTERNAL COMMANDS (GUESTSHELL)

    editor --no-cmd FILE

Disables shell, filter and filter-lines for this process, including all
aliases, user-defined commands, nested scripts and hotkeys. No menu entries
or built-in completion suggestions offer those operations. The ordinary
editor command prompt and internal editing scripts remain usable. A script
stops at a forbidden step; earlier successful edits are not rolled back.
The policy cannot be changed by config, environment or editor commands.

For untrusted guests, compile a separate executable with no process-launch
implementation at all:

    cc -std=c99 -O2 -Wall -Wextra -Werror -pedantic \
        -DEDITOR_NO_CMD editor.c -o editor-guest
    ./editor-guest --version
    ./editor-guest --check

The version must say "(no-cmd build)" and the check must report
"disabled (compile-time EDITOR_NO_CMD)". Install only this root-owned,
non-guest-writable executable in the jail and verify the exact staged copy.
Do not stage a normal editor executable alongside it. A command-line flag
alone is appropriate only if the launcher controls every invocation.

No-cmd is defense in depth, NOT an operating-system sandbox. The editor
still reads/writes files accessible to its OS user, uses preferences and
undo/clipboard storage, and supports terminal job control. Do not run it
with elevated privileges for guests. Keep the jail, user permissions,
network/process policy, trusted launcher and root-owned program paths in
place. Do not expose a general shell or allow writable executable paths.
Plain mode never runs external commands, with or without --no-cmd.

EXTERNAL COMMANDS AND USER-DEFINED COMMANDS

    shell ls -1
        Execute /bin/sh -c 'ls -1' and insert its standard output at cursor.
        With no argument, shell asks for the command at Shell>.

    filter sort
        Send the entire document through sort and replace it with stdout.

    filter-lines 3-9 sort -u
        Send only complete lines 3 through 9 to the command, replacing those
        lines with captured output. Use one line number for a single line.

    All three are available under Edit when external commands are enabled. Each successful operation
    is one undo step. The shell child runs with editor's OS privileges and
    working directory. When editor runs as root, the child also runs as root.
    Shell commands are therefore explicit only: opening a document, pasting,
    loading a config, and viewing a script as a document do not execute it.
    No terminal input is provided to shell commands. For filter, stdin is the
    selected document text. stdout is the only text inserted; stderr and exit
    status are kept separate. A nonzero exit, interrupt, allocation failure,
    excessive output, or NUL/escape/control byte rejects the whole edit.
    CR, LF and CRLF output is normalized to the document's newline style.
    Do not use curses or interactive programs like vi, less, or top this way.
    Filters may legitimately return empty output and thereby delete text.
    Undo reverses each successful insertion or replacement.

    define dirlist shell ls -1
        Save a custom editor command named dirlist; type dirlist to run it.

    define q1 quit!
        Save q1 as an explicit alias for discarding unsaved edits and exiting.
        q1 exists only after defining it. Plain quit still checks for changes.

    A directly invoked definition behaves like typing its command, including
    normal prompts. For example, define store write retains Filename> for an
    unnamed file. Definitions may call other definitions, up to eight levels.
    Script calls keep the restricted script rules even through nested aliases.
    The built-in files name already means ls; dirlist avoids that conflict.

    define stamp shell date
        Save a name for a shell-output insertion.

    functions
        List the saved definitions. functions reload rereads the file.
    undefine dirlist
        Remove a definition.

    run ~/commands.editor
        Execute a plaintext editor-command script, one instruction per line.
        # comments and empty lines are ignored. Example file:

            # Build a header
            shell date
            shell uname -a

    define header run ~/commands.editor
        Bind the script to a custom command named header. Type header to run.

    Only user-owned, non-group/other-writable regular script files are read;
    script file size is limited to 32 KiB. Scripts are never run automatically
    on startup or opening documents. A script can use shell, filter,
    filter-lines, find, next/prev, goto, top/bottom, undo/redo,
    movement/edit, run, and named custom commands. Other editor commands
    (including quit, read, write, define) are refused within scripts to
    prevent unexpected interactive prompts or document switches. A script
    stops on failure (including a find with no match), after no more than
    200 executed steps or 8 nested
    definitions/scripts. Earlier successful steps stay in the undo history,
    one entry per edit; a script is NOT an all-or-nothing transaction.

    After defining a command, it may also be assigned to one of your own
    optional hotkeys, for example: bind F2 dirlist. No keys are assigned by
    default. Defining a command does not create a key binding.

    Key binding saves detect another session changing keys.conf, including
    while a save is being staged. A refused save keeps the requested binding
    in this session and reports that it was not saved. Reopen editor to load
    the current file before saving more bindings. Malformed keymap content
    must be corrected first; saving never silently removes unknown entries.
    --no-keys also disables bind/unbind for that launch, so an unloaded map
    cannot be overwritten accidentally.

    User definitions are stored in $XDG_CONFIG_HOME/editor/commands.conf,
    or ~/.config/editor/commands.conf (not in config or keys.conf). This is
    inert text loaded at startup. Names begin with a lowercase ASCII letter
    and continue with lowercase letters, digits, hyphen or underscore,
    maximum 31 characters. They cannot replace a built-in command or alias.
    Each definition is a single editor command line, up to 2047 bytes.
    Built-ins always win. User commands currently take no arguments; script
    files provide multi-step behavior without introducing a new language.
    Up to 32 definitions are saved atomically. A stale editor refuses to
    overwrite externally changed command definitions: functions reload
    refreshes them. File permissions and errors are reported instead of
    silently executing or ignoring unsafe definitions.

    For shell and filter, /bin/sh interprets the command text exactly as
    requested. Do not run untrusted command strings or pass untrusted shell
    fragments. Running a root-owned editor means shell commands run as root.


PASTING FROM THE TERMINAL
    An incomplete paste is discarded after five seconds without data. The
    editor displays a waiting-for-end-marker notice and keeps the document
    and command draft intact. Delayed paste bytes cannot become commands.
    If the terminal lost its end marker, make a small fresh bracketed paste
    to supply one; that paste is discarded too. Then paste the wanted text
    again. A complete paste still uses one undo step.

    Terminal paste recognizes CR, LF and CRLF line breaks and inserts each
    using the document's current newline style (the first newline found
    when opened, or LF for a new file). A CRLF pair produces one line break,
    not two. CRLF pairs split across terminal reads are handled together.
    Blank lines, indentation, tabs, UTF-8 and an absent final newline are
    retained. The two literal characters ^M are not changed.

    One complete terminal paste is one undoable change. Conversion happens
    while collecting the paste, without a second full-sized buffer. The
    document limit applies after conversion; a paste that would exceed it
    is rejected without partly inserting the text.

    This applies only to bracketed paste received from the terminal, including
    when editing a clipboard. Files opened with read, piped input, and the
    editor's paste [SLOT] command remain byte-preserving. Existing document
    bytes are not normalized or repaired automatically. Multiline pastes at
    Command> and argument prompts remain rejected without execution.

    This fixes the earlier behavior that saved CR-only terminal newlines
    as visible ^M characters on one long line. Undo a bad paste or remove
    that inserted block, then paste the original text again with this version.
    Simply hiding ^M or deleting CR bytes would join lines, not fix them.

One document at a time, arrow-key text editing, an optional numbered menu,
plain command prompt, an optional movement-only mode, saved undo/redo,
user-defined hotkeys (NONE by default),
and optional mouse controls. No ncurses, terminfo, readline, or external pager.
Movement mode: start with ./editor --movement file.conf, or use the command
'movement' at any time; 'edit' returns to typing. In that mode arrows and hjkl move;
p/n/b/f, Ctrl-P/N/B/F, 0/$, a/e, g/G, w/@, y/v also navigate.
Enter returns to ordinary edit mode. No text can be inserted from movement mode.
Controls > Current editing provides one switch for movement/edit, without saving.
Delete to boundaries with deleol (end of line, keep newline), deleof (EOF),
or backbof (beginning of file). Each deletion is one undo operation.

Esc opens Command> by default. The command line is a way to do tasks:

    menu             Open the main menu once (without changing Esc)
    help             A short starting guide
    list             Commands explained and grouped by purpose
    list clipboard   Find clipboard-related commands
    help cut         Examples, line/range meaning and accepted synonyms
    goto             Ask which line to go to

Esc/q from help/list goes straight back to Command>. Empty Enter returns to
the document; Esc at an empty prompt still asks Really quit? Command typos
keep the complete draft for correction; suggestions never run themselves.
Tab completes names, and ambiguous choices now explain what each command
does. Tab at an empty prompt opens the task guide. Manual remains the full
reference. No default keybindings were added.

CLIPBOARDS
  clipboard 2        Select clipboard slot 2 (persistent across sessions).
  copy 5             Copy DOCUMENT LINE 5 into the selected slot.
  cut 5-8            Cut document lines 5-8 into the selected slot.
  paste 2            Paste FROM SLOT 2 (selection unchanged).
  paste              Paste from the currently selected slot.
  clipboard          Toggle the selected clipboard's text editing screen.
  clipboard default  Select clipboard.txt (the original default slot).
  clipboard list     Display named clipboard slots.
  cb, cboard, clip, editclip: synonyms for clipboard.

While editing a clipboard, 'write' SAVES AND STAYS. 'clipboard' saves
pending edits without asking and returns to the original document, which
remains open with unsaved changes, cursor position, and undo history intact.
If saving fails, clipboard editing stays open with its text intact and an error.
The internal name selected is reserved; it is not a user clipboard slot.
Quit and quit! always exit the program, not just the clipboard.
Clipboard slots are private plaintext files under $XDG_STATE_HOME/editor/
(default ~/.local/state/editor/). clipboard-2.txt holds slot 2.

Optional clipboard history: 'toggle-cliphistory' switches collection on/off.
'cliphistory' browses snapshots; 'clipuse N' restores older content.
History is OFF by default and unencrypted. It is separate from named slots.

FIND AND REPLACE
  find TEXT                 Find case-sensitive literal text from cursor.
  next / n                  Find the next match (wrap around).
  prev / p                  Find the previous match (wrap around).
  replace                   Ask for search text, then replacement text.
  replaceall                Ask for search text, then replacement text.
  replace OLD => NEW        Replace next match from cursor, once.
  replaceall OLD => NEW     Replace all non-overlapping matches.
  undo                      Reverse a replacement; replaceall is ONE undo.
  Move >                    Find / Next / Previous menu entries.
  Edit >                    Replace / Replace all menu entries.
The older findnext/findprev names remain aliases. The former 'next' and
'previous' aliases for down/up are removed; use up/down to move vertically.
Use bare find to enter exact leading/trailing spaces in the Find> prompt,
including a search consisting only of spaces. Inline command separators are
still separators; Find> is not reparsed as a command.
No search/replace is regex. Replacements cannot exceed the 8 MiB text limit.

FILESYSTEM
read FILE opens a document after saved-work checks; ls [DIR] lists files.
Tab after read/write/ls completes filenames and directories. Command names
also have Tab completion. File/path contents are never executed as shell code.
A failure while determining a completion does not alter the draft. An error
notice returns to the same prompt with Esc/q. If a directory was successfully
completed but listing its contents fails, the valid completed path is kept. Ambiguous UTF-8 prefixes
stop at a complete character. Directory listings show up to 1024 entries and
explicitly mark truncation; completion checks the complete directory.
Command pastes are bounded to the remaining 4095-byte input space. Rejected
multiline, oversized, or invalid pastes are discarded through the paste end
marker without executing text from the paste. Esc/q closes the error notice.

STABILITY AND LIMITS
Rejected clipboard reads release partial allocations, including when large,
malformed or concurrently modified. Editor retains
safe file-write staging, outside-change confirmation for ordinary files,
and existing persistent undo journals. A clipboard may be replaced without
an overwrite confirmation, as requested. Handled abnormal exits attempt
private text recovery; sudden process death remains unprotected in editor.
Files are limited to 8 MiB; undo journals to 128 MiB / 100,000 edits.
Historical undo archives may grow until cleaned manually. Native OpenBSD
compilation and long-duration field usage remain unverified.

LINER
sh liner.sh config.conf - dependency-light line editor with optional pager.
Liner 0.9 includes a committed CURRENT recovery pointer. See docs/liner.txt
and docs/liner.1.

See docs/commands.txt for the exported task guide and command examples.
See docs/editor.txt or docs/editor.1 for all commands, synonyms, examples,
recovery, terminal controls, credits and the BLOODGUILT CURSE warning.

PROGRAM SETTINGS: HELP > SETTINGS
One row per choice; selecting it switches and saves. All toggle commands
use the same pattern and take no arguments:

    toggle-esc          Esc opens Command line / Menu.
    toggle-startup      Future launches start in Edit / Movement.
    toggle-mouse        Mouse Off / On, now and after restart.
    toggle-signals      Interrupt exits / cancels input, now and after restart.
    toggle-cliphistory  Clipboard history Off / On (old snapshots remain).

    menu                Open the main menu once, leaving Esc unchanged.
    settings            Open Help > Settings.
    settings show       Inspect saved/current values and the config path.

Only toggle-startup waits for the next launch. movement and edit still change
this session only. Controls > Current editing has one switch for those actions.
Settings menu entries display the current value, not separate choices as commands.
A failed save leaves the prior behavior unchanged and shows the error.
Choose 9 Apply / Return to editor when done; each successful toggle has
already been saved. Apply does not change the current editing mode.
A custom command named menu from an older release is retained but shadowed.
Use functions to see its body, define it under another name, and undefine menu
to remove the old definition. Review custom key bindings that refer to menu.

Config: ~/.config/editor/config, or $XDG_CONFIG_HOME/editor/config if absolute.
Your existing startup=movement, esc and signal_controls values still work.
Mouse now has its own saved mouse=on/off value. Clipboard history retains its
existing preference file with the clipboard data; no migration is required.
Owned 0755 directories and 0644 files are accepted. Changes preserve comments,
other settings and line endings; replacement config files use mode 0600.

--movement/--edit, --menu/--cli and --mouse/--no-mouse override a single launch
without saving. Last flag in each pair wins. No hotkeys are assigned by default.

Old command names startup, toggle-mode, mouse and signals now show a correction
instead of running. cliphistory only browses history. Update any user-created
bindings that invoke retired names. Config keys are unchanged; startup=movement
is still correct in the config file.

STAGED-SAVE FAILURE HANDLING (0.6.14)
A failed temporary-file creation does not authorize cleanup of the candidate
name. Only temporary files successfully created by this editor are removed.
Existing document, clipboard, keymap and undo-journal files survive that failure;
the buffer stays available for retry while the process remains running.

Staged writers check for pending interrupt/stop/termination signals immediately
before publishing their prepared file, including signals received during a
successful synchronization. Cancellation before publication retains the prior
destination. A write already committed is not rolled back. Native interrupt
still exits by default after attempting private recovery; toggle-signals retains its
existing opt-in cancellation behavior. No keys or signal defaults changed.

The source no longer calls strcpy or sprintf. Exact-size pathname joins check
size arithmetic, and fixed-buffer copies retain explicit length validation.
Linux builds check that neither symbol is referenced; this is not a native
OpenBSD build certification. See VALIDATION.txt for reproduced failures and
repeatable tests.

REPRODUCIBLE DEVELOPMENT CHECKS
Run: sh tests/run.sh
Additional integrity checks: python3 tests/integrity.py ./editor
Optional sanitizer build: SANITIZE=1 CC=clang sh tests/run.sh
The tests require a C compiler, Python 3, and bash for real job-control
checks; editor itself requires none of those test tools at runtime.
Tests use isolated temporary directories, not your editor configuration/data.
VALIDATION.txt lists the tests run for this release and remaining limitations.

EARLIER RELIABILITY WORK (0.6.4)
OS file-size limits report recoverable write errors instead of terminating
editor. Raw input preserves bytes under inherited parity-marking settings.
Low-memory redraw failures discard the expendable display cache, not the
editing buffer. Clipboard-history failures remain visible after copy/cut.
Private history I/O is buffered in fixed-size blocks without changing the
journal format; clipboard history previews read only the displayed prefix.
Malformed/overflowing mouse reports are rejected. Existing command/menu
parity is regression-tested. No commands, dependencies, or hotkeys were added.

Additional optional developer checks (Clang/libFuzzer):
  clang -std=c99 -O1 -g -fsanitize=fuzzer,address,undefined \
    tests/input_fuzz.c -o input-fuzz
  ./input-fuzz -runs=100000 -max_len=4096
Cross-release history check, using two trusted compiled editor executables:
  python3 tests/compatibility.py /path/to/editor-0.6.11 /path/to/editor-0.6.14
These are development tools only; neither is required to run editor.

TERMINAL SIGNALS AND EXIT NOTICE
Ctrl+C/Z are not editor bindings and are not disabled. The terminal's configured
interrupt/suspend characters and ISIG setting are retained. With standard
terminal settings, Ctrl+C exits after attempting recovery, and Ctrl+Z suspends;
fg resumes. Terminal settings are restored before stopping or exiting.

Optional setting in editor/config, OFF by default:
    signal_controls=off
ON makes an interrupt cancel input instead of terminating; stop still suspends.
Help > Settings > Signals and toggle-signals save signal_controls before
changing live behavior. settings show reports values without changing them.
If saving fails, the old behavior remains and an error is displayed. Esc
cancels input normally.
Old Ctrl+C/Z bindings are ignored and new bindings for those keys are refused.

Ordinary quit prints the BLOODGUILT CURSE notice after terminal restoration.
It does not pause. Forced/confirmed quick exits and signal exits skip it. The
notice never enters a document or the stdout data stream of a pipeline.

EARLIER REINFORCEMENT IN 0.6.8
Clipboard-history scans fail closed before restoration; failed initial scans
cannot silently renumber entries or prune history. Unavailable previews keep
their numbers. Long replace-all preparation checks cancellation before any
commit, and next/previous avoid scanning unrelated text. Controls and the
journal format are unchanged. See VALIDATION.txt for tests and limitations.

Optional local search microbenchmark (does not time terminal rendering):
  cc -std=c99 -O2 tests/search_bench.c -o search-bench
  ./search-bench
