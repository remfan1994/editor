#!/bin/sh
# Remove the documented installation of editor, never the user's data.
# No installed program is executed, and no directory is removed recursively.
set -eu
PATH=/usr/bin:/bin:/usr/sbin:/sbin
LC_ALL=C
export PATH LC_ALL

usage() {
    cat <<'USAGE'
Usage: sh uninstall.sh [--user | --system] [--dry-run | --yes]

  --user     Remove $HOME/.local/bin/editor (default).
  --system   Remove /usr/local/bin/editor (root required for removal).
  --dry-run  Inspect the selected file and report what would be removed.
  --yes      Remove a recognized editor without an interactive prompt.
  --help     Show this help.

Only the selected installed executable is removed. Documents, preferences,
undo history, recovery copies, liner, source files and PATH are preserved.
A symbolic link or an unrecognized executable is refused, not followed.
USAGE
}

fail() {
    printf 'uninstall: %s\n' "$*" >&2
    exit 1
}

scope=
dry_run=no
assume_yes=no
for arg do
    case "$arg" in
        --user|--system)
            [ -z "$scope" ] || fail 'Choose exactly one installation scope.'
            scope=$arg
            ;;
        --dry-run) dry_run=yes ;;
        --yes) assume_yes=yes ;;
        --help|-h) usage; exit 0 ;;
        *) fail "Unknown option: $arg (see --help)." ;;
    esac
done
if [ "$dry_run" = yes ] && [ "$assume_yes" = yes ]; then
    fail 'Use --dry-run or --yes, not both.'
fi

case "$scope" in
    --system)
        target=/usr/local/bin/editor
        if [ "$dry_run" = no ] && [ "$(id -u)" != 0 ]; then
            fail 'System-wide removal requires root. Use doas or sudo.'
        fi
        ;;
    *)
        # Never infer the target from PATH: editor is also a generic name.
        case "${HOME-}" in
            ''|/|[!/]*) fail 'HOME must be an absolute home-directory path.' ;;
        esac
        target=$HOME/.local/bin/editor
        ;;
esac

# Identification is intentionally conservative. These two distinctive strings
# occur in the editor 0.6.18 and 0.6.19 binaries (including stripped and no-CMD builds).
# This is an identity sanity check, not cryptographic authentication. Refuse
# unknown/older builds rather than guessing. Never run a binary to identify it.
inspect_target() {
    [ ! -L "$target" ] || fail "Refusing symbolic link: $target"
    if [ ! -e "$target" ]; then
        printf 'No installed editor found at %s. Nothing removed.\n' "$target"
        exit 0
    fi
    [ -f "$target" ] && [ -x "$target" ] ||
        fail "Not a regular executable: $target"
    if ! grep -a -F -q 'A small, single-file terminal text editor.' "$target" ||
       ! grep -a -F -q 'design by remfan1994' "$target" ||
       ! grep -a -F -q 'published by ThatIAm.vip' "$target"; then
        fail "Unrecognized editor executable; left unchanged: $target"
    fi
}

inspect_target
if [ "$dry_run" = yes ]; then
    printf 'Would remove: %s\nNo files changed.\n' "$target"
    exit 0
fi

printf 'Remove installed editor: %s\n' "$target"
if [ "$assume_yes" = no ]; then
    [ -t 0 ] || fail 'Interactive confirmation requires a terminal; use --yes if intended.'
    printf 'Proceed? [y/N] '
    IFS= read -r answer || answer=
    case "$answer" in
        y|Y|yes|YES|Yes) ;;
        *) printf 'Cancelled. No files changed.\n'; exit 0 ;;
    esac
fi

# Recheck after the prompt in case the installation changed while waiting.
# As with manual installation, use a trusted directory and do not run an
# installer or another uninstaller concurrently.
inspect_target
rm -f "$target" || fail "Could not remove: $target"
if [ -e "$target" ] || [ -L "$target" ]; then
    fail "File still exists: $target"
fi
printf 'Removed: %s\nUser data and all other installations were left unchanged.\n' "$target"
