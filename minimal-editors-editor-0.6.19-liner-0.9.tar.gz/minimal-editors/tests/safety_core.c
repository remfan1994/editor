/* Fault-injection regression tests for staged-save ownership/cancellation.
 * No hooks or test dependencies are part of the installed editor. */
#define _XOPEN_SOURCE 700
#if defined(__OpenBSD__)
#define _BSD_SOURCE 1
#endif
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>

static int temp_fault, sync_signal;
static char candidate_path[4096];
static int test_sync(int);
static int test_mkstemp(char *path)
{
    size_t n=strlen(path);
    int fd;
    assert(n>=6 && n<sizeof candidate_path);
    if (temp_fault) {
        int fault=temp_fault; temp_fault=0;
        if (fault==1) {
            memcpy(path+n-6,"INUSE1",6);
            /* This file belongs to the fixture, not to the caller whose
             * mkstemp failed. A failed call does not transfer ownership. */
            fd=open(path,O_WRONLY|O_CREAT|O_EXCL,0600);
            assert(fd>=0 && write(fd,"KEEP\n",5)==5 && close(fd)==0);
        }
        memcpy(candidate_path,path,n+1);
        errno=fault==1 ? EEXIST : EACCES;
        return -1;
    }
    fd=mkstemp(path);
    memcpy(candidate_path,path,strlen(path)+1);
    return fd;
}
#define mkstemp test_mkstemp
#define fsync test_sync
#define main editor_main
#ifndef EDITOR_SOURCE
#define EDITOR_SOURCE "../editor.c"
#endif
#include EDITOR_SOURCE
#undef main
#undef fsync
#undef mkstemp

static int test_sync(int fd)
{
    int result=fsync(fd);
    /* A real successful synchronization, followed by the handler flag a
     * delivered signal would leave. This intentionally does not return EINTR. */
    if (result==0 && sync_signal) {
        int sig=sync_signal; sync_signal=0; signal_controls=1;
        signal_handler(sig);
    }
    return result;
}
static char root[4096];
static unsigned groups, cases;
static int fds(void)
{
    int count=0;
    for (int fd=0;fd<1024;fd++) if (fcntl(fd,F_GETFD)>=0) count++;
    return count;
}
static void raw_file(const char *path,const char *s,size_t n)
{
    int fd=open(path,O_WRONLY|O_CREAT|O_TRUNC,0600);
    assert(fd>=0 && write_all(fd,s,n)==0 && close(fd)==0);
}
static void check_file(const char *path,const char *s,size_t n)
{
    Buffer b={0};struct stat st;
    assert(read_file(path,&b,&st));
    assert(b.n==n && (!n || !memcmp(b.s,s,n)));
    free(b.s);
}
static void reset(void)
{
    free_changes(history);history=current=history_tail=NULL;
    free(text.s);free(saved.s);free(filename);free(loaded_journal_path);
    text=(Buffer){0};saved=(Buffer){0};filename=loaded_journal_path=NULL;
    clear_prompt();reset_screen();
    for(size_t i=0;i<command_history_n;i++)free(command_history[i]);
    command_history_n=0;
    cursor=top=left=goal=0;group=goal_set=existed=false;
    journal_ignored=journal_dirty=journal_rebased=journal_branched=false;
    loaded_journal_stat_valid=false;
    signal_controls=interrupted=suspended=terminated=resized=0;
    menu_open=command_mode=filename_mode=menu_argument_mode=editing_clipboard=false;
    viewer_text=viewer_title=NULL;bind_count=0;
    selected_clipboard[0]=0;clip_history_enabled=false;
    startup_config_error=0;startup_sync_warning=false;
    startup_movement=startup_esc_menu=startup_mouse=startup_signals=false;
    temp_fault=sync_signal=0;candidate_path[0]=0;
}
static char *prepare(const char *kind,bool present)
{
    char home[4096];char *dest=NULL;
    struct stat st;
    int n=snprintf(home,sizeof home,"%s/case-%u-XXXXXX",root,++cases);
    assert(n>0 && (size_t)n<sizeof home && mkdtemp(home));
    reset();
    assert(chdir(home)==0 && setenv("HOME",home,1)==0);
    assert(unsetenv("XDG_CONFIG_HOME")==0 && unsetenv("XDG_STATE_HOME")==0);
    filename=resolve_path("document.txt");assert(filename);
    assert(copy_buffer(&text,"",0) && copy_buffer(&saved,"",0));
    if(!strcmp(kind,"document") && present) {
        raw_file(filename,"original",8);
        assert(copy_buffer(&text,"original",8) && copy_buffer(&saved,"original",8));
        assert(stat(filename,&original)==0);existed=true;
    }
    if(!strcmp(kind,"document")) dest=strdup(filename);
    else if(!strcmp(kind,"keys")) {
        dest=keymap_path(true);assert(dest);
        if(present)raw_file(dest,"# old keymap\nbind F3 write\n",26);
        load_bindings();
        assert(binding_assign("F2","write"));
    } else if(!strcmp(kind,"journal")) {
        dest=journal_path(filename);assert(dest);
        if(present)assert(journal_save());
    } else if(!strcmp(kind,"clipboard")) {
        dest=clipboard_path(true);assert(dest);
        if(present)raw_file(dest,"original clip",13);
    } else if(!strcmp(kind,"config")) {
        dest=config_path("config",true);assert(dest);
        if(present)raw_file(dest,"# retain\nmouse=off\n",19);
    } else assert(0);
    assert(dest && edit(text.n,0,"draft",5,false));
    if(present)assert(lstat(dest,&st)==0);
    return dest;
}
static bool invoke(const char *kind,const char *dest)
{
    if(!strcmp(kind,"document")) {save_file(NULL,false);return !changed();}
    if(!strcmp(kind,"keys"))return save_bindings();
    if(!strcmp(kind,"journal"))return journal_save();
    if(!strcmp(kind,"clipboard"))return private_write(dest,"new clip",8,false);
    if(!strcmp(kind,"config"))return save_preference(SETTING_MOUSE,1);
    assert(0);return false;
}
static int one_case(const char *kind,bool present,int fault,int sig)
{
    char *dest=prepare(kind,present);
    Buffer disk={0},draft={0};struct stat before,after;
    Change *was_current=current,*was_head=history;
    size_t was_cursor=cursor;
    int descriptors=fds(),error;
    bool okay,retained=true,result;
    assert(copy_buffer(&draft,text.s,text.n));
    if(present)assert(read_file(dest,&disk,&before));
    temp_fault=fault;sync_signal=sig;
    result=invoke(kind,dest);error=errno;
    assert(!temp_fault && !sync_signal);
    if(sig)assert(interrupted || suspended || terminated);
    interrupted=suspended=terminated=0;
    if(fault==1) {
        retained=lstat(candidate_path,&after)==0;
        if(retained)check_file(candidate_path,"KEEP\n",5);
    } else assert(lstat(candidate_path,&after)<0 && errno==ENOENT);
    if(present) {
        okay=lstat(dest,&after)==0 && same_disk_version(&before,&after);
        if(okay)check_file(dest,disk.s,disk.n);
    } else okay=lstat(dest,&after)<0 && errno==ENOENT;
    okay=okay && !result && retained && current==was_current && history==was_head &&
        cursor==was_cursor && text.n==draft.n && !memcmp(text.s,draft.s,draft.n) &&
        fds()==descriptors;
    if(strcmp(kind,"document"))
        okay=okay && error==(fault==1?EEXIST:fault==2?EACCES:EINTR);
    if(!okay)fprintf(stderr,"FAIL %s present=%d fault=%d signal=%d: result=%d foreign-retained=%d errno=%d\n",
                     kind,present,fault,sig,result,retained,error);
    if(retained && fault==1)assert(unlink(candidate_path)==0);
    if(okay) {
        /* Recovery is not merely an error message: retry succeeds using the
         * same text/history, without reopening or losing the draft. */
        assert(invoke(kind,dest));
        assert(lstat(dest,&after)==0 && S_ISREG(after.st_mode));
        if(!strcmp(kind,"document")) {
            check_file(dest,draft.s,draft.n);
            assert(history_step(false) && history_step(true));
            assert(text.n==draft.n && !memcmp(text.s,draft.s,draft.n));
        }
        assert(fds()==descriptors);
    }
    free(disk.s);free(draft.s);free(dest);reset();
    return okay ? 0 : 1;
}
static int run_group(const char *kind,bool signals)
{
    static const int sigs[]={SIGINT,SIGTSTP,SIGTERM};
    int failed=0;
    for(int existing=0;existing<=1;existing++) {
        if(signals)for(size_t i=0;i<sizeof sigs/sizeof *sigs;i++)
            failed+=one_case(kind,existing!=0,0,sigs[i]);
        else for(int fault=1;fault<=2;fault++)
            failed+=one_case(kind,existing!=0,fault,0);
    }
    printf("%s %u - %s %s (existing/new targets, exact draft and recovery)\n",
           failed ? "FAIL" : "ok",++groups,kind,signals?"cancellation":"temporary failures");
    return failed;
}
int main(int argc,char **argv)
{
    const char *base=getenv("EDITOR_TEST_ROOT");
    const char *kinds[]={"document","journal","keys","clipboard","config"};
    int n=snprintf(root,sizeof root,"%s/editor-safety-XXXXXX",base?base:"/tmp");
    int failed=0;
    assert(n>0 && (size_t)n<sizeof root && mkdtemp(root));
    if(argc==2) {
        bool signals=!strncmp(argv[1],"cancel-",7);
        failed=run_group(signals?argv[1]+7:argv[1],signals);
    } else {
        for(size_t i=0;i<sizeof kinds/sizeof *kinds;i++) {
            failed+=run_group(kinds[i],false);
            failed+=run_group(kinds[i],true);
        }
    }
    printf("%s: %u safety groups, %u injected save cases.\n",failed?"FAILED":"PASS",groups,cases);
    return failed?1:0;
}
