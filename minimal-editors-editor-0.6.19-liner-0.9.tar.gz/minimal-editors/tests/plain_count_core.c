/* Development-only: exact capacity boundary and cached record counting. */
#define main editor_main
#include "../editor.c"
#undef main
#include <assert.h>

static size_t reference_count(void)
{
    size_t i,n=0;
    for (i=0;i<text.n;i++) if (text.s[i]=='\n') n++;
    return n+(text.n && text.s[text.n-1]!='\n');
}
static unsigned rng=2105;
static unsigned next(void)
{
    rng^=rng<<13; rng^=rng>>17; rng^=rng<<5; return rng;
}
int main(void)
{
    Buffer b={0};
    size_t i;
    assert(reserve(&b,LIMIT+1) && b.cap==LIMIT+1);
    assert(reserve(&b,LIMIT+2) && b.cap>=LIMIT+2);
    free(b.s);
    assert(copy_buffer(&text,"a\r\nb\n",5));
    plain_newlines=count_lf(text.s,text.n); plain_count_active=true;
    for(i=0;i<20000;i++) {
        size_t at=next()%(text.n+1),old=next()%(text.n-at+1);
        const char *s=next()%2 ? "q\n" : "\r\n\n";
        size_t n=next()%(strlen(s)+1);
        assert(edit(at,old,s,n,false));
        assert(plain_count()==reference_count());
        if (next()%3==0 && current) {
            assert(history_step(false)); assert(plain_count()==reference_count());
            assert(history_step(true)); assert(plain_count()==reference_count());
        }
    }
    free_changes(history);free(text.s);
    puts("PASS exact document capacity and 20000 randomized cache splices with undo/redo");
    return 0;
}
