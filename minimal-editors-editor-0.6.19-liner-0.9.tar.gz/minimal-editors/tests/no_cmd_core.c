/* Exercise the last execution boundary without relying on UI dispatch. */
#define main editor_program_entry
#include "../editor.c"
#undef main
#include <assert.h>
int main(void)
{
#ifndef EDITOR_NO_CMD
    Buffer output={0};
    char report[256];
    no_cmd=true;
    assert(!process_capture("printf NO", "input", 5, 64,
                            &output,report,sizeof report));
    assert(errno==EPERM && output.n==0 && output.s==NULL);
    assert(!strcmp(report,cmd_disabled));
#endif
    assert(!insert_shell_output("printf NO",0,0,false));
    assert(errno==EPERM && !strcmp(message,cmd_disabled) && text.n==0);
    assert(!execute_script_step("capture printf NO"));
    assert(!strcmp(message,cmd_disabled));
    command_set("pipe-document printf NO"); execute();
    assert(!strcmp(message,cmd_disabled) && text.n==0);
    puts("PASS direct no-cmd policy boundaries");
    return 0;
}
