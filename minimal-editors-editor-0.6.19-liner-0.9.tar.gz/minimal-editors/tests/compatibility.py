#!/usr/bin/env python3
"""Optional cross-release test: python3 tests/compatibility.py OLD NEW.

Both executable paths must be trusted local editor builds. This uses an
isolated temporary home, not the user's files or editor state.
"""
import argparse
from pathlib import Path
import tempfile
import subprocess
from terminal import Session


def exercise(binary, home, path, action, expected):
    session = Session(binary, home, [path])
    try:
        if action == 'insert':
            session.send(b'A')
        else:
            session.command(action)
        session.command('write')
        session.wait_file(path, expected)
        session.finish()
    except BaseException:
        session.kill()
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('old')
    parser.add_argument('new')
    args = parser.parse_args()
    old = str(Path(args.old).resolve(strict=True))
    new = str(Path(args.new).resolve(strict=True))
    with tempfile.TemporaryDirectory(prefix='editor-compat-') as temp:
        home = Path(temp)
        path = home / 'sample'
        path.write_bytes(b'base\r\n')
        exercise(new, home, path, 'insert', b'Abase\r\n')
        exercise(old, home, path, 'undo', b'base\r\n')
        exercise(new, home, path, 'redo', b'Abase\r\n')
        exercise(old, home, path, 'undo', b'base\r\n')
        exercise(new, home, path, 'redo', b'Abase\r\n')
    versions = [subprocess.check_output([binary, '--version'], text=True).strip()
                for binary in (old, new)]
    print('PASS: ' + ' / '.join(versions) +
          ' cross-session journal compatibility in both directions')


if __name__ == '__main__':
    main()
