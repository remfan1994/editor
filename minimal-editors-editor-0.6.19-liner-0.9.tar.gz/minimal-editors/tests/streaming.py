#!/usr/bin/env python3
"""Development-only streaming, memory and long-session regression tests.
Run: python3 tests/streaming.py /path/to/editor [--busybox]
No runtime dependency on Python or BusyBox is added.
"""
import os
from pathlib import Path
import random
import resource
import shutil
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parent.parent
editor = str(Path(sys.argv[1]).resolve())
liner = ['/bin/sh', str(root / 'liner.sh'), '--plain']
checks = 0

def check(name, ok):
    global checks
    assert ok, name
    checks += 1
    print('PASS ' + name, flush=True)


def split_records(data):
    # A final LF terminates a record rather than creating a phantom one.
    records = []
    parts = data.split(b'\n')
    for p in parts[:-1]:
        if p.endswith(b'\r'):
            records.append((p[:-1], b'\r\n'))
        else:
            records.append((p, b'\n'))
    if parts[-1]:
        records.append((parts[-1], b''))
    return records


def model(data, op, first, last, repl):
    records = split_records(data)
    style = next((ending for _, ending in records if ending), b'\n')
    unterminated = bool(records and not records[-1][1])
    if op == 'change':
        e = records[first - 1][1]
        records[first - 1:first] = [(x, style) for x in repl[:-1]] + [(repl[-1], e)]
    elif op == 'insert':
        addition = [(x, style) for x in repl]
        if first == len(records) + 1 and unterminated:
            records[-1] = (records[-1][0], style)
            if repl[-1]:
                addition[-1] = (repl[-1], b'')
        records[first - 1:first - 1] = addition
    else:
        eof = last == len(records)
        del records[first - 1:last]
        if eof and unterminated and records:
            records[-1] = (records[-1][0], b'')
    if records and records[-1] == (b'', b''):
        records[-1] = (b'', style)
    return b''.join(a + b for a, b in records)


def limit_address():
    resource.setrlimit(resource.RLIMIT_AS, (64 * 1024 * 1024,) * 2)


def run(cmd, data=b'', **kwargs):
    return subprocess.run(cmd, input=data, env=env, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, timeout=90, **kwargs)


with tempfile.TemporaryDirectory(prefix='editor-streaming-') as tmp:
    home = Path(tmp)
    env = dict(os.environ, HOME=tmp, TMPDIR=tmp, TERM='dumb', LC_ALL='C',
               XDG_CONFIG_HOME=tmp + '/config', XDG_STATE_HOME=tmp + '/state')
    f = home / 'document'
    fixture = b'x\n' * 2000000
    f.write_bytes(fixture)
    r = run(liner + [str(f)], b'change 1\ny\nundo\nredo\nwrite\nquit\n', preexec_fn=limit_address)
    check('liner edits two million records under 64 MiB address-space limit',
          r.returncode == 0 and not r.stderr and f.read_bytes() == b'y' + fixture[1:])
    # Old awk sprintf limits and quadratic concatenation made long lines fail.
    fixture = b'x' * (8 * 1024 * 1024)
    f.write_bytes(fixture)
    r = run(liner + [str(f)], b'show 1\nquit\n')
    check('liner displays maximum-size ASCII record without truncation',
          r.returncode == 0 and not r.stderr and b'     1  ' + fixture + b'\n' in r.stdout)
    fixture = b'a\\\t\x1b\xff' * 10000 + b'\r\n'
    f.write_bytes(fixture)
    r = run(liner + [str(f)], b'show 1\nshow 1 2\nquit\n')
    expected = b'     1  ' + b'a\\\\\\t\\x1B\\xFF' * 10000 + b'\n'
    check('chunked escaped display is exact and invalid range prints no partial record',
          r.returncode == 0 and r.stdout.count(expected) == 1 and b'\x1b' not in r.stdout and
          b'Line range must be between 1 and 1.' in r.stderr)
    # Exercise the exact production engine, including multiline draft records
    # (the normal plain UI deliberately accepts only a single draft line).
    script = (root / 'liner.sh').read_text()
    engine = script[script.index('ln_engine() {'):script.index('\nln_page_size() {')]
    (home / 'engine.sh').write_text(engine + '\nln_work=$1; ln_current=0; shift; ln_engine "$@"\n')
    rng = random.Random(0x2105)
    corpus = [b'', b'a', b'\n', b'\r\n', b'a\r\nb', b'a\n\nb', b'\n\r\na\r', b'a\r\n\xff\n']
    for _ in range(112):
        data = bytearray()
        for j in range(rng.randrange(1, 16)):
            data += rng.choice([b'', b'x', b'\t\\', b'\xff', b'a\r', b'\x1b[0m'])
            data += rng.choice([b'\n', b'\r\n'])
        if rng.randrange(2):
            del data[-1:]
        corpus.append(bytes(data))
    awk_envs = [('system awk', env)]
    if '--busybox' in sys.argv:
        busybox = shutil.which('busybox')
        assert busybox, 'BusyBox requested but unavailable'
        bb = home / 'bb'; bb.mkdir()
        for name in ['awk', 'tail', 'od']:
            (bb / name).symlink_to(busybox)
        awk_envs.append(('BusyBox awk', dict(env, PATH=str(bb))))
    for label, e in awk_envs:
        cases = 0
        for initial in corpus:
            count = len(split_records(initial))
            for op in ['insert', 'change', 'delete'] if count else ['insert']:
                first = rng.randrange(1, count + (2 if op == 'insert' else 1))
                last = rng.randrange(first, count + 1) if op == 'delete' else first
                repl = [rng.choice([b'', b'Q', b'\xff', b'\t', b'\r', b'\\']) for _ in range(rng.randrange(1, 5))]
                (home / '0').write_bytes(initial)
                (home / 'input').write_bytes(b'\n'.join(repl) + b'\n')
                r = subprocess.run(['/bin/sh', str(home / 'engine.sh'), tmp, 'edit', op, str(first), str(last)],
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=e, timeout=5)
                assert r.returncode == 0 and r.stdout == model(initial, op, first, last, repl), (label, initial, op, first, last, repl, r.stdout, r.stderr)
                cases += 1
        check(label + ': %d streaming multiline/mixed-ending edits match independent model' % cases, cases >= 300)
    # The plain count cache must stay exact through insertion, deletion, undo,
    # redo and branching. Use a single large session, not independent launches.
    f.write_bytes(b'anchor\n')
    data = bytearray()
    for i in range(2000):
        data += b'insert 2\nx\nundo\nredo\ndelete 2\n'
    data += b'show 2\nshow 1\nwrite\nquit\n'
    r = run([editor, '--plain', str(f)], bytes(data))
    check('editor 8000 edit/undo/redo operations in one session',
          r.returncode == 0 and not r.stderr and f.read_bytes() == b'anchor\n' and
          r.stdout.count(b'Changed.') == 4000 and r.stdout.count(b'Line range must be between 1 and 1.') == 1)
    # A single extended liner session repeatedly changes history direction.
    f.write_bytes(b'anchor\n')
    data = b'insert 2\nx\nundo\nredo\ndelete 2\n' * 200 + b'write\nquit\n'
    r = run(liner + [str(f)], data)
    check('liner 800 edit/undo/redo operations with snapshot pruning',
          r.returncode == 0 and not r.stderr and f.read_bytes() == b'anchor\n' and
          r.stdout.count(b'Changed.') == 400 and b'Old undo states pruned' in r.stdout)
print('PASS: %d streaming/endurance checks.' % checks)
