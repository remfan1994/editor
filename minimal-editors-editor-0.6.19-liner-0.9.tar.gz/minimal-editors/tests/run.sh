#!/bin/sh
# Development checks only; the installed editor needs no Python or test tools.
set -eu
base=$(CDPATH= cd "$(dirname "$0")/.." && pwd)
work=$(mktemp -d "${TMPDIR:-/tmp}/editor-check.XXXXXXXX")
trap 'rm -rf "$work"' 0
trap 'exit 130' INT
trap 'exit 143' TERM
cc=${CC:-cc}
flags='-std=c99 -O2 -Wall -Wextra -Werror -pedantic'
if [ "${SANITIZE:-0}" = 1 ]; then
    flags='-std=c99 -O1 -g -Wall -Wextra -Werror -pedantic -fsanitize=address,undefined -fno-omit-frame-pointer'
    ASAN_OPTIONS=${ASAN_OPTIONS:-detect_leaks=1:halt_on_error=1}
    export ASAN_OPTIONS
fi
# Intentional field splitting of compiler flags; paths remain quoted.
$cc $flags "$base/editor.c" -o "$work/editor"
$cc $flags -DEDITOR_NO_CMD "$base/editor.c" -o "$work/editor-guest"
$cc $flags "$base/tests/no_cmd_core.c" -o "$work/no-cmd-core"
$cc $flags -DEDITOR_NO_CMD "$base/tests/no_cmd_core.c" -o "$work/no-cmd-core-guest"
$cc $flags "$base/tests/core.c" -o "$work/core"
$cc $flags "$base/tests/safety_core.c" -o "$work/safety-core"
$cc $flags "$base/tests/safety_driver.c" -o "$work/safety-driver"
$cc $flags "$base/tests/command_stability_core.c" -o "$work/command-stability"
$cc $flags "$base/tests/external_stability_core.c" -o "$work/external-stability"
$cc $flags "$base/tests/layout_core.c" -o "$work/layout-core"
$cc $flags "$base/tests/keymap_stability_core.c" -o "$work/keymap-stability"
EDITOR_TEST_ROOT=$work
export EDITOR_TEST_ROOT
"$work/core"
"$work/no-cmd-core"
"$work/no-cmd-core-guest"
"$work/safety-core"
"$work/command-stability"
"$work/external-stability"
"$work/layout-core"
"$work/keymap-stability"
python3 "$base/tests/terminal.py" "$work/editor"
python3 "$base/tests/reliability_terminal.py" "$work/editor"
python3 "$base/tests/signals_terminal.py" "$work/editor"
python3 "$base/tests/cli_terminal.py" "$work/editor"
python3 "$base/tests/refinement_terminal.py" "$work/editor"
python3 "$base/tests/reinforcement_terminal.py" "$work/editor"
python3 "$base/tests/startup_terminal.py" "$work/editor"
python3 "$base/tests/settings_terminal.py" "$work/editor"
python3 "$base/tests/persist_signals_terminal.py" "$work/editor"
python3 "$base/tests/toggles_terminal.py" "$work/editor"
python3 "$base/tests/paste_terminal.py" "$work/editor"
python3 "$base/tests/safety_terminal.py" "$work/safety-driver"
python3 "$base/tests/extensibility_terminal.py" "$work/editor"
python3 "$base/tests/command_stability_terminal.py" "$work/editor"
python3 "$base/tests/external_stability_terminal.py" "$work/editor"
python3 "$base/tests/paste_stability_terminal.py" "$work/editor"
python3 "$base/tests/layout_terminal.py" "$work/editor"
python3 "$base/tests/keymap_stability_terminal.py" "$work/editor"
python3 "$base/tests/no_cmd_terminal.py" "$work/editor" "$work/editor-guest"
printf '%s\n' 'All core and terminal regression checks passed.'
