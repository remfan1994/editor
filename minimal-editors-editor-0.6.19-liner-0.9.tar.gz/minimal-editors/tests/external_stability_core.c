/* Fault injection for external-command cancellation boundaries. Test only. */
#define _XOPEN_SOURCE 700
#if defined(__OpenBSD__)
#define _BSD_SOURCE 1
#endif
#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <poll.h>

static int pipe_calls, fork_calls, pipe_interrupt, wait_interrupt;
static int stderr_fd, flood_reads, flood_enabled;
static int poll_fault;
static int fork_fault, wait_lost, ownership_lost, kill_calls;
static int test_pipe(int fds[2]);
static pid_t test_fork(void);
static ssize_t test_read(int fd, void *buf, size_t length);
static pid_t test_waitpid(pid_t pid, int *status, int options);
static int test_poll(struct pollfd *fds, nfds_t count, int timeout);
static int test_kill(pid_t pid, int sig);
#define pipe test_pipe
#define fork test_fork
#define read test_read
#define waitpid test_waitpid
#define poll test_poll
#define kill test_kill
#define main editor_main
#ifndef EDITOR_SOURCE
#define EDITOR_SOURCE "../editor.c"
#endif
#include EDITOR_SOURCE
#undef main
#undef pipe
#undef fork
#undef read
#undef waitpid
#undef poll
#undef kill

static int test_pipe(int fds[2])
{
    int result=pipe(fds);
    if (result==0) {
        if (++pipe_calls==2) stderr_fd=fds[0];
        if (pipe_calls==pipe_interrupt) interrupted=1;
    }
    return result;
}
static pid_t test_fork(void)
{
    fork_calls++;
    if (fork_fault) {errno=EAGAIN;return -1;}
    return fork();
}
static ssize_t test_read(int fd, void *buf, size_t length)
{
    if (flood_enabled && fd==stderr_fd) {
        flood_reads++;
        if (flood_reads==40) interrupted=1;
        /* A deterministic stand-in for a pipe kept continuously readable.
         * Cap the faulty baseline too, so a regression cannot hang tests. */
        if (flood_reads>60) {errno=EIO;return -1;}
        memset(buf,'x',length);
        return (ssize_t)length;
    }
    return read(fd,buf,length);
}
static pid_t test_waitpid(pid_t pid, int *status, int options)
{
    pid_t result=waitpid(pid,status,options);
    if (wait_lost && result==pid) {
        wait_lost=0;ownership_lost=1;errno=ECHILD;return -1;
    }
    if (wait_interrupt && result==pid) {wait_interrupt=0;interrupted=1;}
    return result;
}
static int test_poll(struct pollfd *fds, nfds_t count, int timeout)
{
    if (poll_fault==1) {
        poll_fault=0;suspended=1;errno=EINTR;return -1;
    }
    if (poll_fault==2 && count) {
        poll_fault=0;assert(close(fds[0].fd)==0);
    }
    return poll(fds,count,timeout);
}
static int test_kill(pid_t pid, int sig)
{
    kill_calls++;
    if (ownership_lost) return 0; /* Never signal a potentially recycled PID. */
    return kill(pid,sig);
}
static int descriptor_count(void)
{
    int count=0;
    for (int fd=0;fd<256;fd++) if (fcntl(fd,F_GETFD)>=0) count++;
    return count;
}
static void reset(void)
{
    interrupted=terminated=suspended=0;
    pipe_calls=fork_calls=pipe_interrupt=wait_interrupt=0;
    flood_reads=flood_enabled=0;stderr_fd=-1;
    poll_fault=0;
    fork_fault=wait_lost=ownership_lost=kill_calls=0;
    external_cancel_notice=false;
}
int main(void)
{
    Buffer output={0};
    char report[256], directory[]="/tmp/editor-external-core-XXXXXXXX";
    int before=descriptor_count();
    assert(mkdtemp(directory) && chdir(directory)==0);
    for (int which=0;which<3;which++) {
        reset();
        if (which==0) interrupted=1;
        if (which==1) terminated=SIGTERM;
        if (which==2) suspended=1;
        assert(!process_capture("touch must-not-execute",NULL,0,1024,
                                &output,report,sizeof report));
        assert(fork_calls==0 && pipe_calls==0 && access("must-not-execute",F_OK)<0);
        assert(strstr(report,"interrupted") && descriptor_count()==before);
    }
    puts("PASS external-pending-signals-prevent-launch");

    reset();pipe_interrupt=2;
    assert(!process_capture("touch must-not-execute","input",5,1024,
                            &output,report,sizeof report));
    assert(pipe_calls==2 && fork_calls==0 && access("must-not-execute",F_OK)<0);
    assert(strstr(report,"interrupted") && descriptor_count()==before);
    puts("PASS external-signal-during-preparation-prevents-launch");

    reset();flood_enabled=1;
    assert(!process_capture("printf diagnostic >&2; exec 1>&-; sleep 30",
                            NULL,0,1024,&output,report,sizeof report));
    assert(flood_reads==40 && strstr(report,"interrupted"));
    assert(descriptor_count()==before);
    puts("PASS external-continuous-stderr-checks-cancellation");

    reset();wait_interrupt=1;
    assert(copy_buffer(&text,"original\n",9) && copy_buffer(&saved,"original\n",9));
    assert(!insert_shell_output("printf replacement",0,text.n,true));
    assert(text.n==9 && memcmp(text.s,"original\n",9)==0 && history==NULL);
    assert(external_cancel_notice && strstr(message,"interrupted"));
    assert(descriptor_count()==before);
    puts("PASS external-signal-before-commit-preserves-document");

    reset();poll_fault=1;
    assert(!process_capture("sleep 30",NULL,0,1024,&output,report,sizeof report));
    assert(strstr(report,"interrupted") && descriptor_count()==before);
    puts("PASS external-poll-eintr-honors-suspension");

    reset();poll_fault=2;
    assert(!process_capture("sleep 30",NULL,0,1024,&output,report,sizeof report));
    assert(strstr(report,"output discarded") && descriptor_count()==before);
    puts("PASS external-invalid-pipe-cleans-up-child-and-descriptors");

    reset();
    assert(process_capture("printf '\\033[31m\\001warning\\n%400s' x >&2; printf OUT",
                           NULL,0,1024,&output,report,sizeof report));
    assert(output.n==3 && !memcmp(output.s,"OUT",3));
    assert(strlen(report)<sizeof report && !strchr(report,'\033'));
    assert(strstr(report,"stderr:") && strstr(report,"warning"));
    assert(descriptor_count()==before);
    puts("PASS external-stderr-is-bounded-and-controls-sanitized");

    {
        struct sigaction original_action, wanted, actual;
        assert(sigaction(SIGCHLD,NULL,&original_action)==0);
        for (int mode=0;mode<2;mode++) {
            memset(&wanted,0,sizeof wanted);sigemptyset(&wanted.sa_mask);
            wanted.sa_handler=mode==0 ? SIG_IGN : SIG_DFL;
#ifdef SA_NOCLDWAIT
            if (mode==1) wanted.sa_flags=SA_NOCLDWAIT;
#else
            if (mode==1) continue;
#endif
            assert(sigaction(SIGCHLD,&wanted,NULL)==0);
            for (int failure=0;failure<3;failure++) {
                reset();free(output.s);output=(Buffer){0};
                if (failure==1) pipe_interrupt=2;
                if (failure==2) fork_fault=1;
                assert(process_capture("printf OK",NULL,0,1024,
                                       &output,report,sizeof report)==(failure==0));
                if (!failure) assert(output.n==2 && !memcmp(output.s,"OK",2));
                assert(sigaction(SIGCHLD,NULL,&actual)==0);
                assert(actual.sa_handler==wanted.sa_handler);
#ifdef SA_NOCLDWAIT
                assert((actual.sa_flags&SA_NOCLDWAIT)==(wanted.sa_flags&SA_NOCLDWAIT));
#endif
                assert(descriptor_count()==before);
            }
        }
        assert(sigaction(SIGCHLD,&original_action,NULL)==0);
    }
    puts("PASS external-inherited-child-signal-policy-restored-on-success-and-error");

    reset();free(output.s);output=(Buffer){0};wait_lost=1;
    assert(!process_capture("printf OK",NULL,0,1024,&output,report,sizeof report));
    assert(ownership_lost && kill_calls==0 && descriptor_count()==before);
    puts("PASS external-lost-child-ownership-never-signals-recycled-pid");
    reset();free(output.s);free(text.s);free(saved.s);
    assert(chdir("/")==0 && rmdir(directory)==0);
    puts("PASS 9 external-process cancellation groups");
    return 0;
}
