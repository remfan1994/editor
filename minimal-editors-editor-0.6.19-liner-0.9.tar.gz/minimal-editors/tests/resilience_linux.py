from pathlib import Path
import os, subprocess, tempfile, pty, termios, select, time, re, sys
base=Path(__file__).resolve().parent.parent; ed=str(Path(sys.argv[1]).resolve()); liner=str(base/'liner.sh'); count=0

def check(label, condition):
    global count
    assert condition, label
    count+=1; print('PASS '+label,flush=True)

def run(cmd, data=b'', env=None, **kw):
    return subprocess.run(cmd,input=data,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40,**kw)

with tempfile.TemporaryDirectory(prefix='resilience-') as tmp:
    home=Path(tmp); env=dict(os.environ,HOME=tmp,XDG_CONFIG_HOME=tmp+'/config',XDG_DATA_HOME=tmp+'/data',XDG_STATE_HOME=tmp+'/.local/state',TMPDIR=tmp,TERM='dumb',LC_ALL='C')
    bb=home/'bb'; bb.mkdir(); util=['awk','cat','chmod','cmp','cp','ln','ls','mktemp','mv','od','rm','tail','tr','wc','sh','dd','mkfifo','stty']
    for name in util: (bb/name).symlink_to('/usr/bin/busybox')
    minimal=home/'minimal'; minimal.mkdir()
    for name in util[:-3]: (minimal/name).symlink_to('/usr/bin/busybox')
    setups=[('dash',['/usr/bin/dash',liner,'--plain'],env),('bash POSIX',['/usr/bin/bash','--posix',liner,'--plain'],env),('BusyBox-only',['/usr/bin/busybox','ash',liner,'--plain'],dict(env,PATH=str(bb))),('minimal PATH',['/usr/bin/busybox','ash',liner],dict(env,PATH=str(minimal))),('editor',[ed,'--plain'],env)]
    for i,(name,cmd,e) in enumerate(setups):
        f=home/('test'+str(i)); f.write_bytes(b'a\r\nb')
        r=run(cmd+[str(f)],b'page\nchange 2\nc\ninsert 3\nd\nundo\nredo\nwrite\nquit\n',e)
        check(name+' exact CRLF and no-final-LF edit/undo/redo',r.returncode==0 and f.read_bytes()==b'a\r\nc\r\nd' and b'\x1b' not in r.stdout)
        # NUL source refused before editing.
        f.write_bytes(b'a\0b'); r=run(cmd+[str(f)],b'quit\n',e)
        check(name+' rejects NUL input file',r.returncode!=0 and f.read_bytes()==b'a\0b')
        # Preserve unrelated existing destination.
        f.write_bytes(b'a\n'); other=home/('other'+str(i)); other.write_bytes(b'outside')
        r=run(cmd+[str(f)],b'change 1\nnew\nwrite '+os.fsencode(other)+b'\nquit!\n',e)
        check(name+' refuses unrelated existing save target',r.returncode==0 and f.read_bytes()==b'a\n' and other.read_bytes()==b'outside')
        # No control bytes from display of an arbitrary text file.
        f.write_bytes(b'\x1b[31m\t\xff\n'); r=run(cmd+[str(f)],b'page\nquit\n',e)
        check(name+' escapes hostile document bytes',r.returncode==0 and b'\x1b' not in r.stdout and b'\\x1B' in r.stdout and b'\\xFF' in r.stdout)
    for name,cmd,e in setups[:-1]:
        args=cmd[:-1] if cmd[-1]=='--plain' else cmd
        r=run(args+['--check'],env=e); check(name+' utility probe',r.returncode==0 and b'PASS' in r.stdout)
    r=run([ed,'--check'],env=env); check('editor check',r.returncode==0 and b'Plain mode: available' in r.stdout)
    # Reopen history shared by plain and existing full-screen journal code.
    f=home/'journal'; f.write_bytes(b'base\n'); assert run([ed,'--plain',str(f)],b'change 1\nnew\nwrite\nquit\n',env).returncode==0
    r=run([ed,'--plain',str(f)],b'undo\nwrite\nquit\n',env); check('editor plain persistent undo',r.returncode==0 and f.read_bytes()==b'base\n')
    r=run([ed,'--plain'],b'insert 1\nrecover me\n',env); paths=list((home/'.local/state/editor').glob('editor-recovery.*'))
    check('editor dirty EOF recovery exact bytes and private mode',r.returncode==1 and len(paths)==1 and paths[0].read_bytes()==b'recover me\n' and paths[0].stat().st_mode & 0o777==0o600)
    r=run([ed,'--plain'],b'insert 1\npartial',env); check('editor incomplete draft cancelled',r.returncode==1 and len(list((home/'.local/state/editor').glob('editor-recovery.*')))==1)
    r=run([ed,'--plain'],b'\x00quit!\n'+b'x'*4100+b'\ninsert 1\nOK\nwrite '+os.fsencode(home/'valid')+b'\nquit\n',env)
    check('editor discards NUL/oversize commands through LF',r.returncode==0 and (home/'valid').read_bytes()==b'OK\n' and r.stdout.count(b'Input refused')==2)
    # Interactive fallback must not touch termios or use escape codes.
    for idx,(name,cmd,e) in enumerate([('liner TERM=dumb',['/bin/sh',liner],env),('liner missing optional utilities',['/usr/bin/busybox','ash',liner],dict(env,TERM='xterm',PATH=str(minimal))),('liner --plain',['/bin/sh',liner,'--plain'],dict(env,TERM='xterm')),('editor --plain',[ed,'--plain'],env)]):
        f=home/('pty'+str(idx)); f.write_bytes(b'x\n'*40); master,slave=pty.openpty(); before=termios.tcgetattr(slave)
        proc=subprocess.Popen(cmd+[str(f)],stdin=slave,stdout=slave,stderr=slave,env=e)
        os.write(master,b'page\nchange 1\ny\nwrite\nquit\n'); out=b''; deadline=time.monotonic()+10
        while time.monotonic()<deadline:
            ready,_,_=select.select([master],[],[],0.1)
            if ready: out+=os.read(master,65536)
            if proc.poll() is not None and not ready: break
        if proc.poll() is None: proc.kill()
        proc.wait(); after=termios.tcgetattr(slave); os.close(slave);os.close(master)
        check(name+' PTY plain fallback keeps terminal settings',proc.returncode==0 and before==after and b'\x1b' not in out and f.read_bytes()==b'y\n'+b'x\n'*39)
    f=home/'bounded'; f.write_bytes(b'0\n')
    data=b''.join(b'change 1\n'+str(n).encode()+b'\n' for n in range(1,141))+b'undo\n'*140+b'write\nquit\n'
    r=run(['/bin/sh',liner,'--plain',str(f)],data,env)
    check('liner 128-state cap and earliest reachable state',r.returncode==0 and f.read_bytes()==b'12\n' and r.stdout.count(b'Nothing to undo.')==12)
    # Exercise the actual 64 MiB budget with 4 MiB documents.
    f=home/'byte-cap'; f.write_bytes(b'x'*4194304)
    data=b'insert 1\na\n'*17+b'undo\n'*17+b'write\nquit\n'
    r=run(['/bin/sh',liner,'--plain',str(f)],data,env)
    check('liner 64 MiB snapshot budget',r.returncode==0 and f.read_bytes()==b'a\n'*3+b'x'*4194304 and r.stdout.count(b'Nothing to undo.')==3)
    f=home/'branch'; f.write_bytes(b'0\n'); data=b'change 1\n1\nchange 1\n2\nundo\nchange 1\n3\nredo\nwrite\nquit\n'
    r=run(['/bin/sh',liner,'--plain',str(f)],data,env); check('liner redo branch prunes correctly',r.returncode==0 and f.read_bytes()==b'3\n' and b'Nothing to redo.' in r.stdout)
    # Check failed temporary allocation and missing dependency diagnostic.
    r=run(['/bin/sh',liner,'--check'],env=dict(env,TMPDIR=tmp+'/absent')); check('liner unavailable TMPDIR fails clearly',r.returncode!=0 and b'Cannot create private temporary directory' in r.stderr)
    r=run(['/bin/sh',liner,'--check'],env=dict(env,PATH=tmp+'/absent')); check('liner missing utility fails clearly',r.returncode!=0 and b'Missing required utility: awk' in r.stderr)
print('PASS: %d resilience checks.'%count)
