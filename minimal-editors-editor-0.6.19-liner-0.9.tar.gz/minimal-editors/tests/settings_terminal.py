#!/usr/bin/env python3
"""Single Esc toggle and Help > Settings workflows in real pseudo-terminals."""
import argparse
from pathlib import Path
import tempfile
from terminal import Session
from startup_terminal import config


def quit_from_menu(s):
    # A root menu and one-off command prompt; do not change the saved preference.
    s.send(b'\x1b8\rquit!\r')
    s.finish()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('binary')
    binary=str(Path(parser.parse_args().binary).resolve())
    count=0
    with tempfile.TemporaryDirectory(prefix='editor-settings-') as t:
        root=Path(t)
        def run(name,fn):
            nonlocal count
            home=root/name;home.mkdir();fn(home)
            count+=1;print(f'ok {count} - {name}',flush=True)

        def command(home):
            cfg=config(home,b'# retain\nstartup=movement\nsignal_controls=off\n')
            doc=home/'doc';doc.write_bytes(b'base\n')
            s=Session(binary,home,[doc])
            try:
                s.command('toggle-esc')
                s.wait_file(cfg,b'# retain\nstartup=movement\nsignal_controls=off\nesc=menu\n')
                s.send(b'!') # Esc preference must not change movement mode.
                s.send(b'\x1b8\rwrite\r');s.wait_file(doc,b'base\n')
                quit_from_menu(s)
            except BaseException:s.kill();raise
            s=Session(binary,home,[doc])
            try:
                s.send(b'\x1b8\rtoggle-esc\r')
                s.wait_file(cfg,b'# retain\nstartup=movement\nsignal_controls=off\nesc=cli\n')
                s.command('edit');s.send(b'X');s.command('write');s.wait_file(doc,b'Xbase\n');s.finish()
            except BaseException:s.kill();raise
        run('toggle-command-persists-and-does-not-change-movement',command)

        def nested(home):
            cfg=config(home,b'startup=edit\nesc=menu\n');doc=home/'doc';doc.write_bytes(b'base\n')
            s=Session(binary,home,[doc])
            try:
                s.send(b'\x1b7\r7\r');s.wait_output(b'Start in: Edit');s.wait_output(b'Esc opens: Menu')
                s.send(b'2\r');s.wait_file(cfg,b'startup=edit\nesc=cli\n');s.wait_output(b'Esc opens: Command line')
                s.send(b'1\r');s.wait_file(cfg,b'startup=movement\nesc=cli\n');s.wait_output(b'Start in: Movement')
                s.send(b'6\r');s.wait_output(b'User hotkeys');s.send(b'h');s.wait_output(b'Settings')
                s.send(b'hh');s.send(b'8\r') # Settings -> Help -> root -> one-off CLI.
                s.send(b'\rX');s.command('write');s.wait_file(doc,b'Xbase\n');s.finish()
            except BaseException:s.kill();raise
        run('nested-menu-single-setting-labels-and-parent-navigation',nested)

        def overrides(home):
            cfg=config(home,b'startup=movement\nesc=menu\n');doc=home/'doc';doc.write_bytes(b'base\n')
            s=Session(binary,home,['--cli','--edit',doc])
            try:
                s.send(b'X');s.command('write');s.wait_file(doc,b'Xbase\n');s.finish()
                assert cfg.read_bytes()==b'startup=movement\nesc=menu\n'
            except BaseException:s.kill();raise
            # Toggle is based on the visible interface, even with a launch override.
            cfg.write_bytes(b'startup=edit\nesc=cli\n')
            s=Session(binary,home,['--cli','--menu',doc])
            try:
                s.send(b'\x1b8\rtoggle-esc\r');s.wait_output(b'Esc opens: Command line (saved)')
                assert cfg.read_bytes()==b'startup=edit\nesc=cli\n'
                s.finish()
            except BaseException:s.kill();raise
        run('one-launch-overrides-remain-independent-of-saved-values',overrides)

        def failure(home):
            cfg=config(home,b'startup=edit\nesc=cli\n');cfg.chmod(0o444)
            doc=home/'doc';doc.write_bytes(b'base\n');s=Session(binary,home,[doc])
            try:
                s.command('toggle-esc');s.wait_output(b'Esc setting NOT saved')
                assert cfg.read_bytes()==b'startup=edit\nesc=cli\n'
                s.send(b'q\x1bX');s.command('write');s.wait_file(doc,b'Xbase\n')
                cfg.chmod(0o644)
                s.command('toggle-esc');s.wait_file(cfg,b'startup=edit\nesc=menu\n')
                quit_from_menu(s)
            except BaseException:s.kill();raise
        run('failed-setting-save-keeps-config-and-live-interface',failure)

        def narrow(home):
            cfg=config(home,b'startup=edit\nesc=cli\n');s=Session(binary,home,[],rows=3,cols=12)
            try:
                s.command('settings');s.wait_output(b'Start E')
                s.send(b'2\r');s.wait_file(cfg,b'startup=edit\nesc=menu\n');s.wait_output(b'Esc Menu')
                s.send(b'1\r');s.wait_file(cfg,b'startup=movement\nesc=menu\n');s.wait_output(b'Start M')
                s.send(b'\x1b\x1b8\rquit!\r');s.finish()
            except BaseException:s.kill();raise
        run('settings-values-and-numeric-toggles-on-12-by-3-terminal',narrow)

        def help_completion(home):
            cfg=config(home,b'startup=edit\nesc=cli\n');s=Session(binary,home,[])
            try:
                s.command('help');s.wait_output(b'PROGRAM SETTINGS');s.send(b'q')
                s.send(b'help toggle-esc\r');s.wait_output(b'Menu and Command line');s.send(b'q')
                s.send(b'toggle-e\t');s.wait_output(b'toggle-esc')
                assert cfg.read_bytes()==b'startup=edit\nesc=cli\n'
                s.send(b'\r');s.wait_file(cfg,b'startup=edit\nesc=menu\n')
                s.send(b'\x1b8\rtoggle-esc\r');s.wait_file(cfg,b'startup=edit\nesc=cli\n')
                # menu opens once; cli remains retired, not a toggle alias.
                mark=len(s.data);s.command('menu');s.wait_output(b'Menu 1/9',start=mark);s.send(b'h')
                s.command('cli');s.wait_output(b'Command not found');s.send(b'q\x1b')
                assert cfg.read_bytes()==b'startup=edit\nesc=cli\n'
                s.command('preferences');s.wait_output(b'Settings')
                s.send(b'\x1b\x1b8\rquit!\r');s.finish()
            except BaseException:s.kill();raise
        run('help-completion-and-one-time-menu-command',help_completion)

        def apply(home):
            cfg=config(home,b'startup=edit\nesc=cli\n');doc=home/'doc';doc.write_bytes(b'base\n')
            s=Session(binary,home,[doc])
            try:
                s.send(b'X');before=cfg.stat();s.command('menu');s.wait_output(b'Menu 1/9');assert cfg.stat().st_ino==before.st_ino
                s.send(b'7\r7\r');s.wait_output(b'Apply / Return to editor');s.send(b'1\r');s.wait_file(cfg,b'startup=movement\nesc=cli\n')
                before=cfg.stat();s.send(b'9\r');s.wait_output(b'Settings closed. Successful changes already saved.')
                after=cfg.stat();assert (before.st_ino,before.st_mtime_ns)==(after.st_ino,after.st_mtime_ns)
                s.send(b'Y');s.command('write');s.wait_file(doc,b'XYbase\n');s.finish()
            except BaseException:s.kill();raise
            s=Session(binary,home,[doc])
            try:
                s.send(b'!');s.command('settings');s.send(b'9\r');s.send(b'!');s.command('write');s.wait_file(doc,b'XYbase\n');s.finish()
            except BaseException:s.kill();raise
        run('apply-returns-to-original-mode-without-rewriting-config',apply)

        def narrow_apply(home):
            cfg=config(home,b'startup=edit\nesc=cli\n');doc=home/'doc';doc.write_bytes(b'base\n')
            s=Session(binary,home,[doc],rows=3,cols=12)
            try:
                s.command('settings');s.wait_output(b'9 Apply');s.send(b'9\rX');s.command('write');s.wait_file(doc,b'Xbase\n');s.finish()
                assert cfg.read_bytes()==b'startup=edit\nesc=cli\n'
            except BaseException:s.kill();raise
        run('apply-visible-and-selectable-on-12-by-3',narrow_apply)

        def mouse_apply(home):
            cfg=config(home,b'startup=edit\nesc=cli\nmouse=on\n');doc=home/'doc';doc.write_bytes(b'base\n')
            s=Session(binary,home,[doc],rows=24,cols=80)
            try:
                s.command('settings');s.wait_output(b'Apply / Return to editor')
                s.send(b'\x1b[<0;5;10M');s.wait_output(b'Settings closed. Successful changes already saved.')
                s.send(b'X');s.command('write');s.wait_file(doc,b'Xbase\n');s.finish()
            except BaseException:s.kill();raise
        run('mouse-apply-returns-to-document',mouse_apply)

        def legacy_menu(home):
            cfg=config(home,b'startup=edit\nesc=cli\n');defs=cfg.parent/'commands.conf';defs.write_bytes(b'menu\tquit!\ndirlist\ttop\n')
            doc=home/'doc';doc.write_bytes(b'base\n');s=Session(binary,home,[doc])
            try:
                s.command('functions');s.wait_output(b'shadowed by built-in');s.wait_output(b'dirlist = top');s.send(b'q\r')
                s.send(b'\x1bme\t\r');s.wait_output(b'Menu 1/9');s.send(b'h');assert not s.exited()
                s.command('undefine menu');s.wait_file(defs,b'dirlist\ttop\n');s.finish()
            except BaseException:s.kill();raise
        run('old-custom-menu-definition-preserved-and-removable',legacy_menu)

        def scopes(home):
            cfg=config(home,b'startup=edit\nesc=cli\nsignal_controls=off\n')
            s=Session(binary,home,[])
            try:
                s.command('settings');s.send(b'3\r');s.wait_output(b'Mouse: On')
                s.send(b'4\r');s.wait_output(b'Signals: On (cancel)')
                s.send(b'5\r');s.wait_output(b'Clipboard history: On')
                s.wait_file(cfg,b'startup=edit\nesc=cli\nsignal_controls=on\nmouse=on\n')
                s.send(b'\x1b\x1b8\rquit!\r');s.finish()
            except BaseException:s.kill();raise
            s=Session(binary,home,[])
            try:
                s.command('settings');s.wait_output(b'Mouse: On');s.wait_output(b'Signals: On (cancel)')
                s.wait_output(b'Clipboard history: On')
                s.send(b'5\r');s.wait_output(b'Clipboard history: Off')
                s.send(b'\x1b\x1b8\rquit!\r');s.finish()
            except BaseException:s.kill();raise
        run('all-five-setting-scopes-are-visible-and-persistent',scopes)

        def clipboard(home):
            cfg=config(home,b'startup=edit\nesc=cli\n');doc=home/'doc';doc.write_bytes(b'base\n')
            s=Session(binary,home,[doc])
            try:
                s.send(b'P');s.command('copy');s.command('clipboard');s.send(b'C')
                s.command('settings');s.send(b'2\r');s.wait_file(cfg,b'startup=edit\nesc=menu\n')
                s.send(b'\x1b\x1b8\rclipboard\r')
                s.send(b'\x1b8\rwrite\r');s.wait_file(doc,b'Pbase\n')
                s.send(b'\x1b8\rundo\r');s.send(b'\x1b8\rwrite\r');s.wait_file(doc,b'base\n')
                assert (home/'state/editor/clipboard.txt').read_bytes()==b'CPbase\n'
                quit_from_menu(s)
            except BaseException:s.kill();raise
        run('settings-preserve-dirty-clipboard-parent-and-undo',clipboard)
    print(f'PASS: {count} settings terminal groups.',flush=True)

if __name__=='__main__':main()
