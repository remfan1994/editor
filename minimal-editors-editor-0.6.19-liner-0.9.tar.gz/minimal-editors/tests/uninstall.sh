#!/bin/sh
# Exercise the user-installation path in a disposable home directory.
# Pass an actual built editor (normal, stripped or no-CMD).
set -eu
if [ "$#" -ne 1 ]; then
    printf 'Usage: sh tests/uninstall.sh /path/to/built/editor\n' >&2
    exit 2
fi
case "$1" in /*) binary=$1 ;; *) binary=$PWD/$1 ;; esac
[ -f "$binary" ] && [ -x "$binary" ]
script=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)/uninstall.sh
tmp=$(mktemp -d "${TMPDIR:-/tmp}/editor-uninstall.XXXXXXXX")
trap 'rm -rf "$tmp"' EXIT
trap 'exit 1' HUP INT TERM
HOME="$tmp/home with spaces"
export HOME
mkdir -p "$HOME/.local/bin" "$HOME/.config/editor" \
    "$HOME/.local/state/editor/history" "$HOME/.local/share/man/man1"
target="$HOME/.local/bin/editor"
for path in "$HOME/.config/editor/config" "$HOME/.config/editor/keys.conf" \
    "$HOME/.config/editor/commands.conf" "$HOME/.local/state/editor/clipboard.txt" \
    "$HOME/.local/state/editor/history/sample" "$HOME/.local/state/editor/recovery.txt" \
    "$HOME/.local/bin/liner" "$HOME/.local/share/man/man1/editor.1" \
    "$HOME/.profile" "$HOME/document.txt"; do
    printf 'must remain\n' > "$path"
done

check_preserved() {
    for path in "$HOME/.config/editor/config" "$HOME/.config/editor/keys.conf" \
        "$HOME/.config/editor/commands.conf" "$HOME/.local/state/editor/clipboard.txt" \
        "$HOME/.local/state/editor/history/sample" "$HOME/.local/state/editor/recovery.txt" \
        "$HOME/.local/bin/liner" "$HOME/.local/share/man/man1/editor.1" \
        "$HOME/.profile" "$HOME/document.txt"; do
        [ "$(cat "$path")" = 'must remain' ]
    done
}
expect_failure() {
    if "$@" > "$tmp/output" 2>&1; then
        printf 'Unexpected success: %s\n' "$*" >&2
        exit 1
    fi
}

install -m 755 "$binary" "$target"
sh "$script" --dry-run | grep -F 'Would remove:'
cmp "$binary" "$target"
expect_failure sh "$script" --dry-run --yes
expect_failure sh "$script" --user --system
expect_failure sh "$script" --not-an-option
if sh "$script" </dev/null > "$tmp/output" 2>&1; then
    printf 'Unexpected noninteractive removal without --yes\n' >&2
    exit 1
fi
cmp "$binary" "$target"
sh "$script" --user --yes
[ ! -e "$target" ]
sh "$script" --yes | grep -F 'Nothing removed.'
check_preserved

# Unrelated programs must not be run or removed, even with --yes.
printf '#!/bin/sh\ntouch "%s"\n' "$tmp/executed" > "$target"
chmod 755 "$target"
expect_failure sh "$script" --yes
[ -f "$target" ] && [ ! -e "$tmp/executed" ]
rm "$target"

# Valid and dangling symbolic links are refused; no target is followed.
ln -s "$binary" "$target"
expect_failure sh "$script" --yes
[ -L "$target" ] && [ -f "$binary" ]
rm "$target"
ln -s "$tmp/nonexistent" "$target"
expect_failure sh "$script" --yes
[ -L "$target" ]
rm "$target"

mkdir "$target"
printf 'must remain\n' > "$target/file"
expect_failure sh "$script" --yes
[ -f "$target/file" ]
rm "$target/file"
rmdir "$target"
install -m 644 "$binary" "$target"
expect_failure sh "$script" --yes
[ -f "$target" ]
rm "$target"
expect_failure env HOME=relative sh "$script" --yes
expect_failure env HOME= sh "$script" --yes
check_preserved
printf 'PASS: user scope, preview, noninteractive guard, removal, repeat, preservation, invalid arguments, unrelated executable, symlinks, directory, non-executable, HOME validation\n'
