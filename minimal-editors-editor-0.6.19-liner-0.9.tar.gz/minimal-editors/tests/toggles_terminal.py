#!/usr/bin/env python3
"""Uniform switch commands: real menu, input, completion and restart checks."""
import argparse
from pathlib import Path
import tempfile
from terminal import Session
from startup_terminal import config

DEFAULT=b'startup=edit\nesc=cli\nmouse=off\nsignal_controls=off\n'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('binary')
    binary=str(Path(parser.parse_args().binary).resolve())
    count=0
    with tempfile.TemporaryDirectory(prefix='editor-uniform-toggles-') as tmp:
        root=Path(tmp)
        def run(name,fn):
            nonlocal count
            home=root/name;home.mkdir();fn(home);count+=1
            print(f'ok {count} - {name}',flush=True)

        def all_saved(home):
            cfg=config(home,DEFAULT);doc=home/'doc';doc.write_bytes(b'base\n')
            s=Session(binary,home,[doc])
            try:
                s.send(b'X')
                for cmd in ('toggle-startup','toggle-mouse','toggle-signals','toggle-cliphistory'):
                    s.command(cmd)
                s.command('toggle-esc')
                expected=b'startup=movement\nesc=menu\nmouse=on\nsignal_controls=on\n'
                s.wait_file(cfg,expected)
                s.wait_file(home/'state/editor/clipboard-history.enabled',b'on\n')
                s.send(b'Y') # Startup did not change the current edit mode.
                s.send(b'\x1b8\rwrite\r');s.wait_file(doc,b'XYbase\n')
                s.send(b'\x1b8\rquit!\r');s.finish()
            except BaseException:s.kill();raise
            s=Session(binary,home,[doc],cols=130,rows=40)
            try:
                s.wait_output(b'\x1b[?1000h')
                s.send(b'!') # Now the saved startup choice is in effect.
                s.send(b'\x1b8\rwrite\r');s.wait_file(doc,b'XYbase\n')
                s.send(b'\x1b7\r7\r')
                for text in (b'Start in: Movement',b'Esc opens: Menu',b'Mouse: On',b'Signals: On (cancel)',b'Clipboard history: On'):
                    s.wait_output(text)
                s.send(b'hh8\rquit!\r');s.finish()
                assert cfg.read_bytes()==expected
            except BaseException:s.kill();raise
        run('five-switches-save-and-survive-restart-without-changing-current-edit-mode',all_saved)

        def mouse_override(home):
            cfg=config(home,DEFAULT.replace(b'mouse=off',b'mouse=on'))
            original=cfg.read_bytes()
            s=Session(binary,home,['--no-mouse'],rows=40)
            try:
                assert b'\x1b[?1000h' not in s.data
                s.command('settings show');s.wait_output(b'Saved mouse: On');s.wait_output(b'Current mouse: Off')
                s.send(b'q\r');s.finish();assert cfg.read_bytes()==original
            except BaseException:s.kill();raise
            s=Session(binary,home,[])
            try:
                s.wait_output(b'\x1b[?1000h')
                mark=len(s.data);s.command('toggle-mouse');s.wait_output(b'\x1b[?1000l',start=mark)
                s.wait_file(cfg,DEFAULT)
                s.finish()
            except BaseException:s.kill();raise
        run('mouse-persistence-and-one-run-override-are-distinct',mouse_override)

        def narrow(home):
            cfg=config(home,DEFAULT)
            s=Session(binary,home,[],rows=3,cols=12)
            try:
                s.command('settings')
                for number,on,off in ((3,b'Mouse On',b'Mouse Off'),(4,b'Sig:On',b'Sig:Off'),(5,b'ClipH On',b'ClipH Off')):
                    mark=len(s.data);s.send(str(number).encode()+b'\r');s.wait_output(on,start=mark)
                    mark=len(s.data);s.send(str(number).encode()+b'\r');s.wait_output(off,start=mark)
                s.send(b'hh8\rquit!\r');s.finish();assert cfg.read_bytes()==DEFAULT
            except BaseException:s.kill();raise
        run('every-on-off-label-remains-readable-on-12-by-3',narrow)

        def completion(home):
            cfg=config(home,DEFAULT);s=Session(binary,home,[],cols=110,rows=35)
            try:
                s.send(b'\x1btoggle-\t');s.wait_output(b'More than one command matches')
                for name in (b'toggle-esc',b'toggle-startup',b'toggle-mouse',b'toggle-signals',b'toggle-cliphistory'):
                    s.wait_output(name)
                assert cfg.read_bytes()==DEFAULT
                s.send(b'qe\t');s.wait_output(b'Command> toggle-esc')
                assert cfg.read_bytes()==DEFAULT
                s.send(b'\r');s.wait_file(cfg,DEFAULT.replace(b'esc=cli',b'esc=menu'))
                s.send(b'\x1b8\rtoggle-esc\r');s.wait_file(cfg,DEFAULT)
                s.command('help toggle-startup');s.wait_output(b'future sessions');s.send(b'q\r');s.finish()
            except BaseException:s.kill();raise
        run('tab-and-help-explain-the-same-five-switches-without-executing-them',completion)

        def refused(home):
            cfg=config(home,DEFAULT);doc=home/'doc';doc.write_bytes(b'base\n')
            s=Session(binary,home,[doc],rows=40)
            try:
                for cmd in ('startup movement','toggle-mode','signals on','mouse on'):
                    s.command(cmd);s.wait_output(b'NO arguments');s.send(b'q\x1b')
                for cmd in ('toggle-startup movement','toggle-mouse on','toggle-signals off','toggle-esc menu','toggle-cliphistory toggle'):
                    mark=len(s.data);s.command(cmd);s.wait_output(b'takes no arguments',start=mark)
                    s.send(b'q\x1b')
                assert cfg.read_bytes()==DEFAULT
                assert not (home/'state/editor/clipboard-history.enabled').exists()
                s.send(b'X');s.command('write');s.wait_file(doc,b'Xbase\n');s.finish()
            except BaseException:s.kill();raise
        run('retired-and-mixed-syntax-cannot-toggle-or-discard-the-draft',refused)

        def failed(home):
            cfg=config(home,DEFAULT);cfg.chmod(0o444)
            s=Session(binary,home,[])
            try:
                s.command('settings');s.send(b'3\r');s.wait_output(b'Mouse setting NOT saved')
                assert cfg.read_bytes()==DEFAULT
                s.send(b'q\x1b');cfg.chmod(0o644)
                s.command('toggle-mouse');s.wait_file(cfg,DEFAULT.replace(b'mouse=off',b'mouse=on'))
                s.wait_output(b'\x1b[?1000h');s.finish()
            except BaseException:s.kill();raise
        run('failed-menu-save-stays-visible-and-retry-enables-the-mouse',failed)

        def movement(home):
            cfg=config(home,DEFAULT);doc=home/'doc';doc.write_bytes(b'base\n')
            s=Session(binary,home,[doc])
            try:
                s.send(b'\x1bsettings\rhh6\r');s.wait_output(b'Current editing: Edit')
                s.send(b'1\r');s.wait_output(b'Current editing: Movement')
                s.send(b'hh!');s.command('write');s.wait_file(doc,b'base\n')
                s.command('edit');s.send(b'X');s.command('write');s.wait_file(doc,b'Xbase\n')
                assert cfg.read_bytes()==DEFAULT
                s.finish()
            except BaseException:s.kill();raise
        run('one-current-movement-menu-row-keeps-saved-startup-unchanged',movement)
    print(f'PASS: {count} uniform-toggle terminal groups.',flush=True)

if __name__=='__main__':main()
