#!/bin/sh
# Offline, compiler-free after editor is built. No Python or special TTY.
set -eu
base=$(CDPATH= cd "$(dirname "$0")/.." && pwd)
editor=${1:-$base/editor}
case $editor in /*) ;; *) editor=$(pwd -P)/$editor ;; esac
work=$(mktemp -d "${TMPDIR:-/tmp}/rescue-smoke.XXXXXXXX")
trap 'rm -rf "$work"' 0
trap 'exit 130' INT
trap 'exit 143' TERM
HOME=$work XDG_CONFIG_HOME=$work/config XDG_DATA_HOME=$work/data TMPDIR=$work TERM=dumb LC_ALL=C
export HOME XDG_CONFIG_HOME XDG_DATA_HOME TMPDIR TERM LC_ALL
"$editor" --check
sh "$base/liner.sh" --check
printf 'a\r\nc\r\nd' > "$work/expected"
for mode in editor liner; do
    printf 'a\r\nb' > "$work/$mode.txt"
    printf 'page\nchange 2\nc\ninsert 3\nd\nundo\nredo\nwrite\nquit\n' > "$work/commands"
    case $mode in
        editor) "$editor" --plain "$work/$mode.txt" < "$work/commands" ;;
        liner) sh "$base/liner.sh" --plain "$work/$mode.txt" < "$work/commands" ;;
    esac
    cmp "$work/expected" "$work/$mode.txt"
    printf 'PASS: %s exact-byte editing, undo, redo and save.\n' "$mode"
done
