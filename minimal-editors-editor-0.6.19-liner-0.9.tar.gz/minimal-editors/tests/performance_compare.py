#!/usr/bin/env python3
"""Compile and compare deterministic editor CPU/wall workloads; developer only.

Usage: python3 tests/performance_compare.py /path/to/old/editor.c
Times are observations, never pass/fail thresholds. /dev/null output excludes
terminal transport and emulator cost. Repeated workloads follow one warm-up
draw. Explicit cold-position-cache workloads include index construction; the
file-read workload uses a freshly written, therefore warm filesystem cache.
"""
from pathlib import Path
import argparse
import hashlib
import os
import re
import shlex
import statistics
import subprocess
import tempfile


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('baseline', type=Path)
    parser.add_argument('--runs', type=int, default=5)
    args = parser.parse_args()
    if not 1 <= args.runs <= 20:
        parser.error('--runs must be 1 through 20')
    root = Path(__file__).resolve().parent.parent
    source = root / 'editor.c'
    baseline = args.baseline.resolve()
    flags = ['-std=c99', '-O2', '-Wall', '-Wextra', '-Werror', '-pedantic']
    compiler = shlex.split(os.environ.get('CC', 'cc'))
    measures = {'baseline': {}, 'current': {}}
    pattern = re.compile(r'^(.*): ([0-9.]+) CPU seconds; ([0-9.]+) wall seconds$')
    print('Editor performance comparison')
    print('Runs per build:', args.runs)
    print('Compiler:', ' '.join(compiler + flags))
    print('Compiler version:', subprocess.check_output(compiler + ['--version'], text=True).splitlines()[0])
    for label, path in [('baseline', baseline), ('current', source)]:
        print(label, 'source SHA256:', hashlib.sha256(path.read_bytes()).hexdigest())
    print('Repeated workloads exclude one initial warm-up draw.')
    print('Cold position-cache and warm-filesystem read cases are labeled explicitly.')
    print('Rendering writes to /dev/null; timings exclude emulator and network delay.')
    print('Medians below are CPU / wall seconds. Individual runs follow.')
    with tempfile.TemporaryDirectory(prefix='editor-performance-') as tmp:
        binaries = {}
        for label, path in [('baseline', baseline), ('current', source)]:
            binary = Path(tmp) / label
            define = '-DEDITOR_SOURCE="' + str(path) + '"'
            subprocess.run(compiler + flags + [define, str(root / 'tests/performance_bench.c'), '-o', str(binary)], check=True)
            binaries[label] = binary
        for run in range(args.runs):
            for label in ('baseline', 'current'):
                result = subprocess.run([str(binaries[label])], check=True, text=True, capture_output=True, timeout=120)
                print('\n' + label + ' run ' + str(run + 1))
                print(result.stdout, end='')
                for line in result.stdout.splitlines():
                    match = pattern.fullmatch(line)
                    if not match:
                        raise RuntimeError('unrecognized benchmark output: ' + line)
                    name, cpu, wall = match.groups()
                    measures[label].setdefault(name, []).append((float(cpu), float(wall)))
    print('\nMEDIANS')
    for name, old in measures['baseline'].items():
        new = measures['current'][name]
        assert len(old) == len(new) == args.runs
        old_cpu, old_wall = (statistics.median(x[i] for x in old) for i in range(2))
        new_cpu, new_wall = (statistics.median(x[i] for x in new) for i in range(2))
        print(name)
        print('  baseline: %.6f / %.6f; current: %.6f / %.6f; CPU ratio: %.2fx' %
              (old_cpu, old_wall, new_cpu, new_wall, old_cpu / new_cpu))


if __name__ == '__main__':
    main()
