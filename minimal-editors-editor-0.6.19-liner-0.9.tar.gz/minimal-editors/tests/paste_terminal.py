#!/usr/bin/env python3
"""Terminal-paste newline regressions; not an editor runtime dependency."""
from pathlib import Path
import os
import signal
import sys
import tempfile
from terminal import Session

BEGIN = b'\x1b[200~'
END = b'\x1b[201~'
REPORT = (b'ex.html"\r    location "/api/*" {\r        block return 404\r    }\r'
          b'    location "/.*" {\r        block return 404\r    }\r}')


def scenarios(binary, root):
    count = 0

    def run(name, fn, initial=b'', args=()):
        nonlocal count
        home = root / name
        home.mkdir()
        doc = home / 'sample.conf'
        doc.write_bytes(initial)
        session = Session(binary, home, [*args, doc])
        try:
            fn(session, home, doc)
            session.finish()
        except BaseException:
            print('FAIL', name, repr(bytes(session.data[-1800:])), flush=True)
            session.kill()
            raise
        count += 1
        print('PASS', name, flush=True)

    def saved(s, path, expected):
        s.command('write')
        s.wait_file(path, expected)

    def report(s, home, doc):
        start = len(s.data)
        s.send(BEGIN + REPORT + END)
        expected = REPORT.replace(b'\r', b'\n')
        assert b'^M' not in s.data[start:]
        saved(s, doc, expected)
        s.command('undo'); saved(s, doc, b'')
        s.command('redo'); saved(s, doc, expected)
    run('reported-httpd-block-cr-paste-and-one-undo', report)

    def lf_target(s, home, doc):
        wire = b'alpha\r\nbeta\r\n\r\n    gamma\rdelta\n^M literal\t\xc3\xa9\r'
        expected = b'alpha\nbeta\n\n    gamma\ndelta\n^M literal\t\xc3\xa9\n'
        s.send(BEGIN + wire + END)
        saved(s, doc, expected + b'original\n')
    run('mixed-endings-indent-tabs-and-literal-caret-M', lf_target, b'original\n')

    def crlf_target(s, home, doc):
        original = doc.read_bytes()
        s.command('bottom')
        s.send(BEGIN + b'A\rB\nC\r\n\rD' + END)
        expected = original + b'A\r\nB\r\nC\r\n\r\nD'
        saved(s, doc, expected)
        assert b'\r\r\n' not in doc.read_bytes()
        s.command('undo'); saved(s, doc, original)
        s.command('redo'); saved(s, doc, expected)
    run('crlf-target-preserves-preexisting-mixed-file-bytes', crlf_target,
        b'head\r\nraw\rcontrol\nlast')

    def fragmented(s, home, doc):
        s.send(BEGIN + b'first\r')
        s.send(b'\nsecond\r')
        s.send(b'\n\r')
        s.send(b'\nthird\r')
        s.send(b'\x1b[20')
        s.send(b'1~X')
        expected = b'first\nsecond\n\nthird\nX'
        saved(s, doc, expected)
        s.command('undo'); saved(s, doc, expected[:-1])
        s.command('undo'); saved(s, doc, b'')
    run('split-read-crlf-and-end-marker-retain-following-input', fragmented)

    def command_prompt(s, home, doc):
        for wire in (b'bad\rquit!', b'bad\nquit!', b'bad\r\nquit!'):
            s.command('find')
            start = len(s.data)
            s.send(BEGIN + wire + END)
            s.wait_output(b'Paste one command line at a time', start=start)
            assert not s.exited()
            s.send(b'qneedle\r')
        s.send(b'X')
        saved(s, doc, b'Xneedle\n')
    run('multiline-command-paste-remains-rejected-not-executed', command_prompt, b'needle\n')

    def clipboard(s, home, doc):
        s.send(b'X')
        s.command('clipboard')
        s.send(BEGIN + b'one\r\n  two\r\tthree\n' + END)
        s.command('clipboard')
        clip = home / 'state/editor/clipboard.txt'
        s.wait_file(clip, b'one\n  two\n\tthree\n')
        saved(s, doc, b'Xparent\n')
        s.command('undo'); saved(s, doc, b'parent\n')
    run('clipboard-editor-paste-preserves-dirty-parent-and-undo', clipboard, b'parent\n')

    def large(s, home, doc):
        wire = b'    alpha\r\n\r\n\tbeta\r' * 4096
        expected = b'    alpha\n\n\tbeta\n' * 4096
        s.send(BEGIN + wire + END, settle=.1)
        saved(s, doc, expected)
        s.command('undo'); saved(s, doc, b'')
        s.command('redo'); saved(s, doc, expected)
    run('large-multiline-paste-remains-one-undo-step', large)

    def cancelled_paste(s, home, doc):
        s.command('toggle-signals')
        s.send(BEGIN + b'discard this\r')
        os.kill(s.pid, signal.SIGINT)
        s.drain(.15)
        # Opt-in interrupt handling returns to Command>; empty Enter resumes text.
        s.send(b'\nquit!\rY\r' + END + b'\rX')
        assert not s.exited()
        saved(s, doc, b'Xoriginal\n')
    run('cancelled-newline-paste-drains-command-looking-remainder', cancelled_paste, b'original\n')

    def movement(s, home, doc):
        s.send(BEGIN + b'A\r\nB\rC\n' + END)
        s.command('edit')
        s.send(b'X')
        saved(s, doc, b'Xoriginal\n')
    run('movement-mode-paste-is-still-read-only', movement, b'original\n', ['--movement'])

    # Reopen the actual saved file to test the persisted transaction as well.
    home = root / 'saved-paste-reopen'
    home.mkdir()
    doc = home / 'sample.conf'
    initial = b'head\r\n'
    expected = initial + b'a\r\nb\r\n'
    doc.write_bytes(initial)
    s = Session(binary, home, [doc])
    try:
        s.command('bottom'); s.send(BEGIN + b'a\rb\r\n' + END)
        saved(s, doc, expected); s.finish()
    except BaseException:
        s.kill(); raise
    s = Session(binary, home, [doc])
    try:
        s.command('undo'); saved(s, doc, initial)
        s.command('redo'); saved(s, doc, expected)
        s.finish()
    except BaseException:
        s.kill(); raise
    count += 1
    print('PASS persisted-paste-undo-and-redo-after-reopen', flush=True)

    # The terminal input fix must not normalize stdin data or file I/O.
    home = root / 'pipe-byte-preservation'
    home.mkdir()
    payload = b'keep\rcarriage\r\nLF\nlast'
    s = Session(binary, home, ['-'], stdin_data=payload, stdout_pipe=True)
    try:
        s.command('write -')
        result = os.read(s.pipe_out, 4096)
        assert result == payload, result
        s.finish()
    except BaseException:
        s.kill(); raise
    count += 1
    print('PASS pipe-input-output-stays-byte-preserving', flush=True)
    print(f'PASS: {count} paste newline PTY groups', flush=True)


if __name__ == '__main__':
    with tempfile.TemporaryDirectory(prefix='editor-paste-') as temp:
        scenarios(Path(sys.argv[1]).resolve(), Path(temp))
