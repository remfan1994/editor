#!/usr/bin/env python3
"""No-CMD policy tests; harmless marker files detect any child execution."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from terminal import Session

DENIED = b'External commands disabled (--no-cmd).'
ORIGINAL = b'first\nsecond\n'


def policy(binary, flags, expected, root):
    count = 0
    home = root / 'commands'; home.mkdir()
    doc = home / 'document'; doc.write_bytes(ORIGINAL)
    cfg = home / 'config/editor'; cfg.mkdir(parents=True)
    defs = cfg / 'commands.conf'
    defs.write_text('saved\tcapture touch marker\nnested\tsaved\n')
    defs.chmod(0o600)
    keys = cfg / 'keys.conf'
    keys.write_text('bind F2 shell touch marker\nbind F3 nested\n')
    keys.chmod(0o600)
    (home / 'inner').write_text('nested\n')
    (home / 'outer').write_text('top\nrun inner\nbottom\n')
    (home / 'safe-script').write_text('bottom\ntop\n')
    s = Session(binary, home, [*flags, '--cli', doc], cols=140)
    def absent():
        assert not (home / 'marker').exists(), 'external command executed'
        assert doc.read_bytes() == ORIGINAL
    def denied(command):
        nonlocal count
        mark = len(s.data)
        s.send(b'\x1b',settle=.15); s.send(command.encode()+b'\r')
        s.wait_output(DENIED, start=mark)
        absent(); count += 1
        print('PASS', expected, command, flush=True)
    try:
        # Every canonical command and synonym, plus case-insensitive lookup.
        for command in ('shell', 'shell touch marker', 'SHELL touch marker',
                        'insert-output touch marker', 'capture touch marker',
                        'filter', 'filter touch marker', 'pipe-document touch marker',
                        'filter-lines', 'filter-lines 1 touch marker',
                        'filter-range 1 touch marker', 'nested', 'run outer'):
            denied(command)
        for key in (b'\x1bOQ', b'\x1bOR'):
            s.command('top'); s.drain(.1); mark = len(s.data); s.send(key); s.wait_output(DENIED, start=mark)
            absent(); count += 1
            print('PASS', expected, 'saved hotkey', repr(key), flush=True)
        s.command('define fresh filter touch marker')
        s.wait_output(b'Defined user command fresh')
        denied('fresh')
        s.command('bind F4 fresh'); s.wait_output(b'Bound F4')
        mark = len(s.data); s.send(b'\x1bOS'); s.wait_output(DENIED, start=mark)
        absent(); count += 1
        print('PASS', expected, 'new hotkey to alias', flush=True)
        # The built-in name remains reserved; cannot shadow the policy.
        s.command('define shell top'); s.drain(.1)
        denied('shell touch marker')
        # Ordinary scripts, line edits, saving, and undo are unaffected.
        s.command('run safe-script'); s.wait_output(b'Ran 2 script lines')
        s.send(b'X'); s.command('write'); s.wait_file(doc, b'X'+ORIGINAL)
        s.command('undo'); s.command('write'); s.wait_file(doc, ORIGINAL)
        s.command('help shell'); s.wait_output(DENIED)
        s.send(b'q\r')
        s.finish(); absent(); count += 1
        print('PASS', expected, 'editing, safe script, undo, help and terminal restore', flush=True)
    except BaseException:
        print('FAIL', expected, bytes(s.data[-1800:]), flush=True)
        s.kill(); raise

    home = root / 'menu'; home.mkdir(); doc = home / 'document'; doc.write_bytes(ORIGINAL)
    s = Session(binary, home, [*flags, '--menu', doc], rows=40, cols=100)
    try:
        mark = len(s.data); s.send(b'\x1b3\r'); s.wait_output(b'Delete N...', start=mark)
        assert b'Insert shell output' not in s.data[mark:]
        assert b'Filter whole document' not in s.data[mark:]
        mark = len(s.data); s.send(b'19\r',settle=.2)
        assert b'Shell>' not in s.data[mark:] and b'Filter command>' not in s.data[mark:]
        s.send(b'h9\r1\r'); s.finish(); count += 1
        print('PASS', expected, 'restricted menu has no external command entries', flush=True)
    except BaseException:
        print('FAIL menu', bytes(s.data[-1800:]), flush=True); s.kill(); raise

    for argv in ([*flags,'--check'], ['--check',*flags]):
        r = subprocess.run([binary,*argv],capture_output=True,check=True)
        assert expected.encode() in r.stdout
        count += 1
    env = dict(os.environ, HOME=str(root), XDG_CONFIG_HOME=str(root/'config'), XDG_STATE_HOME=str(root/'state'))
    for argv in ([*flags,'--plain'], ['--plain',*flags]):
        target = root / 'plain-doc'
        target.write_bytes(b'old\r\n')
        r = subprocess.run([binary,*argv,target],input=b'shell touch marker\nchange 1\nnew\nwrite\nquit\n',capture_output=True,env=env,cwd=root,check=True)
        assert b'Unexpected argument; type help.' in r.stdout
        assert not (root/'marker').exists() and target.read_bytes() == b'new\r\n'
        count += 1
    # Explicit -- keeps a file name separate from command-line options.
    target = root/'--no-cmd'; target.write_bytes(b'base\n')
    subprocess.run([binary,'--plain','--','--no-cmd'],input=b'change 1\nOK\nwrite\nquit\n',capture_output=True,env=env,cwd=root,check=True)
    assert target.read_bytes() == b'OK\n'; count += 1
    print('PASS', expected, 'diagnostic and plain-mode option handling', flush=True)
    return count

if __name__ == '__main__':
    normal, restricted = map(lambda p: Path(p).resolve(), sys.argv[1:3])
    with tempfile.TemporaryDirectory(prefix='editor-no-cmd-') as tmp:
        root=Path(tmp)
        one=root/'runtime'; one.mkdir()
        two=root/'compiled'; two.mkdir()
        count=policy(normal,['--no-cmd'],'disabled (--no-cmd)',one)
        count+=policy(restricted,[],'disabled (compile-time EDITOR_NO_CMD)',two)
        for binary,flags in ((normal,['--no-cmd']), (restricted,[])):
            r=subprocess.run([binary,*flags,'--cmd','--check'],capture_output=True)
            assert r.returncode!=0
            count+=1
        # Standard build with no flag still performs the intended operation.
        home=root/'normal'; home.mkdir(); doc=home/'document'; doc.write_bytes(ORIGINAL)
        s=Session(normal,home,['--cli',doc])
        try:
            s.command('shell printf OK'); s.wait_output(b'Inserted 2 bytes')
            s.command('write'); s.wait_file(doc,b'OK'+ORIGINAL); s.finish(); count+=1
        except BaseException:
            s.kill(); raise
        print('PASS: %d no-cmd checks.' % count,flush=True)
