#!/usr/bin/env python3
"""PTY regression checks. Python is needed for tests, never for editor itself."""
import argparse
import errno
import fcntl
import os
from pathlib import Path
import pty
import resource
import select
import signal
import struct
import tempfile
import termios
import time

class Session:
    def __init__(self, binary, home, args=(), stdin_data=None, stdout_pipe=False, rows=24, cols=80, odd_input=False, mark_input=False, file_limit=None, terminal_setup=None):
        self.home = Path(home)
        self.odd_input = odd_input
        self.mark_input = mark_input
        self.data = bytearray()
        self.pid = None
        self.status = None
        self.pipe_out = None
        inp = os.pipe() if stdin_data is not None else None
        out = os.pipe() if stdout_pipe else None
        pid, master = pty.fork()
        if pid == 0:
            if terminal_setup is not None:
                attr = termios.tcgetattr(0)
                terminal_setup(attr)
                termios.tcsetattr(0, termios.TCSANOW, attr)
            if file_limit is not None:
                resource.setrlimit(resource.RLIMIT_FSIZE, (file_limit, file_limit))
                signal.signal(signal.SIGXFSZ, signal.SIG_DFL)
            if mark_input:
                attr = termios.tcgetattr(0)
                attr[0] |= termios.PARMRK
                termios.tcsetattr(0, termios.TCSANOW, attr)
            if odd_input:
                attr = termios.tcgetattr(0)
                attr[0] |= termios.INLCR | termios.IGNCR | termios.IXON | termios.IXOFF
                termios.tcsetattr(0, termios.TCSANOW, attr)
            env = dict(os.environ, HOME=str(home), XDG_CONFIG_HOME=str(home / 'config'),
                       XDG_STATE_HOME=str(home / 'state'), TERM='xterm', LC_ALL='C.UTF-8')
            if inp:
                os.close(inp[1]); os.dup2(inp[0], 0); os.close(inp[0])
            if out:
                os.close(out[0]); os.dup2(out[1], 1); os.close(out[1])
            os.chdir(home)
            os.execve(str(binary), [str(binary), *map(str, args)], env)
        self.pid, self.fd = pid, master
        os.set_blocking(master, False)
        if inp:
            os.close(inp[0]); os.write(inp[1], stdin_data); os.close(inp[1])
        if out:
            os.close(out[1]); self.pipe_out=out[0]; os.set_blocking(self.pipe_out,False)
        self.resize(rows,cols)
        try:
            # Instrumented/cold processes can start slowly under parallel load.
            # Wait for actual terminal setup; never substitute a fixed sleep.
            self.wait_output(b'\x1b[?2004h', 10)
            self.drain(.05)
        except BaseException:
            self.kill()
            raise
    def resize(self,r,c):
        fcntl.ioctl(self.fd, termios.TIOCSWINSZ,struct.pack('HHHH',r,c,0,0))
    def drain(self, seconds=.06):
        until=time.monotonic()+seconds
        while time.monotonic()<until:
            ready,_,_=select.select([self.fd],[],[],max(0,until-time.monotonic()))
            if not ready: break
            try: chunk=os.read(self.fd,65536)
            except OSError as e:
                if e.errno in (errno.EIO,errno.EAGAIN): break
                raise
            if not chunk: break
            self.data.extend(chunk)
        return bytes(self.data)
    def wait_output(self, needle, timeout=2, start=0):
        until=time.monotonic()+timeout
        while time.monotonic()<until:
            self.drain(.025)
            if needle in self.data[start:]: return
            if self.exited(): break
        raise AssertionError(f'output missing {needle!r}: {bytes(self.data[-700:])!r}')
    def wait_file(self, path, expected, timeout=5):
        """Wait for an actual file result, not an assumed scheduling delay."""
        path = Path(path)
        until = time.monotonic() + timeout
        current = None
        while time.monotonic() < until:
            try:
                current = path.read_bytes()
            except FileNotFoundError:
                current = None
            if current == expected:
                return
            if self.exited():
                break
            self.drain(.025)
        raise AssertionError(f'file result missing for {path}: '
                             f'length={len(current) if current is not None else None}, '
                             f'prefix={current[:256] if current is not None else None!r}; '
                             f'terminal {bytes(self.data[-800:])!r}')
    def send(self,data,settle=.05):
        view=memoryview(data)
        until=time.monotonic()+5
        while view:
            try:
                n=os.write(self.fd,view[:4096]);view=view[n:]
            except BlockingIOError:
                self.drain(.01)
                if time.monotonic()>until: raise TimeoutError('PTY input blocked')
        return self.drain(settle)
    def command(self,text):
        return self.send(b'\x1b'+text.encode()+b'\r')
    def exited(self):
        if self.status is not None: return True
        pid,status=os.waitpid(self.pid,os.WNOHANG)
        if pid: self.status=status
        return pid!=0
    def finish(self, expected=0, expected_signal=None):
        if not self.exited(): self.command('quit!')
        until=time.monotonic()+3
        while not self.exited() and time.monotonic()<until: self.drain(.025)
        if not self.exited():
            os.kill(self.pid,signal.SIGKILL);_,self.status=os.waitpid(self.pid,0)
            raise AssertionError('editor failed to exit: '+repr(bytes(self.data[-700:])))
        self.drain(.01)
        attr=termios.tcgetattr(self.fd)
        assert attr[3] & termios.ICANON and attr[3] & termios.ECHO, 'terminal not restored'
        if self.mark_input:
            assert attr[0] & termios.PARMRK, 'PARMRK not restored'
        if self.odd_input:
            assert attr[0] & termios.INLCR and attr[0] & termios.IGNCR, 'input flags not restored'
        text=bytes(self.data)
        assert b'AddressSanitizer' not in text and b'runtime error:' not in text and b'LeakSanitizer' not in text, text[-4000:]
        if expected_signal is not None:
            assert os.WIFSIGNALED(self.status), f'not a signal exit: {self.status}'
            assert os.WTERMSIG(self.status)==expected_signal, f'wrong signal: {self.status}'
        else:
            assert os.WIFEXITED(self.status), f'abnormal status: {self.status}'
            assert os.WEXITSTATUS(self.status)==expected, f'exit code: {os.WEXITSTATUS(self.status)}'
        os.close(self.fd)
        if self.pipe_out is not None: os.close(self.pipe_out)
    def kill(self):
        if not self.exited():
            os.kill(self.pid,signal.SIGKILL);os.waitpid(self.pid,0)
        os.close(self.fd)
        if self.pipe_out is not None: os.close(self.pipe_out)

def set_config(home,text):
    d=home/'config'/'editor';d.mkdir(parents=True,exist_ok=True);d.chmod(0o700)
    (d/'config').write_bytes(text)

def scenarios(binary, root, baseline=False):
    count=0
    def run(name,fn):
        nonlocal count
        home=root/name;home.mkdir()
        try: fn(home)
        except Exception:
            print('FAIL:',name,flush=True);raise
        count+=1;print(f'ok {count} - {name}',flush=True)
    def startup(home):
        f=home/'sample';f.write_bytes(b'abc\n')
        set_config(home,b'startup=movement\n')
        s=Session(binary,home,[f])
        try:
            s.send(b'!\x7f\x1b[3~');s.command('write');assert f.read_bytes()==b'abc\n'
            s.command('edit');s.send(b'X');s.command('write');assert f.read_bytes()==b'Xabc\n'
            s.command('movement');s.send(b'llj!');s.command('write');assert f.read_bytes()==b'Xabc\n'
            s.finish()
        except Exception: s.kill();raise
        s=Session(binary,home,['--edit',f])
        try:
            s.send(b'Y');s.command('write');assert f.read_bytes()==b'YXabc\n';s.finish()
        except Exception:s.kill();raise
    def filename_sigint(home):
        # Application cancellation is now explicitly opt-in.
        set_config(home,b'signal_controls=on\n')
        s=Session(binary,home)
        try:
            s.command('write');s.wait_output(b'Filename>')
            os.kill(s.pid,signal.SIGINT);s.drain(.12)
            s.send(b'quit!\r');s.drain(.1)
            assert s.exited(), 'SIGINT left filename prompt active (quit! treated as filename)'
            assert not (home/'quit!').exists();s.finish()
        except Exception:s.kill();raise
    def piped_named(home):
        f=home/'sample';f.write_bytes(b'named file\n')
        s=Session(binary,home,[f],stdin_data=b'ignored pipe\n')
        try:
            s.send(b'X');s.command('write');assert f.read_bytes()==b'Xnamed file\n';s.finish()
        except Exception:s.kill();raise
    def paste_interrupt(home):
        set_config(home,b'signal_controls=on\n')
        f=home/'sample';f.write_bytes(b'original\n')
        s=Session(binary,home,[f])
        try:
            s.send(b'\x1b[200~some paste',settle=.1)
            os.kill(s.pid,signal.SIGINT);s.drain(.1)
            s.send(b'quit!\r\x1b[201~',settle=.2)
            assert not s.exited(), 'cancelled paste remainder executed as command'
            assert f.read_bytes()==b'original\n'
            s.send(b'\x1b');s.command('write');assert f.read_bytes()==b'original\n';s.finish()
        except Exception:s.kill();raise
    if baseline:
        # Independent invocations are used for baseline reproductions.
        return {'filename-sigint':filename_sigint,'piped-named':piped_named,'paste-interrupt':paste_interrupt}
    run('startup-config',startup)
    run('filename-sigint',filename_sigint)
    run('piped-named',piped_named)
    run('paste-interrupt',paste_interrupt)
    def paste(home):
        f=home/'sample';f.write_bytes(b'base\n')
        s=Session(binary,home,[f])
        try:
            s.send(b'\x1b[200~one\ntwo\n\x1b[201~');s.command('write');assert f.read_bytes()==b'one\ntwo\nbase\n'
            s.command('undo');s.command('write');assert f.read_bytes()==b'base\n'
            s.send(b'\x1b[200~bad\0data\x1b[201~');s.command('write');assert f.read_bytes()==b'base\n'
            s.command('movement');s.send(b'\x1b[200~edit\rquit!\r\x1b[201~');s.command('write');assert f.read_bytes()==b'base\n'
            s.command('manual');s.send(b'\x1b[200~quit!\r\x1b[201~');s.send(b'q');assert not s.exited();s.finish()
        except Exception:s.kill();raise
    run('paste-contexts',paste)
    def small(home):
        f=home/'sample';f.write_bytes(b'one\r\ntwo\r\nthree\r\n')
        s=Session(binary,home,[f],rows=3,cols=12)
        try:
            s.command('movement');s.send(b'jjkkkkllllhhhh');s.command('edit')
            s.command('toggle-esc');s.send(b'\x1b');s.send(b'6\rl');s.send(b'\x1b8\rtoggle-esc\r')
            s.command('list');s.send(b'jjllhhkkq\r');s.command('manual');s.send(b'jjllhhkkq')
            for r,c in [(1,1),(3,12),(5,20),(24,80),(3,12)]:s.resize(r,c);s.send(b'\x1b[C\x1b[D')
            s.command('write');assert f.read_bytes()==b'one\r\ntwo\r\nthree\r\n';s.finish()
        except Exception:s.kill();raise
    run('small-screens-and-menu',small)
    def completion(home):
        f=home/'sample';f.write_bytes(b'start\n');(home/'unique.conf').write_bytes(b'new file\n')
        s=Session(binary,home,[f])
        try:
            s.send(b'\x1bhe\t\r');s.wait_output(b'HELP');s.send(b'q\r')
            s.send(b'\x1bread uniq\t\r');s.command('write copy with spaces.txt');assert (home/'copy with spaces.txt').read_bytes()==b'new file\n'
            s.command('movement');s.send(b'\x1bedit\r');s.send(b'X');s.command('write');assert (home/'copy with spaces.txt').read_bytes()==b'Xnew file\n'
            assert f.read_bytes()==b'start\n';s.finish()
        except Exception:s.kill();raise
    run('completion-and-active-filename',completion)
    def overwrite(home):
        f=home/'sample';f.write_bytes(b'old\n');s=Session(binary,home,[f])
        try:
            s.send(b'X');f.write_bytes(b'external\n');s.command('write');s.wait_output(b'File written since read.')
            s.send(b'n');assert f.read_bytes()==b'external\n';s.send(b'\x1b');s.command('write');s.send(b'y');assert f.read_bytes()==b'Xold\n', (f.read_bytes(),bytes(s.data[-2500:]))
            s.command('undo');s.command('write');assert f.read_bytes()==b'external\n';s.finish()
        except Exception:s.kill();raise
        s=Session(binary,home,[f])
        try:
            s.command('undo');s.command('write');assert f.read_bytes()==b'Xold\n', (f.read_bytes(), bytes(s.data[-2500:]))
            s.command('undo');s.command('write');assert f.read_bytes()==b'old\n';s.finish()
        except Exception:s.kill();raise
    run('outside-write-and-reopen-history',overwrite)
    def pipeline(home):
        s=Session(binary,home,['-'],stdin_data=b'pipe input\r\n',stdout_pipe=True)
        try:
            s.send(b'X');s.command('write -');out=os.read(s.pipe_out,4096);assert out==b'Xpipe input\r\n',out
            s.finish()
        except Exception:s.kill();raise
    run('pipeline-bytes',pipeline)
    def unusual_terminal(home):
        f=home/'sample';f.write_bytes(b'original\n')
        s=Session(binary,home,[f],odd_input=True)
        try:
            s.send(b'A\rB');s.command('write');assert f.read_bytes()==b'A\nBoriginal\n'
            s.send(b'\x1b[200~x\ny\x1b[201~');s.command('write')
            assert f.read_bytes()==b'A\nBx\nyoriginal\n';s.finish()
        except Exception:s.kill();raise
    run('inherited-terminal-input-flags',unusual_terminal)
    def blocked_pipe(home):
        f=home/'sample';f.write_bytes(b'x'*300000)
        s=Session(binary,home,[f],stdout_pipe=True)
        try:
            s.command('write -');os.kill(s.pid,signal.SIGTERM)
            until=time.monotonic()+3
            while not s.exited() and time.monotonic()<until:s.drain(.025)
            assert s.exited(),'blocked pipe ignored SIGTERM';s.finish(expected=128+signal.SIGTERM)
        except Exception:s.kill();raise
    run('blocked-pipe-termination',blocked_pipe)
    def stress(home):
        f=home/'sample';f.write_bytes(b'')
        s=Session(binary,home,[f],rows=5,cols=20)
        try:
            for i in range(80):
                s.send(b'abc\x1b[D\x7f\x1b[C\r',settle=.003)
                s.command('undo');s.command('redo')
                if i%10==0:s.command('write')
            s.command('write');assert f.read_bytes()==b'ac\n'*80
            fdpath=Path('/proc')/str(s.pid)/'fd'
            if fdpath.exists(): assert len(list(fdpath.iterdir()))==3
            s.finish()
        except Exception:s.kill();raise
    run('typing-undo-save-stress',stress)
    def mouse_prompt(home):
        f=home/'sample';f.write_bytes(b'parent text\n')
        s=Session(binary,home,['--mouse',f])
        try:
            for text in ['read','replace','write copy.txt']:
                if text.startswith('write '):
                    (home/'copy.txt').write_bytes(b'existing\n')
                    s.command(text);s.send(b'n')
                else:s.command(text)
                # Click status bar, leave menu, then execute a genuine CLI command.
                s.send(b'\x1b[<0;2;23M');s.send(b'h')
                s.command('history');s.wait_output(b'Undo:')
                assert not (home/'history').exists()
                assert f.read_bytes()==b'parent text\n'
            s.finish()
        except Exception:s.kill();raise
    run('mouse-leaves-old-prompt',mouse_prompt)
    def clipboard_warning(home):
        f=home/'sample';f.write_bytes(b'parent\n');s=Session(binary,home,[f])
        try:
            s.command('clipboard');s.send(b'pending scratch')
            clip=home/'state'/'editor'/'clipboard.txt'
            clip.mkdir()  # Forced regular-file rejection, even when tests run as root.
            start=len(s.data);s.command('write')
            s.wait_output(b'not a regular file',start=start)
            assert f.read_bytes()==b'parent\n'
            # Draw Command> first: a differential renderer correctly skips
            # retransmission when two failures leave the same footer intact.
            s.send(b'\x1b',settle=.12)
            start=len(s.data);s.send(b'clipboard\r')
            s.wait_output(b'not a regular file',start=start)
            clip.rmdir();s.command('clipboard')
            assert clip.read_bytes()==b'pending scratch'
            assert f.read_bytes()==b'parent\n';s.finish()
        except Exception:s.kill();raise
    run('clipboard-warning-visible',clipboard_warning)
    def concurrent_journals(home):
        f=home/'sample';f.write_bytes(b'start');first=Session(binary,home,[f]);second=None
        try:
            first.command('bottom');first.send(b'A');first.command('write')
            second=Session(binary,home,[f]);second.command('bottom')
            second.send(b'B');second.send(b'\x7f');second.command('write')
            journal=next((home/'state'/'editor'/'history').glob('*.undo'))
            second_history=journal.read_bytes()
            second.finish();second=None
            first.send(b'C');first.command('write')
            assert f.read_bytes()==b'startAC'
            stale=list(journal.parent.glob(journal.name+'.stale.*'))
            assert any(p.read_bytes()==second_history for p in stale)
            first.finish()
        except Exception:
            if second is not None:second.kill()
            first.kill();raise
    run('two-session-undo-retention',concurrent_journals)
    return count

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('binary',type=Path);parser.add_argument('--baseline')
    args=parser.parse_args();binary=args.binary.resolve()
    with tempfile.TemporaryDirectory(prefix='editor-pty-') as tmp:
        root=Path(tmp)
        if args.baseline:
            tests=scenarios(binary,root,baseline=True)
            tests[args.baseline](root)
        else: print('PASS:',scenarios(binary,root),'PTY test groups',flush=True)
