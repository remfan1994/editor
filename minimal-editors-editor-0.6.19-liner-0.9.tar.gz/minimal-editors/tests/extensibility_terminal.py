#!/usr/bin/env python3
"""External-command and user-script PTY tests. Run in isolated homes only."""
import os
from pathlib import Path
import signal
import sys
import tempfile
from terminal import Session


def check(binary, root):
    count = 0
    def run(name, fn, initial=b'first\nsecond\n'):
        nonlocal count
        home = root / name
        home.mkdir()
        sample = home / 'doc.txt'
        sample.write_bytes(initial)
        s = Session(binary, home, [sample])
        try:
            fn(s, home, sample)
            s.finish()
        except BaseException:
            print('FAIL', name, bytes(s.data[-1600:]), flush=True)
            s.kill()
            raise
        count += 1
        print('PASS', name, flush=True)

    def insert(s, home, doc):
        s.command('shell printf "HELLO\\nWORLD\\n"')
        s.wait_output(b'Inserted')
        s.command('write')
        s.wait_file(doc, b'HELLO\nWORLD\nfirst\nsecond\n')
        s.command('undo')
        s.command('write')
        s.wait_file(doc, b'first\nsecond\n')
    run('shell-output-one-undo', insert)

    def prompts(s, home, doc):
        s.command('shell'); s.wait_output(b'Shell>')
        s.send(b'ls -1\r')
        s.wait_output(b'Inserted')
        s.command('write')
        s.wait_file(doc, b'doc.txt\nstate\nfirst\nsecond\n')
    run('shell-prompt-and-ls', prompts)

    def failure(s, home, doc):
        s.command('shell printf partial; echo failed >&2; exit 7')
        s.wait_output(b'Shell failed (status 7)')
        s.command('shell printf "\\033[31m"')
        s.wait_output(b'non-text control byte')
        s.command('write')
        s.wait_file(doc, b'first\nsecond\n')
    run('nonzero-and-control-output-atomic', failure)

    def filt(s, home, doc):
        s.command('filter sort')
        s.wait_output(b'Filtered')
        s.command('write')
        s.wait_file(doc, b'cat\ndog\nzebra\n')
        s.command('undo')
        s.command('write')
        s.wait_file(doc, b'zebra\ndog\ncat\n')
        s.command('filter-lines 2 tr a-z A-Z')
        s.command('write')
        s.wait_file(doc, b'zebra\nDOG\ncat\n')
    run('filter-whole-and-numbered-lines', filt, b'zebra\ndog\ncat\n')

    def filter_fail(s, home, doc):
        s.command('filter printf "partial"; exit 8')
        s.wait_output(b'Shell failed (status 8)')
        s.command('write')
        s.wait_file(doc,b'first\nsecond\n')
    run('filter-failure-keeps-contents', filter_fail)

    def defs(s, home, doc):
        s.command('define greet shell printf HEY')
        s.wait_output(b'Defined user command greet')
        defs_file=home/'config/editor/commands.conf'
        s.wait_file(defs_file,b'greet\tshell printf HEY\n')
        s.command('greet')
        s.command('write')
        s.wait_file(doc,b'HEYfirst\nsecond\n')
        s.command('functions')
        s.wait_output(b'greet = shell printf HEY')
        s.send(b'q\r')
        s.command('undefine greet')
        s.wait_file(defs_file,b'')
    run('persisted-definition-and-direct-call',defs)

    def scripts(s, home, doc):
        file=home/'commands.editor'
        file.write_text('# example\nshell printf A\nshell printf B\n')
        s.command('define batch run commands.editor')
        s.command('batch')
        s.command('write')
        s.wait_file(doc,b'ABfirst\nsecond\n')
        s.command('undo')
        s.command('write')
        s.wait_file(doc,b'Afirst\nsecond\n')
    run('user-function-runs-script-with-stepwise-undo',scripts)

    def recursion(s, home, doc):
        s.command('define loop loop')
        s.command('loop')
        s.wait_output(b'recursion limit')
        s.command('write')
        s.wait_file(doc,b'first\nsecond\n')
    run('recursion-limited',recursion)

    def over(s, home, doc):
        s.command('shell head -c 8388609 /dev/zero | tr "\\000" x')
        s.wait_output(b'output discarded',timeout=20)
        s.command('write')
        s.wait_file(doc,b'first\nsecond\n')
    run('oversized-shell-output-does-not-edit',over)

    def no_auto(s, home, doc):
        # External scripts never execute merely because a document is opened.
        s.command('run not-found.editor')
        s.wait_output(b'Cannot read trusted script')
        s.command('write')
        s.wait_file(doc,b'first\nsecond\n')
    run('nonexistent-script-no-edit',no_auto)

    def saved_restart(s, home, doc):
        s.command('define stamp shell printf Z')
        s.command('write')
        s.wait_file(doc,b'first\nsecond\n')
    run('custom-command-file-is-inert-on-save',saved_restart)
    home=root/'custom-command-file-is-inert-on-save'
    s=Session(binary,home,[home/'doc.txt'])
    try:
        s.command('stamp')
        s.command('write')
        s.wait_file(home/'doc.txt',b'Zfirst\nsecond\n')
        s.finish()
    except BaseException:s.kill();raise
    count+=1;print('PASS saved-command-restores-after-restart',flush=True)

    def partial_script(s,home,doc):
        file=home/'steps.editor'
        file.write_text('shell printf A\nnot-a-script-command\nshell printf B\n')
        s.command('run steps.editor')
        s.wait_output(b'Script line 2 stopped')
        s.command('write')
        s.wait_file(doc,b'Afirst\nsecond\n')
        s.command('undo')
        s.command('write')
        s.wait_file(doc,b'first\nsecond\n')
    run('script-stops-with-previous-steps-undoable',partial_script)

    def suspicious(s,home,doc):
        unsafe=home/'unsafe.editor'
        unsafe.write_text('shell printf BAD\n');unsafe.chmod(0o666)
        s.command('run unsafe.editor')
        s.wait_output(b'Cannot read trusted script')
        s.command('write')
        s.wait_file(doc,b'first\nsecond\n')
    run('reject-other-writable-script',suspicious)

    def deadlock(s,home,doc):
        s.command('shell head -c 200000 /dev/zero 1>&2; printf OUT')
        s.wait_output(b'Inserted',timeout=8)
        s.command('write')
        s.wait_file(doc,b'OUTfirst\nsecond\n')
    run('large-stderr-does-not-block-stdout',deadlock)

    def normalize(s,home,doc):
        s.command('shell printf "A\\r\\nB\\rC\\n"')
        s.wait_output(b'Inserted')
        s.command('write')
        s.wait_file(doc,b'A\r\nB\r\nC\r\nfirst\r\nsecond\r\n')
    run('external-output-normalizes-newlines',normalize,b'first\r\nsecond\r\n')

    def interrupt(s,home,doc):
        s.command('toggle-signals')
        s.wait_output(b'interrupt')
        mark=len(s.data)
        s.command('shell touch started; sleep 30')
        s.wait_file(home/'started',b'',timeout=8)
        os.kill(s.pid,signal.SIGINT)
        s.wait_output(b'Command stopped; output discarded',timeout=8,start=mark)
        s.send(b'q\r')  # Read the cancellation notice, then return to editing.
        s.command('write')
        s.wait_file(doc,b'first\nsecond\n')
    run('cancel-sleeping-shell-and-recover',interrupt)

    def stale(s,home,doc):
        s.command('define one shell date')
        path=home/'config/editor/commands.conf'
        s.wait_file(path,b'one\tshell date\n')
        path.write_bytes(b'changed\tshell printf NEW\n')
        s.command('define two shell printf OLD')
        s.wait_output(b'Command NOT saved')
        assert path.read_bytes()==b'changed\tshell printf NEW\n'
        s.command('functions reload')
        s.command('changed')
        s.command('write')
        s.wait_file(doc,b'NEWfirst\nsecond\n')
    run('stale-definitions-not-overwritten',stale)

    def bind(s,home,doc):
        s.command('define insertx shell printf X')
        s.command('bind F2 insertx')
        s.wait_output(b'Bound F2')
        s.send(b'\x1b[12~')
        s.command('write')
        s.wait_file(doc,b'Xfirst\nsecond\n')
    run('optional-hotkey-runs-user-definition',bind)

    home=root/'optional-hotkey-runs-user-definition'
    s=Session(binary,home,[home/'doc.txt'])
    try:
        s.send(b'\x1b[12~')
        s.command('write')
        s.wait_file(home/'doc.txt',b'XXfirst\nsecond\n')
        s.finish()
    except BaseException:s.kill();raise
    count+=1;print('PASS restored-hotkey-runs-restored-definition',flush=True)

    home=root/'menu-shell-output';home.mkdir()
    doc=home/'doc.txt';doc.write_bytes(b'original\n')
    s=Session(binary,home,['--menu',doc])
    try:
        # Menu root: 3 Edit; edit row 19: Insert shell output.
        s.send(b'\x1b3\r19\r')
        s.wait_output(b'Shell>')
        s.send(b'printf MENU\r')
        s.wait_output(b'Inserted')
        # Change saved Esc choice from menu back to CLI using one-off Command line.
        s.send(b'\x1b8\rtoggle-esc\r')
        s.command('write')
        s.wait_file(doc,b'MENUoriginal\n')
        s.finish()
    except BaseException:
        print('FAIL menu-shell-output',bytes(s.data[-1500:]),flush=True)
        s.kill();raise
    count+=1;print('PASS menu-shell-output',flush=True)

    def clipboard_context(s,home,doc):
        s.send(b'*')
        s.command('clipboard')
        s.command('shell printf CLIP')
        s.command('clipboard')
        s.command('write')
        s.wait_file(doc,b'*first\nsecond\n')
        s.wait_file(home/'state/editor/clipboard.txt',b'CLIP')
    run('shell-clipboard-parent-preserved',clipboard_context)

    home=root/'shell-pipeline-stdout-isolation';home.mkdir()
    s=Session(binary,home,stdin_data=b'doc\n',stdout_pipe=True)
    try:
        s.command('shell printf INSERT')
        s.wait_output(b'Inserted')
        s.command('write -')
        s.wait_output(b'Text sent to stdout')
        import select
        ready,_,_=select.select([s.pipe_out],[],[],2)
        assert ready, 'document stdout not written'
        assert os.read(s.pipe_out,4096)==b'INSERTdoc\n'
        s.finish()
    except BaseException:s.kill();raise
    count+=1;print('PASS shell-pipeline-stdout-isolation',flush=True)

    print('PASS:',count,'external-command PTY groups',flush=True)

if __name__=='__main__':
    with tempfile.TemporaryDirectory(prefix='editor-ext-') as directory:
        check(Path(sys.argv[1]).resolve(),Path(directory))
