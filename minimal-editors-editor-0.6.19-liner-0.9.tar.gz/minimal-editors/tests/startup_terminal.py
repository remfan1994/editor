#!/usr/bin/env python3
"""Saved startup workflow regressions; test tools are not runtime dependencies."""
import argparse
from pathlib import Path
import tempfile
import shlex
from terminal import Session


def config(home, data=b'startup=movement\n', directory_mode=0o755):
    p=home/'config'/'editor'; p.mkdir(parents=True,exist_ok=True); p.chmod(directory_mode)
    f=p/'config'; f.write_bytes(data); f.chmod(0o644); return f


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('binary'); parser.add_argument('--baseline', action='store_true')
    args=parser.parse_args(); binary=str(Path(args.binary).resolve())
    count=0
    with tempfile.TemporaryDirectory(prefix='editor-startup-') as temp:
        root=Path(temp)
        def run(name, fn):
            nonlocal count
            home=root/name;home.mkdir()
            fn(home);count+=1;print(f'ok {count} - {name}',flush=True)
        def ordinary(home):
            cfg=config(home); f=home/'document';f.write_bytes(b'abc\n')
            s=Session(binary,home,[f])
            try:
                s.send(b'!');s.command('write');s.wait_file(f,b'!abc\n' if args.baseline else b'abc\n')
                s.finish()
            except BaseException:s.kill();raise
            assert cfg.read_bytes()==b'startup=movement\n' and cfg.stat().st_mode & 0o777==0o644
        run('ordinary-755-directory-644-config',ordinary)
        if args.baseline:
            print('REPRODUCED: 0.6.8 ignores startup=movement in a 0755 editor directory; typing changes the file.',flush=True)
            return
        def saved(home):
            f=home/'document';f.write_bytes(b'abc\n'); s=Session(binary,home,[f]);p=home/'config'/'editor'/'config'
            try:
                s.command('toggle-startup');s.wait_file(p,b'startup=movement\n')
                s.send(b'X');s.command('write');s.wait_file(f,b'Xabc\n');s.finish()
            except BaseException:s.kill();raise
            s=Session(binary,home,[f])
            try:
                s.send(b'!\x7f\x1b[3~');s.command('write');s.wait_file(f,b'Xabc\n')
                s.command('toggle-startup');s.wait_file(p,b'startup=edit\n')
                s.send(b'!');s.command('write');s.wait_file(f,b'Xabc\n');s.finish()
            except BaseException:s.kill();raise
            s=Session(binary,home,[f])
            try:s.send(b'Y');s.command('write');s.wait_file(f,b'YXabc\n');s.finish()
            except BaseException:s.kill();raise
        run('saved-command-restart-and-current-mode-independent',saved)
        def menu(home):
            cfg=config(home,b'# user\nsignal_controls=on\nstartup=edit\n');f=home/'document';f.write_bytes(b'base\n')
            s=Session(binary,home,['--menu',f])
            try:
                s.send(b'\x1b7\r7\r');s.wait_output(b'Start in: Edit')
                s.send(b'1\r');s.wait_file(cfg,b'# user\nsignal_controls=on\nstartup=movement\n')
                s.wait_output(b'Start in: Movement')
                s.send(b'\x1b\x1b8\rquit!\r');s.finish()
            except BaseException:s.kill();raise
            s=Session(binary,home,[f],rows=3,cols=12)
            try:
                s.send(b'!');s.command('write');s.wait_file(f,b'base\n')
                s.command('settings');s.wait_output(b'Start M')
                s.send(b'1\r');s.wait_file(cfg,b'# user\nsignal_controls=on\nstartup=edit\n')
                s.send(b'\x1b\x1b8\rquit!\r');s.finish()
            except BaseException:s.kill();raise
        run('menu-toggle-normal-and-12-by-3',menu)
        def overrides(home):
            cfg=config(home); f=home/'document';f.write_bytes(b'abc\n')
            for flags,expected in [(['--edit'],b'Xabc\n'),(['--edit','--movement'],b'Xabc\n'),(['--movement','--edit'],b'XXabc\n')]:
                s=Session(binary,home,flags+[f])
                try:s.send(b'X');s.command('write');s.wait_file(f,expected);s.finish()
                except BaseException:s.kill();raise
                assert cfg.read_bytes()==b'startup=movement\n'
        run('explicit-flags-override-saved-setting',overrides)
        def report(home):
            cfg=config(home,b'startup=edit\n');s=Session(binary,home,[])
            try:
                s.command('settings show');s.wait_output(b'SETTINGS - current and saved');s.wait_output(b'Saved startup: edit')
                assert str(cfg).encode() in s.data
                s.send(b'q');s.send(b'help toggle-startup\r');s.wait_output(b'toggle-startup')
                s.send(b'q');s.send(b'toggle-startup\r');s.wait_file(cfg,b'startup=movement\n')
                s.finish()
            except BaseException:s.kill();raise
        run('actual-path-help-and-alias',report)
        def fallback(home):
            d=home/'.config'/'editor';d.mkdir(parents=True);d.chmod(0o755)
            cfg=d/'config';cfg.write_bytes(b'startup=movement\n');cfg.chmod(0o644)
            config(home,b'startup=edit\n') # a different XDG path must not be used
            wrapper=home/'fallback-editor';wrapper.write_text('#!/bin/sh\nunset XDG_CONFIG_HOME\nexec '+shlex.quote(binary)+' "$@"\n');wrapper.chmod(0o700)
            f=home/'document';f.write_bytes(b'abc\n');s=Session(wrapper,home,[f])
            try:
                s.send(b'!');s.command('write');s.wait_file(f,b'abc\n')
                s.command('toggle-startup');s.wait_file(cfg,b'startup=edit\n')
                s.command('settings show');s.wait_output(str(cfg).encode());s.send(b'q\r');s.finish()
            except BaseException:s.kill();raise
        run('default-home-dot-config-path',fallback)
        def rejected(home):
            cfg=config(home,directory_mode=0o775);s=Session(binary,home,[])
            try:
                s.wait_output(b'Config not loaded:');s.wait_output(b'settings show')
                s.command('toggle-startup');s.wait_output(b'Startup setting NOT saved')
                assert cfg.read_bytes()==b'startup=movement\n'
                s.send(b'q\x1b');s.send(b'X')
                dest=home/'still-editable';s.command('write '+str(dest));s.wait_file(dest,b'X');s.finish()
            except BaseException:s.kill();raise
        run('unsafe-config-visible-error-and-document-still-editable',rejected)
        def dirty_clip(home):
            f=home/'document';f.write_bytes(b'abc\n');s=Session(binary,home,[f])
            try:
                s.send(b'P');s.command('copy');s.command('clipboard');s.send(b'C')
                s.command('toggle-startup');s.wait_file(home/'config'/'editor'/'config',b'startup=movement\n')
                s.command('clipboard');s.command('write');s.wait_file(f,b'Pabc\n')
                s.command('undo');s.command('write');s.wait_file(f,b'abc\n');s.finish()
            except BaseException:s.kill();raise
        run('startup-does-not-touch-clipboard-or-parent-history',dirty_clip)
    print(f'PASS: {count} startup terminal groups.',flush=True)

if __name__=='__main__':main()
