#!/usr/bin/env python3
"""Concurrent keymap sessions and disabled/invalid-map regressions."""
from pathlib import Path
import sys
import tempfile
from terminal import Session


def scenarios(binary, root):
    count = 0
    header = b'# editor user-defined keys; no built-in hotkeys\n'
    for existing in (False, True):
        home = root / ('existing' if existing else 'new')
        home.mkdir()
        doc = home / 'document'; doc.write_bytes(b'base\n')
        keys = home / 'config/editor/keys.conf'
        if existing:
            keys.parent.mkdir(parents=True)
            keys.write_bytes(b'bind F4 write\n'); keys.chmod(0o600)
        one = Session(binary, home, [doc])
        two = Session(binary, home, [doc])
        try:
            one.command('bind F2 undo')
            expected = header + (b'bind F4 write\n' if existing else b'') + b'bind F2 undo\n'
            one.wait_file(keys, expected)
            two.command('bind F3 redo')
            two.wait_output(b'keys.conf changed.')
            assert keys.read_bytes() == expected
            # The second session's explicit binding remains usable in memory.
            two.send(b'X'); two.command('undo'); two.send(b'\x1bOR')
            two.command('write'); two.wait_file(doc, b'Xbase\n')
            two.command('unbind F3')
            two.wait_output(b'Unbound for this session; keys.conf changed.')
            assert keys.read_bytes() == expected
            one.finish(); two.finish()
        except BaseException:
            if not one.exited(): one.kill()
            if not two.exited(): two.kill()
            raise
        resumed = Session(binary, home, [doc])
        try:
            resumed.command('bind F3 redo')
            resumed.wait_file(keys, expected + b'bind F3 redo\n')
            resumed.finish()
        except BaseException:
            if not resumed.exited(): resumed.kill()
            raise
        count += 1
        print('PASS keymap-concurrent-' + ('existing' if existing else 'new') + '-file-retains-both-sessions', flush=True)

    home = root / 'disabled'; home.mkdir()
    doc = home / 'document'; doc.write_bytes(b'base\n')
    keys = home / 'config/editor/keys.conf'; keys.parent.mkdir(parents=True)
    original = b'bind F2 quit!\n'
    keys.write_bytes(original); keys.chmod(0o600)
    s = Session(binary, home, ['--no-keys', doc])
    try:
        s.send(b'\x1bOQ')
        assert not s.exited()
        s.command('bind F3 redo'); s.wait_output(b'Bindings disabled by --no-keys')
        s.command('unbind F2')
        assert keys.read_bytes() == original
        s.finish()
    except BaseException:
        if not s.exited(): s.kill()
        raise
    count += 1; print('PASS no-keys-does-not-clobber-unloaded-keymap', flush=True)

    home = root / 'invalid'; home.mkdir()
    doc = home / 'document'; doc.write_bytes(b'base\n')
    keys = home / 'config/editor/keys.conf'; keys.parent.mkdir(parents=True)
    original = b'bind F2 undo\n\nunknown entry\nbind F3 redo\n'
    keys.write_bytes(original); keys.chmod(0o600)
    s = Session(binary, home, [doc])
    try:
        s.command('bind F4 write'); s.wait_output(b'keys.conf invalid/unreadable')
        assert keys.read_bytes() == original
        s.send(b'X\x1bOS')
        s.wait_file(doc, b'Xbase\n')
        s.send(b'\x1bOQ\x1bOS'); s.wait_file(doc, b'base\n')
        s.send(b'\x1bOR\x1bOS'); s.wait_file(doc, b'Xbase\n')
        s.finish()
    except BaseException:
        if not s.exited(): s.kill()
        raise
    count += 1; print('PASS invalid-keymap-preserved-while-valid-session-bindings-work', flush=True)
    print(f'PASS: {count} keymap stability terminal groups.', flush=True)


if __name__ == '__main__':
    with tempfile.TemporaryDirectory(prefix='editor-keymap-stability-') as d:
        scenarios(Path(sys.argv[1]).resolve(), Path(d))
