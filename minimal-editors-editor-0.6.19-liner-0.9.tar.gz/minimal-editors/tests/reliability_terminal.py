#!/usr/bin/env python3
"""Additional interactive failure regressions for editor 0.6.5."""
import argparse
from pathlib import Path
import tempfile
from terminal import Session

def file_size_failure(binary, home):
    path=home/'document'
    path.write_bytes(b'original\n')
    s=Session(binary,home,[path],file_limit=512)
    try:
        s.send(b'\x1b[200~'+b'x'*1024+b'\x1b[201~')
        s.command('write')
        assert not s.exited(), f'write killed editor, wait status={s.status}'
        assert path.read_bytes()==b'original\n'
        assert b'Write failed:' in s.data
        assert not list(home.glob('.editor.*')), 'failed save left a staging file'
        s.command('undo')
        s.command('write')
        assert path.read_bytes()==b'original\n'
        s.finish()
    except BaseException:
        s.kill();raise

def parity_input(binary,home):
    path=home/'document'
    path.write_bytes(b'')
    s=Session(binary,home,[path],mark_input=True)
    try:
        s.send(b'\x1b[200~A\xffB\x1b[201~')
        s.command('write')
        assert path.read_bytes()==b'A\xffB', f'input changed: {path.read_bytes()!r}'
        s.finish()
    except BaseException:
        s.kill();raise


def history_size_failure(binary, home):
    path=home/'document'
    path.write_bytes(b'')
    s=Session(binary,home,[path],file_limit=512)
    try:
        for _ in range(24):
            s.send(b'x\x1b[D\x1b[C',settle=.005)
        s.command('write')
        assert not s.exited(), f'history write killed editor: {s.status}'
        assert path.read_bytes()==b'x'*24
        # Wait for the completion/error frame rather than assuming that a
        # save plus failed fsync finishes within Session.send's 50 ms delay.
        s.wait_output(b'undo history could not be persisted',timeout=4)
        s.command('undo 24')
        s.command('write')
        assert not s.exited() and path.read_bytes()==b''
        s.finish()
    except BaseException:
        s.kill();raise

def clipboard_size_failure(binary,home):
    path=home/'document'
    path.write_bytes(b'parent\n')
    s=Session(binary,home,[path],file_limit=512)
    try:
        s.send(b'dirty ')
        s.command('clipboard')
        s.send(b'\x1b[200~'+b'c'*1024+b'\x1b[201~')
        s.command('clipboard')
        assert not s.exited(), f'clipboard save killed editor: {s.status}'
        assert path.read_bytes()==b'parent\n'
        assert b'Write failed:' in s.data
        assert not (home/'state/editor/clipboard.txt').exists()
        s.command('backbof')
        s.command('clipboard')
        s.command('write')
        assert path.read_bytes()==b'dirty parent\n'
        s.finish()
    except BaseException:
        s.kill();raise

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('binary',type=Path)
    parser.add_argument('case',nargs='?',choices=('filesize','parity','history-limit','clipboard-limit','all'),default='all')
    args=parser.parse_args()
    functions={'filesize':file_size_failure,'parity':parity_input,
               'history-limit':history_size_failure,'clipboard-limit':clipboard_size_failure}
    failed=0
    with tempfile.TemporaryDirectory(prefix='editor-terminal-review-') as root:
        for name,fn in functions.items():
            if args.case not in ('all',name):continue
            home=Path(root)/name;home.mkdir()
            try:
                fn(args.binary.resolve(),home)
                print('PASS',name,flush=True)
            except Exception as exc:
                print('FAIL',name,repr(exc),flush=True);failed+=1
    raise SystemExit(1 if failed else 0)
if __name__=='__main__':main()
