/* Optional developer-only libFuzzer target. No additional editor dependency.
 * clang -std=c99 -g -O1 -fsanitize=fuzzer,address,undefined \
 *   tests/input_fuzz.c -o input-fuzz
 * ./input-fuzz -runs=100000 -max_len=4096
 */
#define main editor_program_entry
#ifndef EDITOR_SOURCE
#define EDITOR_SOURCE "../editor.c"
#endif
#include EDITOR_SOURCE
#undef main
#include <assert.h>
int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size)
{
    static int null_input = -1;
    if (size > sizeof input) return 0;
    if (null_input < 0) { null_input = open("/dev/null", O_RDONLY); assert(null_input >= 0); }
    tty_in = null_input;
    input_at = 0; input_n = size;
    if (size) memcpy(input, data, size);
    discard_sequence = discard_last = 0; discard_until = 0;
    paste_discard = false; paste_end_matched = 0;
    terminated = interrupted = suspended = 0;
    mouse_enabled = true; bind_count = 0;
    command_mode = menu_open = false; viewer_text = NULL;
    while (input_at < input_n) {
        size_t before = input_at;
        int c = key();
        assert(input_at > before && input_at <= input_n);
        if (c == KEY_MOUSE) {
            assert(mouse_x > 0 && mouse_x < 10000);
            assert(mouse_y > 0 && mouse_y < 10000);
            assert(mouse_button >= 0 && mouse_button < 256);
        }
    }
    return 0;
}
