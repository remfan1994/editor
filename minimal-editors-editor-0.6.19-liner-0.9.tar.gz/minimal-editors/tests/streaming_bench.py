#!/usr/bin/env python3
"""Linux developer benchmark; compare an extracted prior source package.
python3 tests/streaming_bench.py /path/to/prior/minimal-editors --runs 3
Requires GNU /usr/bin/time, cc and Python; not runtime dependencies.
Peak RSS is maximum process RSS reported by time, not aggregate process RSS.
"""
import argparse
import hashlib
import os
from pathlib import Path
import statistics
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('baseline', type=Path)
parser.add_argument('--runs', type=int, default=3)
a = parser.parse_args()
if not 1 <= a.runs <= 10:
    parser.error('--runs must be 1 through 10')
current = Path(__file__).resolve().parent.parent
with tempfile.TemporaryDirectory(prefix='streaming-bench-') as tmp:
    home = Path(tmp)
    env = dict(os.environ, HOME=tmp, TMPDIR=tmp, TERM='dumb', LC_ALL='C',
               XDG_CONFIG_HOME=tmp + '/config', XDG_STATE_HOME=tmp + '/state')
    cmds = {}
    for label, path in [('baseline', a.baseline.resolve()), ('current', current)]:
        for name in ['editor.c', 'liner.sh']:
            print(label, name, hashlib.sha256((path / name).read_bytes()).hexdigest())
        binary = home / label
        subprocess.run(['cc', '-std=c99', '-O2', '-Wall', '-Wextra', '-Werror', '-pedantic',
                        str(path / 'editor.c'), '-o', str(binary)], check=True)
        cmds[label] = {'editor': [str(binary)], 'liner': ['/bin/sh', str(path / 'liner.sh')]}
    workloads = [
        ('liner', 'edit two million short lines', b'x\n' * 2000000,
         b'change 1\ny\nwrite\nquit\n', b'y'),
        ('editor', '1000 first-line displays of 8 MiB document', b'x\n' + b'a' * (8388608 - 2),
         b'show 1\n' * 1000 + b'quit\n', b'x'),
    ]
    for kind, label, data, commands, first in workloads:
        observations = {k: [] for k in cmds}
        print(kind, label, flush=True)
        for i in range(a.runs):
            for k, options in cmds.items():
                f = home / (kind + '-' + k + '-' + str(i)); f.write_bytes(data)
                timing = home / 'time'
                r = subprocess.run(['/usr/bin/time', '-o', str(timing), '-f', '%e %M'] +
                                   options[kind] + ['--plain', str(f)], input=commands,
                                   stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                                   env=env, timeout=120)
                assert r.returncode == 0 and not r.stderr and f.read_bytes() == first + data[1:], r.stderr
                row = [float(x) for x in timing.read_text().split()]
                observations[k].append(row)
                print(k, i + 1, row, flush=True)
        for k, rows in observations.items():
            print(k, 'median wall seconds, max process RSS KiB:',
                  *(statistics.median(row[i] for row in rows) for i in range(2)))
