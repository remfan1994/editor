/* Keymap concurrency/failure regressions. No installed-editor dependency. */
#define _XOPEN_SOURCE 700
#if defined(__OpenBSD__)
#define _BSD_SOURCE 1
#endif
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static int sync_mutation, post_publish_stat_failure, publish_mutation;
static char *keymap_fixture;
static int injected_sync(int fd);
static int injected_fstat(int fd, struct stat *st);
static int injected_rename(const char *from, const char *to);
#define fsync injected_sync
#define fstat injected_fstat
#define rename injected_rename
#define main editor_program_entry
#ifndef EDITOR_SOURCE
#define EDITOR_SOURCE "../editor.c"
#endif
#include EDITOR_SOURCE
#undef main
#undef rename
#undef fstat
#undef fsync

static const char external_keys[] = "# external version\nbind F7 undo\n";

static void raw_write(const char *path, const char *contents)
{
    size_t n = strlen(contents);
    int fd = open(path, O_CREAT | O_TRUNC | O_WRONLY, 0600);
    assert(fd >= 0 && write_all(fd, contents, n) == 0 && close(fd) == 0);
}

static int injected_sync(int fd)
{
    int result = fsync(fd), mode = sync_mutation;
    if (!result && mode) {
        sync_mutation = 0;
        if (mode == 1) raw_write(keymap_fixture, external_keys);
        else if (mode == 2) assert(unlink(keymap_fixture) == 0);
    }
    return result;
}

static int injected_fstat(int fd, struct stat *st)
{
    int result = fstat(fd, st);
    if (!result && post_publish_stat_failure && keymap_fixture && bindings_version_valid &&
        st->st_dev == bindings_version.st_dev && st->st_ino == bindings_version.st_ino) {
        post_publish_stat_failure = 0;
        errno = EIO;
        return -1;
    }
    return result;
}

static int injected_rename(const char *from, const char *to)
{
    int result = rename(from, to);
    if (!result && publish_mutation && !strcmp(to, keymap_fixture)) {
        struct stat st;
        struct timespec times[2];
        publish_mutation = 0;
        assert(stat(to, &st) == 0);
        raw_write(to, "# editor user-defined keys; no built-in hotkeys\nbind F2 write\nbind F3 undo\n");
        times[0] = st.st_atim; times[1] = st.st_mtim;
        assert(utimensat(AT_FDCWD, to, times, 0) == 0);
    }
    return result;
}

static void check_bytes(const char *expected)
{
    Buffer b = {0};
    struct stat st;
    assert(read_file(keymap_fixture, &b, &st));
    assert(b.n == strlen(expected) && !memcmp(b.s, expected, b.n));
    free(b.s);
}

static int descriptors(void)
{
    int n = 0;
    for (int fd = 0; fd < 1024; fd++) if (fcntl(fd, F_GETFD) >= 0) n++;
    return n;
}

static void prepare(const char *contents)
{
    char home[] = "/tmp/editor-keymap-core-XXXXXX";
    assert(mkdtemp(home));
    assert(setenv("HOME", home, 1) == 0);
    assert(unsetenv("XDG_CONFIG_HOME") == 0);
    free(keymap_fixture);
    keymap_fixture = keymap_path(true);
    assert(keymap_fixture);
    if (contents) raw_write(keymap_fixture, contents);
    keys_disabled = false;
    interrupted = suspended = terminated = 0;
    sync_mutation = post_publish_stat_failure = publish_mutation = 0;
    load_bindings();
}

int main(void)
{
    unsigned groups = 0;
    for (int existing = 0; existing <= 1; existing++) {
        int before, error;
        prepare(existing ? "bind F2 write\n" : NULL);
        assert(bindings_loaded && bindings_version_valid == (existing != 0));
        assert(binding_assign("F3", "redo"));
        before = descriptors(); sync_mutation = 1;
        assert(!save_bindings()); error = errno;
        assert(error == (existing ? EAGAIN : EEXIST));
        assert(descriptors() == before);
        check_bytes(external_keys);
        assert(binding_index(KEY_FUNCTION_BASE + 3) >= 0);
        load_bindings();
        assert(binding_assign("F3", "redo") && save_bindings());
        assert(save_bindings());
        printf("PASS keymap-%s-during-staging-is-preserved-and-reload-recovers\n",
               existing ? "changed" : "created");
        groups++;
    }
    prepare("bind F2 write\n");
    assert(binding_assign("F3", "redo"));
    sync_mutation = 2;
    assert(!save_bindings() && errno == EAGAIN);
    assert(access(keymap_fixture, F_OK) < 0 && errno == ENOENT);
    printf("PASS keymap-removed-during-staging-is-not-recreated\n"); groups++;

    prepare(NULL);
    assert(binding_assign("F3", "redo"));
    post_publish_stat_failure = 1;
    assert(save_bindings() && !post_publish_stat_failure);
    check_bytes("# editor user-defined keys; no built-in hotkeys\nbind F3 redo\n");
    assert(binding_index(KEY_FUNCTION_BASE + 3) >= 0);
    printf("PASS keymap-post-commit-inspection-failure-does-not-report-unsaved\n"); groups++;

    prepare("bind F2 write\n");
    assert(binding_assign("F3", "redo"));
    publish_mutation = 1;
    assert(save_bindings() && !publish_mutation);
    check_bytes("# editor user-defined keys; no built-in hotkeys\nbind F2 write\nbind F3 undo\n");
    assert(binding_assign("F4", "write"));
    assert(!save_bindings() && errno == EAGAIN);
    check_bytes("# editor user-defined keys; no built-in hotkeys\nbind F2 write\nbind F3 undo\n");
    printf("PASS keymap-post-commit-outside-rewrite-is-not-adopted-as-our-version\n"); groups++;

    prepare("# keep\n\nbind F2 undo\n\n  bind\tF3\tredo\n");
    assert(bindings_loaded && bind_count == 2);
    assert(binding_index(KEY_FUNCTION_BASE + 2) >= 0 && binding_index(KEY_FUNCTION_BASE + 3) >= 0);
    printf("PASS keymap-blank-lines-and-whitespace-do-not-hide-later-bindings\n"); groups++;

    prepare("bind F2 undo\nunsupported setting\nbind F3 redo\n");
    assert(!bindings_loaded && bind_count == 2);
    assert(binding_assign("F4", "write") && !save_bindings() && errno == EINVAL);
    check_bytes("bind F2 undo\nunsupported setting\nbind F3 redo\n");
    printf("PASS keymap-invalid-file-cannot-be-overwritten-by-partial-session-table\n"); groups++;

    prepare("bind F2 undo\n");
    keys_disabled = true; load_bindings();
    assert(!bind_count && !bindings_loaded);
    command_set("bind F3 redo"); execute();
    assert(!bind_count && strstr(message, "--no-keys"));
    check_bytes("bind F2 undo\n");
    printf("PASS no-keys-prevents-overwriting-the-deliberately-unloaded-map\n"); groups++;
    for (size_t i = 0; i < command_history_n; i++) free(command_history[i]);
    free(keymap_fixture);
    printf("PASS: %u keymap stability core groups.\n", groups);
    return 0;
}
