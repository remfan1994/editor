#!/usr/bin/env python3
"""Complete sessions through staged-save failures; uses safety_driver.c only."""
from pathlib import Path
import os
import signal
import sys
import tempfile
from unittest.mock import patch
from terminal import Session, set_config


def scenarios(binary, root):
    count = 0

    def run(name, fn, fault='sync-int', cancellation=True, existing=True):
        nonlocal count
        home = root / name
        home.mkdir()
        doc = home / 'original.conf'
        if existing:
            doc.write_bytes(b'original\n')
        if cancellation:
            set_config(home, b'signal_controls=on\n')
        with patch.dict(os.environ, {'EDITOR_TEST_FAULT': fault}):
            s = Session(binary, home, [doc] if existing else [])
        try:
            fn(s, home, doc)
            if not s.exited():
                s.finish()
        except BaseException:
            print('FAIL', name, repr(bytes(s.data[-2000:])), flush=True)
            # finish() closes the PTY on a successful, checked exit.
            if not s.exited():
                s.kill()
            raise
        count += 1
        print('PASS', name, flush=True)

    def paste(s, data):
        s.send(b'\x1b[200~' + data + b'\x1b[201~')

    def collision(s, home, doc):
        paste(s, b'alpha\rbeta\r\n')
        s.command('write new.conf')
        s.wait_output(b'Write failed:')
        assert not (home/'new.conf').exists()
        assert (home/'.editor.INUSE1').read_bytes() == b'KEEP\n'
        s.command('write new.conf')
        s.wait_file(home/'new.conf', b'alpha\nbeta\n')
        s.command('undo'); s.command('write')
        s.wait_file(home/'new.conf', b'')
        s.command('redo'); s.command('write')
        s.wait_file(home/'new.conf', b'alpha\nbeta\n')
        assert (home/'.editor.INUSE1').read_bytes() == b'KEEP\n'
    run('failed-creation-keeps-foreign-file-paste-and-undo', collision,
        fault='temp-collision', existing=False)

    def cancel_new(s, home, doc):
        paste(s, b'new\rfile\n')
        start = len(s.data)
        s.command('write new.conf')
        s.wait_output(b'Command>', start=start)
        assert not (home/'new.conf').exists()
        assert not list(home.glob('.editor.*'))
        s.send(b'write new.conf\r')
        s.wait_file(home/'new.conf', b'new\nfile\n')
        s.command('undo'); s.command('write')
        s.wait_file(home/'new.conf', b'')
        s.command('redo'); s.command('write')
        s.wait_file(home/'new.conf', b'new\nfile\n')
    run('real-interrupt-before-new-file-publish-retries-with-same-draft',
        cancel_new, existing=False)

    def cancel_existing(s, home, doc):
        old_stat = doc.stat()
        paste(s, b'changed\r')
        start = len(s.data)
        s.command('write')
        s.wait_output(b'Command>', start=start)
        assert doc.read_bytes() == b'original\n'
        assert doc.stat().st_ino == old_stat.st_ino
        s.send(b'write\r')
        s.wait_file(doc, b'changed\noriginal\n')
        s.command('undo'); s.command('write')
        s.wait_file(doc, b'original\n')
    run('real-interrupt-keeps-existing-file-and-allows-retry', cancel_existing)

    def native(s, home, doc):
        paste(s, b'draft\n')
        s.command('write should-not-exist.conf')
        s.finish(expected_signal=signal.SIGINT)
        assert not (home/'should-not-exist.conf').exists()
        assert not list(home.glob('.editor.*'))
        assert b'BLOODGUILT CURSE' not in s.data
    run('native-interrupt-exits-without-publishing-new-file', native,
        cancellation=False, existing=False)

    def clip(s, home, doc):
        s.send(b'X'); s.command('clipboard')
        paste(s, b'clip\rtext\r')
        start = len(s.data)
        s.command('clipboard')
        s.wait_output(b'Command>', start=start)
        target=home/'state/editor/clipboard.txt'
        assert not target.exists()
        assert doc.read_bytes() == b'original\n'
        s.send(b'clipboard\r')
        s.wait_file(target,b'clip\ntext\n')
        s.command('write')
        s.wait_file(doc,b'Xoriginal\n')
        s.command('undo'); s.command('write')
        s.wait_file(doc,b'original\n')
    run('interrupted-clipboard-return-keeps-both-buffers', clip)

    def keys(s, home, doc):
        start=len(s.data)
        s.command('bind F2 write')
        s.wait_output(b'Command>', start=start)
        keyfile=home/'config/editor/keys.conf'
        assert not keyfile.exists()
        s.send(b'bind F2 write\r')
        s.wait_file(keyfile,b'# editor user-defined keys; no built-in hotkeys\nbind F2 write\n')
        s.send(b'X\x1bOQ')  # Explicit user-assigned F2, not a default key.
        s.wait_file(doc,b'Xoriginal\n')
    run('interrupted-keymap-save-remains-usable-and-retry-persists', keys)

    def setting(s, home, doc):
        config=home/'config/editor/config'
        before=config.read_bytes()
        start=len(s.data)
        s.command('toggle-mouse')
        s.wait_output(b'Command>',start=start)
        assert config.read_bytes()==before
        s.send(b'toggle-mouse\r')
        s.wait_file(config,b'signal_controls=on\nmouse=on\n')
        assert doc.read_bytes()==b'original\n'
    run('interrupted-setting-save-does-not-change-config-and-retries',setting)
    print(f'PASS: {count} staged-save terminal groups.',flush=True)

if __name__ == '__main__':
    with tempfile.TemporaryDirectory(prefix='editor-staged-') as d:
        scenarios(Path(sys.argv[1]).resolve(),Path(d))
