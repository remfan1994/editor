#!/usr/bin/env python3
"""0.6.8 complete search/clipboard workflows; no production dependencies."""
from pathlib import Path
import os
import signal
import sys
import tempfile
import time
from terminal import Session, set_config


def scenarios(binary, root):
    checks = 0

    def run(name, fn):
        nonlocal checks
        home = root / name
        home.mkdir()
        doc = home / 'sample.conf'
        doc.write_bytes(b'aa aa\nthird aa\n')
        set_config(home, b'signal_controls=on\n')
        session = Session(binary, home, [doc])
        try:
            fn(session, home, doc)
            session.finish()
        except BaseException:
            print('FAIL', name, repr(bytes(session.data[-2000:])), flush=True)
            session.kill()
            raise
        checks += 1
        print('PASS', name, flush=True)

    def save(s, path, expected):
        mark = len(s.data)
        s.command('write')
        s.wait_output(b'Written.', timeout=8, start=mark)
        s.wait_file(path, expected, timeout=8)

    def search(s, home, doc):
        original = doc.read_bytes()
        s.command('find aa'); s.command('n'); s.command('n'); s.command('next')
        s.send(b'X')
        save(s, doc, b'X' + original)
        s.command('undo'); save(s, doc, original)
        s.command('top'); s.command('prev'); s.send(b'Y')
        save(s, doc, b'aa aa\nthird Yaa\n')
        s.command('undo'); save(s, doc, original)
        s.command('replaceall aa => bb')
        save(s, doc, b'bb bb\nthird bb\n')
        s.command('undo'); save(s, doc, original)
        s.command('redo'); save(s, doc, b'bb bb\nthird bb\n')
    run('search-aliases-wrap-and-replacement-history', search)

    def history_error(s, home, doc):
        s.command('copy 1')
        clip = home / 'state/editor/clipboard.txt'
        s.wait_file(clip, b'aa aa\n')
        directory = clip.parent / 'clipboard-history'
        directory.write_bytes(b'not a directory')
        start = len(s.data)
        s.command('clipuse 1')
        s.wait_output(b'Clipboard history scan failed', start=start)
        assert clip.read_bytes() == b'aa aa\n'
        s.command('cliphistory')
        assert b'Clipboard history listing failed' in s.data[start:]
        directory.unlink(); directory.mkdir(mode=0o700)
        entry = directory / ('clip-' + '0'*19 + '1.txt')
        entry.write_bytes(b'restored\n'); entry.chmod(0o600)
        s.command('clipuse 1')
        s.wait_file(clip, b'restored\n')
        s.command('paste'); save(s, doc, b'restored\naa aa\nthird aa\n')
        s.command('undo'); save(s, doc, b'aa aa\nthird aa\n')
    run('history-scan-error-preserves-clipboard-and-recovers', history_error)

    def symlink_history(s, home, doc):
        s.command('copy 1')
        clip = home / 'state/editor/clipboard.txt'
        s.wait_file(clip, b'aa aa\n')
        target = home / 'elsewhere'
        target.mkdir(mode=0o700)
        entry = target / ('clip-' + '9'*20 + '.txt')
        entry.write_bytes(b'not this clipboard\n'); entry.chmod(0o600)
        (clip.parent/'clipboard-history').symlink_to(target)
        s.command('clipuse 1')
        s.wait_output(b'Clipboard history scan failed')
        assert clip.read_bytes() == b'aa aa\n'
        assert entry.read_bytes() == b'not this clipboard\n'
        assert doc.read_bytes() == b'aa aa\nthird aa\n'
    run('history-directory-symlink-is-not-followed', symlink_history)

    def small_clip_search(s, home, doc):
        original = doc.read_bytes()
        s.send(b'X'); s.command('clipboard')
        s.send(b'a a\na a\n'); s.command('find a'); s.command('prev')
        for rows, cols in ((3,12),(5,20),(24,80)):
            s.resize(rows,cols)
            s.command('next');s.command('prev')
        s.command('replaceall a => z');s.command('undo');s.command('redo')
        s.command('clipboard')
        s.wait_file(home/'state/editor/clipboard.txt', b'z z\nz z\n')
        save(s, doc, b'X' + original)
        s.command('undo'); save(s, doc, original)
    run('small-screen-search-in-clipboard-retains-parent', small_clip_search)

    def cancel_replace(s, home, doc):
        big = home/'big.txt'
        content = b'a\n' * (4*1024*1024)
        big.write_bytes(content)
        s.command('read big.txt')
        s.wait_output(b'File opened.', timeout=8)
        start = len(s.data)
        s.send(b'\x1breplaceall a => b\r', settle=0)
        time.sleep(.003)
        os.kill(s.pid, signal.SIGINT)
        s.wait_output(b'Command>', timeout=8, start=start)
        assert not s.exited()
        # Cancellation leaves Command> active, not an editing buffer.
        s.send(b'write\r', settle=.1)
        s.wait_output(b'Already saved (unchanged).', timeout=8, start=start)
        assert big.read_bytes()==content
        s.command('replace a => X'); s.command('write')
        s.wait_file(big,b'X'+content[1:],timeout=8)
        s.command('undo'); save(s,big,content)
        assert doc.read_bytes()==b'aa aa\nthird aa\n'
    run('opt-in-interrupt-cancels-large-replacement-session-stays-usable', cancel_replace)

    print(f'PASS: {checks} reinforcement PTY groups', flush=True)


if __name__ == '__main__':
    with tempfile.TemporaryDirectory(prefix='editor-reinforcement-') as temp:
        scenarios(Path(sys.argv[1]).resolve(),Path(temp))
