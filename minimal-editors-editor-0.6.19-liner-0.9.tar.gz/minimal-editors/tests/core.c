/* Developer regression tests; no test dependencies are needed by editor. */
#if defined(__OpenBSD__)
#define _BSD_SOURCE 1
#endif
#define _XOPEN_SOURCE 700
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stddef.h>
#include <termios.h>
#include <dirent.h>
#include <sys/time.h>
static int fail_directory_fd;
static int injected_dirfd(DIR *d) {
    if (fail_directory_fd) {errno=EBADF;return -1;}
    return dirfd(d);
}
static long allocation_failure = -1;
static size_t allocation_calls, allocation_failures, largest_allocation;
static int fail_allocation;
static int allocation_fails(void) {
    allocation_calls++;
    if (fail_allocation || allocation_failure == 0) {
        allocation_failure=-1; allocation_failures++; errno=ENOMEM; return 1;
    }
    if (allocation_failure > 0) allocation_failure--;
    return 0;
}
static void *injected_malloc(size_t n) { if(n>largest_allocation)largest_allocation=n; return allocation_fails() ? NULL : malloc(n); }
static void *injected_calloc(size_t n, size_t m) { if(m && n<=SIZE_MAX/m && n*m>largest_allocation)largest_allocation=n*m; return allocation_fails() ? NULL : calloc(n,m); }
static void *injected_realloc(void *p, size_t n) { if(n>largest_allocation)largest_allocation=n; return allocation_fails() ? NULL : realloc(p,n); }
static char *injected_strdup(const char *p) { return allocation_fails() ? NULL : strdup(p); }
static char *injected_strndup(const char *p, size_t n) { return allocation_fails() ? NULL : strndup(p,n); }
static int track_io;
static size_t io_reads, io_writes, io_read_bytes, io_write_bytes, short_io;
static long read_budget=-1, write_budget=-1;
static int directory_fail_after=-1, directory_stop_after=-1, directory_close_fail;
static struct dirent *injected_readdir(DIR *);
static int injected_closedir(DIR *);
static ssize_t injected_read(int, void *, size_t);
static void (*sync_hook)(void);
static int fail_sync, fail_rename;
static int fail_sync_after=-1;
static int fail_screen_write;
static int fail_terminal_attr;
static int injected_tcsetattr(int, int, const struct termios *);
static ssize_t injected_write(int, const void *, size_t);
static int injected_sync(int fd) {
    if(sync_hook) { void (*hook)(void)=sync_hook;sync_hook=NULL;hook(); }
    if (fail_sync || fail_sync_after==0) { errno=EIO; return -1; }
    if (fail_sync_after>0) fail_sync_after--;
    return fsync(fd);
}
static int injected_rename(const char *a,const char *b) {
    if (fail_rename) { errno=EIO; return -1; }
    return rename(a,b);
}
#define malloc injected_malloc
#define calloc injected_calloc
#define realloc injected_realloc
#define strdup injected_strdup
#define strndup injected_strndup
#define read injected_read
#define fsync injected_sync
#define rename injected_rename
#define write injected_write
#define tcsetattr injected_tcsetattr
#define readdir injected_readdir
#define closedir injected_closedir
#define dirfd injected_dirfd
#define main editor_main
#ifndef EDITOR_SOURCE
#define EDITOR_SOURCE "../editor.c"
#endif
#include EDITOR_SOURCE
#undef main
#undef malloc
#undef calloc
#undef realloc
#undef strdup
#undef strndup
#undef read
#undef fsync
#undef rename
#undef write
#undef tcsetattr
#undef readdir
#undef closedir
#undef dirfd
#include <assert.h>

static struct dirent *injected_readdir(DIR *d) {
    struct dirent *entry;
    if(directory_fail_after==0) {errno=EIO;return NULL;}
    entry=readdir(d);
    if(entry && strcmp(entry->d_name,".") && strcmp(entry->d_name,"..")) {
        if(directory_fail_after>0)directory_fail_after--;
        if(directory_stop_after>0 && --directory_stop_after==0)interrupted=1;
    }
    return entry;
}
static int injected_closedir(DIR *d) {
    int result=closedir(d);
    if(directory_close_fail) {directory_close_fail=0;errno=EIO;return -1;}
    return result;
}

static int injected_tcsetattr(int fd, int action, const struct termios *attr) {
    if (fail_terminal_attr) {
        if (fail_terminal_attr==1) interrupted=1;
        fail_terminal_attr=0;errno=EINTR;return -1;
    }
    return tcsetattr(fd,action,attr);
}

static ssize_t injected_write(int fd, const void *data, size_t n) {
    if (fail_screen_write && fd == tty_out) {
        fail_screen_write=0; interrupted=1; errno=EINTR; return -1;
    }
    if(write_budget==0) {errno=EIO;return -1;}
    if(write_budget>0 && n>(size_t)write_budget) n=(size_t)write_budget;
    if(short_io && n>short_io)n=short_io;
    {
        ssize_t got=write(fd,data,n);
        if(track_io) {io_writes++; if(got>0)io_write_bytes+=(size_t)got;}
        if(got>0 && write_budget>0)write_budget-=got;
        return got;
    }
}
static ssize_t injected_read(int fd, void *data, size_t n) {
    if(read_budget==0) {errno=EIO;return -1;}
    if(read_budget>0 && n>(size_t)read_budget)n=(size_t)read_budget;
    if(short_io && n>short_io)n=short_io;
    {
        ssize_t got=read(fd,data,n);
        if(track_io) {io_reads++;if(got>0)io_read_bytes+=(size_t)got;}
        if(got>0 && read_budget>0)read_budget-=got;
        return got;
    }
}

static unsigned checks;
static char test_home[512];
static void pass(const char *name) { printf("ok %u - %s\n",++checks,name); }
static int descriptors(void) {
    int i,n=0;
    for(i=0;i<1024;i++) if(fcntl(i,F_GETFD)>=0)n++;
    return n;
}
static void write_bytes(const char *path,const char *s,size_t n) {
    int fd=open(path,O_WRONLY|O_CREAT|O_TRUNC,0600);
    assert(fd>=0); assert(write_all(fd,s,n)==0); assert(close(fd)==0);
}
static void check_bytes(const char *path,const char *s,size_t n) {
    Buffer b={0};struct stat st;
    assert(read_file(path,&b,&st));assert(b.n==n);assert(!n||!memcmp(b.s,s,n));free(b.s);
}
static void command_run(const char *s) { command_set(s);execute(); }
static void reset_doc(const char *data) {
    size_t i;
    assert(!editing_clipboard);
    free_changes(history);history=current=history_tail=NULL;
    free(text.s);memset(&text,0,sizeof text);free(saved.s);memset(&saved,0,sizeof saved);
    free(filename);filename=NULL;free(loaded_journal_path);loaded_journal_path=NULL;
    clear_prompt();reset_screen();
    for(i=0;i<command_history_n;i++)free(command_history[i]);
    memset(command_history,0,sizeof command_history);command_history_n=0;
    assert(copy_buffer(&text,data,strlen(data)));assert(copy_buffer(&saved,data,strlen(data)));
    cursor=top=left=goal=0;goal_set=group=false;
    journal_ignored=journal_dirty=journal_rebased=journal_branched=false;existed=false;
    memset(&original,0,sizeof original);newline[0]='\n';newline[1]=0;newline_n=1;
    search_length=0;search_pattern[0]=0;search_mark=SIZE_MAX;
    movement_mode=command_mode=filename_mode=filename_read_mode=menu_open=menu_argument_mode=false;
    menu_argument_command=menu_argument_label=NULL;viewer_text=viewer_title=NULL;reverse_mode=false;
    clipboard_leave_after_save=false;menu_discard_pending=false;running=true;
    ordinary_quit=false;signal_controls=0;
    interrupted=terminated=suspended=resized=0;
    command_set("");message[0]=0;history_suppress=false;
}
static void attach_file(const char *base) {
    char path[1024]; snprintf(path,sizeof path,"%s/%s",test_home,base);
    filename=strdup(path);assert(filename);
    write_bytes(path,text.s,text.n);assert(stat(path,&original)==0);existed=true;
}
static void forget_history(void) {
    free_changes(history);history=current=history_tail=NULL;
    free(loaded_journal_path);loaded_journal_path=NULL;
    journal_ignored=journal_dirty=journal_rebased=journal_branched=false;group=false;
}
static void test_modes_config(void) {
    char *path,*keys,normal[24];Buffer b={0};int fd;
    reset_doc("abc\nsecond\n");
    assert(!command_lookup("mode"));assert(command_lookup("movement"));assert(command_lookup("edit"));
    command_run("movement");assert(movement_mode);
    text_key('l');assert(cursor==1);text_key('!');text_key(127);text_key(KEY_DELETE);
    assert(!strcmp(text.s,"abc\nsecond\n"));
    command_run("edit");assert(!movement_mode);text_key('X');assert(!strcmp(text.s,"aXbc\nsecond\n"));
    command_run("movement garbage");assert(!movement_mode);
    pass("movement/edit commands; navigation never deletes or inserts");
    path=config_path("config",true);assert(path);keys=keymap_path(true);assert(keys);
    unlink(path);movement_mode=false;startup_config_warning=false;load_startup_config();
    assert(!movement_mode&&!startup_config_warning);
    write_bytes(path,"# preferences\nstartup = movement # note\n",39);
    load_startup_config();assert(movement_mode&&!startup_config_warning);
    write_bytes(path,"startup=edit\r\n",14);load_startup_config();assert(!movement_mode);
    write_bytes(path,"startup=nonsense\n",17);startup_config_warning=false;load_startup_config();
    assert(!movement_mode&&startup_config_warning);
    write_bytes(path,"startup=movement\0evil",21);startup_config_warning=false;load_startup_config();
    assert(!movement_mode&&startup_config_warning);
    unlink(path);assert(mkfifo(path,0600)==0);assert(read_config("config",&b)==-1);unlink(path);
    assert(symlink("missing",path)==0);assert(read_config("config",&b)==-1);unlink(path);
    fd=open(path,O_WRONLY|O_CREAT,0600);assert(fd>=0);assert(ftruncate(fd,32769)==0);close(fd);
    assert(read_config("config",&b)==-1);unlink(path);free(b.s);
    pass("startup config: whitespace, CRLF, invalid/NUL/special/oversized files");
    write_bytes(keys,"bind F2 movement\nbind F3 edit\n",29);bind_count=0;load_bindings();
    assert(bind_count==2);assert(!strcmp(binding_action(KEY_FUNCTION_BASE+2),"movement"));
    assert(hotkey_code("F4294967297",normal)<0);
    assert(hotkey_code("F99999999999999999999999999999999999999",normal)<0);
    assert(hotkey_code("Ctrl+",normal)<0);assert(hotkey_code("Alt+",normal)<0);
    assert(hotkey_code("F12",normal)==KEY_FUNCTION_BASE+12);
    pass("keymap loading; oversized function numbers and incomplete names refused");
    unlink(keys);free(path);free(keys);bind_count=0;
}
static void test_failures(void) {
    int before,i;char *jp,*kp;Buffer oldj={0},oldk={0};struct stat st;
    reset_doc("original");attach_file("faults.txt");assert(edit(text.n,0,"!",1,false));
    load_bindings(); /* Startup captures the current keymap version/absence. */
    assert(journal_save());assert(save_bindings());jp=journal_path(filename);kp=keymap_path(false);
    assert(read_file(jp,&oldj,&st));assert(read_file(kp,&oldk,&st));
    before=descriptors();fail_sync=1;
    for(i=0;i<100;i++) { assert(!journal_save());assert(!save_bindings()); }
    fail_sync=0;assert(descriptors()==before);check_bytes(jp,oldj.s,oldj.n);check_bytes(kp,oldk.s,oldk.n);
    pass("200 forced sync failures: zero descriptor leaks; old journal/keymap retained");
    fail_sync=1;save_file(NULL,false);fail_sync=0;
    check_bytes(filename,"original",8);assert(changed());assert(!strcmp(text.s,"original!"));
    fail_rename=1;save_file(NULL,false);fail_rename=0;
    check_bytes(filename,"original",8);assert(changed());assert(descriptors()==before);
    save_file(NULL,false);assert(!changed());check_bytes(filename,"original!",9);
    st=original;save_file(NULL,false);assert(original.st_ino==st.st_ino);assert(same_disk_version(&original,&st));
    pass("failed file sync/rename preserve disk and buffer; unchanged write preserves inode");
    free(jp);free(kp);free(oldj.s);free(oldk.s);
}
static void test_commands(void) {
    reset_doc("one\r\ntwo\r\nthree\r\n");cursor=1;
    command_run("deleol");assert(!strcmp(text.s,"o\r\ntwo\r\nthree\r\n"));
    command_run("undo");assert(!strcmp(text.s,"one\r\ntwo\r\nthree\r\n"));
    cursor=4;command_run("deleol");assert(!strcmp(text.s,"one\r\ntwo\r\nthree\r\n"));
    cursor=5;command_run("deleof");assert(!strcmp(text.s,"one\r\n"));command_run("undo");
    cursor=5;command_run("backbof");assert(!strcmp(text.s,"two\r\nthree\r\n"));command_run("undo");
    command_run("dline 2-3");assert(!strcmp(text.s,"one\r\n"));command_run("undo");
    command_run("dline 4-999");assert(!strcmp(text.s,"one\r\ntwo\r\nthree\r\n"));
    command_run("dline 184467440737095516161");assert(!strcmp(text.s,"one\r\ntwo\r\nthree\r\n"));
    pass("boundary and ranged deletion: CRLF, invalid counts, undo");
    reset_doc("one one\none\n");command_run("find one");assert(cursor==0);
    command_run("n");assert(cursor==4);command_run("p");assert(cursor==0);
    command_run("replaceall one => two");assert(!strcmp(text.s,"two two\ntwo\n"));
    assert(undo_depth()==1);command_run("undo");assert(!strcmp(text.s,"one one\none\n"));
    command_run("redo");assert(!strcmp(text.s,"two two\ntwo\n"));
    pass("find next/previous and replaceall as one reversible operation");
    reset_doc("abc");
    assert(!copy_buffer(&saved,NULL,1));assert(!copy_buffer(&saved,"x",SIZE_MAX));
    assert(!strcmp(saved.s,"abc"));
    { Buffer bad={NULL,0,128};
      errno=0;assert(!reserve(&bad,1)&&errno==EINVAL&&!bad.s);
      bad.cap=0;bad.n=1;assert(reserve(&bad,2)&&bad.s);free(bad.s);
    }
    assert(!edit(99,1,"z",1,false));assert(!edit(0,99,"z",1,false));assert(!edit(1,0,NULL,1,false));
    assert(!strcmp(text.s,"abc")&&!history);
    menu_argument_mode=true;command_mode=true;menu_argument_command=NULL;command_set("bad");
    command_key('\r');assert(!menu_argument_mode&&!command_mode);
    pass("invalid edit offsets and inconsistent prompt state do not corrupt text");
}
static void test_persistence(void) {
    char *jp;Buffer raw={0};struct stat st;size_t i;
    reset_doc("before\n");attach_file("persist.txt");assert(edit(0,6,"after",5,false));save_file(NULL,false);
    jp=journal_path(filename);assert(read_file(jp,&raw,&st));
    forget_history();journal_load();assert(history&&!journal_ignored);assert(history_step(false));
    assert(!strcmp(text.s,"before\n"));assert(history_step(true));assert(!strcmp(text.s,"after\n"));
    pass("cross-session undo and redo restore exact contents");
    for(i=0;i<raw.n;i+=raw.n/19+1) {
        char c=raw.s[i];raw.s[i]^=1;write_bytes(jp,raw.s,raw.n);raw.s[i]=c;
        forget_history();journal_load();assert(!history&&journal_ignored);assert(!strcmp(text.s,"after\n"));
    }
    write_bytes(jp,raw.s,raw.n/2);forget_history();journal_load();assert(!history&&journal_ignored);
    write_bytes(jp,raw.s,raw.n);forget_history();
    assert(copy_buffer(&text,"external\n",9));assert(copy_buffer(&saved,text.s,text.n));journal_load();
    assert(journal_rebased&&history);assert(history_step(false));assert(!strcmp(text.s,"after\n"));
    assert(history_step(false));assert(!strcmp(text.s,"before\n"));
    pass("damaged/truncated journals refused; outside edit becomes one undo");
    free(raw.s);free(jp);
}
static void test_clipboards(void) {
    int i,before;size_t depth;char *p;
    reset_doc("original\nsecond\n");attach_file("parent.txt");assert(edit(0,0,"unsaved ",8,false));
    cursor=10;depth=undo_depth();command_run("find second");cursor=10;
    assert(clipboard_choose("review"));before=descriptors();
    for(i=0;i<100;i++) {
        clipboard_open();assert(editing_clipboard);
        assert(edit(0,text.n,"clipboard content\n",18,false));
        if(i==0) {
            fail_sync=1;clipboard_open();fail_sync=0;
            assert(editing_clipboard&&changed());
            assert(!strcmp(parent_document.text.s,"unsaved original\nsecond\n"));
        }
        clipboard_open();assert(!editing_clipboard);assert(cursor==10&&undo_depth()==depth);
        assert(!strcmp(text.s,"unsaved original\nsecond\n"));assert(!strcmp(search_pattern,"second"));
    }
    assert(descriptors()==before);p=clipboard_path(false);check_bytes(p,"clipboard content\n",18);free(p);
    command_run("clipboard 2");command_run("copy 2");command_run("paste 2");
    assert(!strcmp(text.s,"second\nunsaved original\nsecond\n"));command_run("undo");
    assert(!strcmp(text.s,"unsaved original\nsecond\n"));
    pass("100 clipboard round trips: parent text/cursor/search/history retained, no fd leak");
}
static unsigned rng=0x6a9ce19u;
static unsigned rand32(void) { rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng; }
static void test_random(void) {
    char **states=calloc(30001,sizeof *states);size_t pos=0,tail=0,i;
    assert(states);reset_doc("seed");attach_file("random.txt");states[0]=strdup(text.s);assert(states[0]);
    for(i=0;i<30000;i++) {
        unsigned op=rand32()%5;
        if(op<3) {
            char buf[2048],insert[16];size_t at=rand32()%(text.n+1),old,n,j,len;
            old=text.n-at;if(old>16)old=16;old=rand32()%(old+1);
            n=1+rand32()%12;if(text.n>1000)n=0;
            for(j=0;j<n;j++)insert[j]="abXYZ \t\n\r"[rand32()%9];
            len=text.n-old+n;assert(len<sizeof buf);
            memcpy(buf,text.s,at);memcpy(buf+at,insert,n);memcpy(buf+at+n,text.s+at+old,text.n-at-old);buf[len]=0;
            cursor=rand32()%(text.n+1);assert(edit(at,old,insert,n,false));
            if(old||n) {
                while(tail>pos) free(states[tail--]);
                states[++pos]=strdup(buf);assert(states[pos]);tail=pos;
            }
        } else if(op==3&&pos) { assert(history_step(false));pos--; }
        else if(op==4&&pos<tail) { assert(history_step(true));pos++; }
        assert(!strcmp(text.s,states[pos]));assert(cursor<=text.n);assert(undo_depth()==pos);
        assert(redo_depth()==tail-pos);
        if(i%5000==4999) {
            assert(copy_buffer(&saved,text.s,text.n));assert(journal_save());forget_history();journal_load();
            assert(!journal_ignored);assert(undo_depth()==pos&&redo_depth()==tail-pos);
        }
    }
    for(i=0;i<=tail;i++) free(states[i]);
    free(states);
    pass("30000 randomized edit/undo/redo transitions against independent snapshots");
}

static void test_reserved_slot(void) {
    char *selector;Buffer b={0};struct stat st;
    reset_doc("keep\n");
    assert(clipboard_choose("review"));
    selector=state_path("clipboard-selected.txt",false);assert(selector);
    assert(!clipboard_slot_valid("selected"));
    command_run("clipboard selected");
    assert(!strcmp(selected_clipboard,"review"));
    command_run("copy 1");
    assert(read_file(selector,&b,&st));assert(!strcmp(b.s,"review"));
    clipboard_list();assert(!strstr(clipboard_page,"slot clipboard-selected.txt"));
    free(selector);free(b.s);viewer_text=viewer_title=NULL;
    pass("reserved clipboard metadata cannot be selected, overwritten or listed as a clip");
}
static void test_mouse_prompt(void) {
    int k;
    reset_doc("preserved\n");mouse_enabled=true;rows=24;cols=80;
    for(k=0;k<3;k++) {
        if(k<2) ask_filename(k!=0);
        else command_run("replace");
        assert(command_mode);
        mouse_button=0;mouse_pressed=true;mouse_y=rows-1;mouse_x=2;
        mouse_key();assert(menu_open);
        assert(!command_mode&&!filename_mode&&!filename_read_mode&&!menu_argument_mode);
        menu_key('h');text_key(KEY_ESCAPE);
        command_set("history");command_key('\r');
        assert(!strcmp(text.s,"preserved\n")&&!filename);
        assert(!command_mode&&!filename_mode&&!menu_argument_mode);
    }
    mouse_enabled=false;
    pass("mouse menu entry cancels obsolete filename and replacement prompt state");
}
static void test_redraw_cancel(void) {
    int fd=open("/dev/null",O_WRONLY);assert(fd>=0);
    reset_doc("never lose this\n");tty_out=fd;rows=24;cols=80;
    fail_screen_write=1;draw();
    assert(interrupted&&!terminated);assert(!strcmp(text.s,"never lose this\n"));
    assert(!previous_rows);assert(resized);
    interrupted=0;draw();assert(previous_rows);
    reset_screen();close(fd);tty_out=STDOUT_FILENO;resized=0;
    pass("cancelled terminal output invalidates cache and repaints document");
}
static void test_clipboard_warning(void) {
    char path[1024];int fd;Buffer screen={0};struct stat st;
    reset_doc("parent\n");clipboard_open();assert(editing_clipboard);
    assert(edit(0,text.n,"scratch",7,false));
    fail_sync=1;save_file(NULL,false);fail_sync=0;
    assert(changed());assert(strstr(message,"Write failed"));
    snprintf(path,sizeof path,"%s/tty-warning",test_home);
    fd=open(path,O_CREAT|O_RDWR|O_TRUNC,0600);assert(fd>=0);tty_out=fd;
    rows=24;cols=120;draw();close(fd);tty_out=STDOUT_FILENO;reset_screen();
    assert(read_file(path,&screen,&st));assert(strstr(screen.s,"Write failed"));
    free(screen.s);clipboard_return();
    pass("clipboard save failure is visible rather than hidden by return hint");
}
static void test_history_interrupt(void) {
    size_t done;int i;
    reset_doc("seed");
    for(i=0;i<32;i++) assert(edit(text.n,0,"x",1,false));
    interrupted=1;done=history_move(false,32,true);
    assert(done==0&&undo_depth()==32);interrupted=0;
    assert(history_move(false,15,true)==15);assert(undo_depth()==17);
    suspended=1;assert(history_move(true,15,true)==0);suspended=0;
    terminated=SIGTERM;assert(history_move(false,32,true)==0);terminated=0;
    assert(history_move(true,15,true)==15);assert(undo_depth()==32);
    pass("counted history navigation observes pending interrupts without losing state");
}
static bool archive_contains(const char *journal,const Buffer *want) {
    char *dir=strdup(journal),*slash;const char *base;DIR *d;struct dirent *ent;bool found=false;
    assert(dir);slash=strrchr(dir,'/');assert(slash);*slash=0;base=strrchr(journal,'/')+1;
    d=opendir(dir);assert(d);
    while((ent=readdir(d))) if(!strncmp(ent->d_name,base,strlen(base)) && strstr(ent->d_name,".stale.")) {
        char path[2048];Buffer b={0};struct stat st;
        snprintf(path,sizeof path,"%s/%s",dir,ent->d_name);
        if(read_file(path,&b,&st)&&same_bytes(&b,want))found=true;
        free(b.s);
    }
    closedir(d);free(dir);return found;
}
static void test_other_journal(void) {
    DocumentContext older;char *jp,*path;Buffer other={0};struct stat st;
    reset_doc("start");attach_file("two-editors.txt");
    assert(edit(text.n,0,"A",1,false));save_file(NULL,false);assert(!changed());
    jp=journal_path(filename);path=strdup(filename);assert(jp&&path);
    document_capture(&older);read_document(path);assert(filename);
    assert(edit(text.n,0,"B",1,false));assert(edit(text.n-1,1,NULL,0,false));
    /* A second editor saves a different history while bytes stay identical. */
    assert(!changed());save_file(NULL,false);assert(read_file(jp,&other,&st));
    document_restore(&older);
    assert(edit(text.n,0,"C",1,false));save_file(NULL,false);
    assert(!changed());assert(archive_contains(jp,&other));
    free(other.s);free(path);free(jp);
    pass("another editor's journal is archived even when document bytes are unchanged");
}
static void test_viewer_columns(void) {
    const char *sample="123456789\tABC\n";size_t end,next;
    reset_doc("");open_viewer("test",sample);
    next=viewer_row(0,11,&end);
    /* The tab at column 9 expands past column 11 and must move to another row. */
    assert(end==9&&next==9);
    next=viewer_row(next,11,&end);assert(end==13&&next==14);
    /* Long UTF-8 names must not be split within a multi-byte unit. */
    if(setlocale(LC_CTYPE,"C.UTF-8")) {
        const char utf[]="\xe7\x95\x8c\xe7\x95\x8c\xe7\x95\x8c\xe7\x95\x8c\xe7\x95\x8c\xe7\x95\x8c";
        open_viewer("test",utf);next=viewer_row(0,11,&end);
        assert(end==15&&next==15);assert(viewer_rows(11)==2);
    }
    viewer_text=viewer_title=NULL;setlocale(LC_CTYPE,"C");
    pass("viewer wraps tabs and UTF-8 by display columns without losing text");
}

static char *race_journal;
static void replace_racing_journal(void) {
    char path[2048];
    snprintf(path,sizeof path,"%s.other",race_journal);
    write_bytes(path,"another writer's journal",24);
    assert(rename(path,race_journal)==0);
}
static void test_journal_save_races(void) {
    char *jp;int before;
    reset_doc("history");attach_file("journal-race.txt");
    assert(edit(text.n,0,"1",1,false));save_file(NULL,false);assert(!changed());
    jp=journal_path(filename);assert(jp);race_journal=jp;before=descriptors();
    assert(edit(text.n,0,"2",1,false));sync_hook=replace_racing_journal;
    assert(!journal_save());assert(!sync_hook);assert(journal_dirty);
    check_bytes(jp,"another writer's journal",24);
    assert(!strcmp(text.s,"history12"));assert(descriptors()==before);
    assert(unlink(jp)==0);sync_hook=replace_racing_journal;
    assert(!journal_save());assert(!sync_hook);assert(journal_dirty);
    check_bytes(jp,"another writer's journal",24);assert(descriptors()==before);
    assert(journal_save());assert(!journal_dirty);
    free(jp);race_journal=NULL;
    pass("intervening journal replacement/creation is not overwritten during staging");
}
static size_t archive_count(const char *journal) {
    char *dir=strdup(journal),*slash=strrchr(dir,'/');const char *base=strrchr(journal,'/')+1;
    DIR *d;struct dirent *ent;size_t n=0;
    assert(slash);*slash=0;d=opendir(dir);assert(d);
    while((ent=readdir(d)))if(!strncmp(ent->d_name,base,strlen(base))&&strstr(ent->d_name,".stale."))n++;
    closedir(d);free(dir);return n;
}
static void test_journal_growth(void) {
    char *jp;int i,before;
    reset_doc("same text");attach_file("bounded-archives.txt");
    assert(journal_save());jp=journal_path(filename);assert(jp);
    before=descriptors();assert(archive_count(jp)==0);
    for(i=0;i<80;i++) {
        assert(edit(text.n,0,"x",1,false));assert(edit(text.n-1,1,NULL,0,false));
        assert(!changed());save_file(NULL,false);assert(!journal_dirty);
        if(i%10==0) { clipboard_open();assert(editing_clipboard);clipboard_open();assert(!editing_clipboard); }
    }
    assert(archive_count(jp)==0);assert(descriptors()==before);
    free(jp);pass("ordinary repeated saves/context switches do not create needless history archives");
}

static void test_review(const char *which) {
    if(!which||!strcmp(which,"slot"))test_reserved_slot();
    if(!which||!strcmp(which,"mouse"))test_mouse_prompt();
    if(!which||!strcmp(which,"redraw"))test_redraw_cancel();
    if(!which||!strcmp(which,"warning"))test_clipboard_warning();
    if(!which||!strcmp(which,"history"))test_history_interrupt();
    if(!which||!strcmp(which,"journal"))test_other_journal();
    if(!which||!strcmp(which,"viewer"))test_viewer_columns();
    if(!which||!strcmp(which,"journal-race"))test_journal_save_races();
    if(!which||!strcmp(which,"journal-growth"))test_journal_growth();
}


/* 0.6.4 review: failures missing from the previous suites. */
static void io_begin(void) {
    io_reads=io_writes=io_read_bytes=io_write_bytes=0;track_io=1;
}
static void test_buffered_history(void) {
    int i;
    size_t writes,reads;
    reset_doc("0\n");attach_file("io-history.txt");
    for(i=0;i<10000;i++) { char ch=(i&1)?'0':'1';assert(edit(0,1,&ch,1,false)); }
    io_begin();assert(journal_save());writes=io_writes;track_io=0;
    forget_history();io_begin();journal_load();reads=io_reads;track_io=0;
    assert(!journal_ignored && undo_depth()==10000);
    printf("METRIC 10000 history entries: %zu write calls, %zu read calls\n",writes,reads);
    assert(writes<1000 && reads<2000);
    assert(history_move(false,10000,true)==10000);assert(!strcmp(text.s,"0\n"));
    assert(history_move(true,10000,true)==10000);assert(!strcmp(text.s,"0\n"));
    pass("10,000-entry history uses bounded buffered I/O and remains fully reversible");
}
static void test_short_and_failed_io(void) {
    char *jp;Buffer prior={0};struct stat st;size_t i;int before;
    reset_doc("alpha\n");attach_file("short-io.txt");
    for(i=0;i<20;i++)assert(edit(text.n,0,"x",1,false));
    assert(copy_buffer(&saved,text.s,text.n));
    short_io=3;assert(journal_save());forget_history();journal_load();short_io=0;
    assert(!journal_ignored && undo_depth()==20);
    jp=journal_path(filename);assert(jp);assert(read_file(jp,&prior,&st));before=descriptors();
    for(i=0;i<10;i++) {
        write_budget=(long)(i*17);assert(!journal_save());write_budget=-1;
        assert(descriptors()==before);check_bytes(jp,prior.s,prior.n);
    }
    forget_history();read_budget=57;journal_load();read_budget=-1;
    assert(journal_ignored && !history);assert(!strcmp(text.s,"alpha\nxxxxxxxxxxxxxxxxxxxx"));
    forget_history();journal_load();assert(!journal_ignored && undo_depth()==20);
    /* A trailing byte must not hide in the reader's prefetched data. */
    { int fd=open(jp,O_WRONLY|O_APPEND);assert(fd>=0);assert(write(fd,"x",1)==1);close(fd); }
    forget_history();journal_load();assert(journal_ignored&&!history);
    free(jp);free(prior.s);
    pass("short reads/writes, midstream failures and trailing history bytes are handled safely");
}
static void test_clip_warning_retained(void) {
    char *cp;const char *actions[]={"copy 1","cut 1"};size_t i;
    clip_history_enabled=true;
    for(i=0;i<2;i++) {
        reset_doc("one\ntwo\n");selected_clipboard[0]=0;
        cp=clipboard_path(true);assert(cp);write_bytes(cp,"OLD\n",4);
        fail_sync_after=2;command_run(actions[i]);fail_sync_after=-1;
        check_bytes(cp,"one\n",4);
        assert(strstr(message,"history"));
        assert(!strcmp(text.s,i ? "two\n" : "one\ntwo\n"));
        free(cp);
    }
    clip_history_enabled=false;
    pass("copy/cut retain optional clipboard-history failure warning after successful update");
}
static void test_preview_budget(void) {
    char *dir=state_path("clipboard-history",true),path[1024];size_t i,bytes,calls;
    assert(dir&&private_directory(dir));
    /* Use sparse files: large logical size without filling test disks. */
    for(i=0;i<64;i++) {
        int fd;
        snprintf(path,sizeof path,"%s/clip-%020zu.txt",dir,i+1);
        fd=open(path,O_WRONLY|O_CREAT|O_TRUNC,0600);assert(fd>=0);
        assert(write(fd,"preview text\n",13)==13);assert(ftruncate(fd,1048576)==0);close(fd);
    }
    calls=allocation_calls;io_begin();clip_history_list();bytes=io_read_bytes;track_io=0;
    calls=allocation_calls-calls;
    printf("METRIC 64-entry clipboard history listing allocations: %zu\n",calls);
    printf("METRIC 64 x 1 MiB clipboard history: %zu bytes read for previews\n",bytes);
    assert(bytes<=64*64);assert(strstr(clipboard_page,"1048576 bytes"));
    assert(strstr(clipboard_page,"preview text"));viewer_text=viewer_title=NULL;
    for(i=0;i<64;i++) {snprintf(path,sizeof path,"%s/clip-%020zu.txt",dir,i+1);unlink(path);}
    free(dir);
    pass("clipboard history reads only short prefixes, not every full historical file");
}
static void test_allocation_failures(void) {
    size_t i,j,start_failures=allocation_failures;
    for(i=0;i<32;i++) {
        reset_doc("abc\ndef\n");cursor=1;
        allocation_failure=(long)i;
        {bool ok=edit(1,3,"replacement",11,false);allocation_failure=-1;
         assert(!strcmp(text.s,ok ? "areplacementdef\n" : "abc\ndef\n"));
         if(ok){assert(history_step(false));assert(!strcmp(text.s,"abc\ndef\n"));}}
    }
    for(i=0;i<32;i++) {
        reset_doc("abc abc\n");allocation_failure=(long)i;
        run_replacement("abc","xy",true);allocation_failure=-1;
        assert(!strcmp(text.s,"abc abc\n")||!strcmp(text.s,"xy xy\n"));
        if(history){assert(history_step(false));assert(!strcmp(text.s,"abc abc\n"));}
    }
    /* Opening a clipboard moves ownership, never copies/frees the dirty parent. */
    for(i=0;i<64;i++) {
        reset_doc("parent\n");assert(edit(0,0,"dirty ",6,false));
        cursor=3;allocation_failure=(long)i;clipboard_open();allocation_failure=-1;
        if(editing_clipboard)clipboard_return();
        assert(!strcmp(text.s,"dirty parent\n")&&cursor==3&&undo_depth()==1&&changed());
    }
    reset_doc("state\n");attach_file("oom-journal.txt");
    for(j=0;j<12;j++)assert(edit(text.n,0,"z",1,false));
    assert(copy_buffer(&saved,text.s,text.n));assert(journal_save());
    for(i=0;i<80;i++) {
        forget_history();allocation_failure=(long)i;journal_load();allocation_failure=-1;
        assert(text.n==18&&cursor<=text.n);
        if(history)assert(undo_depth()==12);
    }
    printf("METRIC 208 allocation-failure positions: %zu failures actually reached\n",allocation_failures-start_failures);
    pass("208 allocation-failure positions preserve complete edits, parent context and history safety");
}
static void test_mouse_numbers(void) {
    static const char *bad[]={"\033[<4294967296;1;1M","\033[<0;4294967297;1M", "\033[<0;1;4294967297M", "\033[<+0;1;1M", "\033[<0;0;1M"};
    size_t i;int c;
    reset_doc("");mouse_enabled=true;
    for(i=0;i<sizeof bad/sizeof bad[0];i++) {
        memcpy(input,bad[i],strlen(bad[i]));input_n=strlen(bad[i]);input_at=0;
        c=key();assert(c==KEY_NONE);
    }
    {const char good[]="\033[<0;12;3M";memcpy(input,good,sizeof good-1);input_n=sizeof good-1;input_at=0;}
    assert(key()==KEY_MOUSE&&mouse_pressed&&mouse_x==12&&mouse_y==3);
    input_at=input_n=0;mouse_enabled=false;
    pass("overflowing or malformed mouse coordinates cannot wrap into valid clicks");
}

static void test_drawing_oom(void) {
    int fd,before;size_t i,variant,failed=allocation_failures;
    reset_doc("original\n");assert(edit(0,0,"unsaved ",8,false));
    fd=open("/dev/null",O_WRONLY);assert(fd>=0);tty_out=fd;before=descriptors();
    for(variant=0;variant<6;variant++) {
        rows=variant==5 ? 3 : 24;cols=variant==5 ? 12 : 80;
        viewer_text=viewer_title=NULL;menu_open=command_mode=movement_mode=false;
        if(variant==1) {viewer_text=manual_text;viewer_title="Manual";viewer_top=0;}
        if(variant==2) menu_enter(MENU_EDIT);
        if(variant==3) {command_mode=true;command_set("write named file.txt");}
        if(variant==4) movement_mode=true;
        for(i=0;i<100;i++) {
            reset_screen();allocation_failure=(long)i;draw();allocation_failure=-1;
            assert(!strcmp(text.s,"unsaved original\n")&&changed()&&undo_depth()==1);
            assert(running&&!terminated&&descriptors()==before);
        }
        reset_screen();fail_allocation=1;draw();fail_allocation=0;
        assert(!strcmp(text.s,"unsaved original\n")&&strstr(message,"memory"));
        draw();assert(previous_rows);
    }
    viewer_text=viewer_title=NULL;menu_open=command_mode=movement_mode=false;
    rows=24;cols=80;reset_screen();close(fd);tty_out=STDOUT_FILENO;
    printf("METRIC 600 rendering failure positions plus 6 persistent failures: %zu failures reached\n",allocation_failures-failed);
    pass("low-memory redraw in text, manual, menu, command, movement and small screens retains edits");
}

static void test_command_surface(void) {
    bool covered[COMMAND_INFO_COUNT]={false};
    size_t i,j,count;const char *title;const MenuItem *items;
    reset_doc("");
    assert(!command_lookup("mode"));
    assert(command_lookup("n")==command_lookup("next"));
    assert(command_lookup("p")==command_lookup("prev"));
    for(i=0;i<COMMAND_INFO_COUNT;i++) {
        const char *p=command_info[i].synonyms;
        assert(command_lookup(command_info[i].name)==command_info+i);
        assert(*command_info[i].syntax&&*command_info[i].description);
        while(*p) {
            const char *begin;char alias[128];size_t n,k;
            while(*p==' '||*p==',')p++;
            begin=p;while(*p&&*p!=',')p++;
            n=(size_t)(p-begin);while(n&&begin[n-1]==' ')n--;
            assert(n&&n<sizeof alias);memcpy(alias,begin,n);alias[n]=0;
            assert(command_lookup(alias)==command_info+i);
            for(k=0;k<n;k++)alias[k]=(char)toupper((unsigned char)alias[k]);
            assert(command_lookup(alias)==command_info+i);
        }
    }
    /* The root itself is the menu command route. */
    covered[command_lookup("menu")-command_info]=true;
    for(menu_page=MENU_ROOT;menu_page<=MENU_EXIT;menu_page++) {
        items=menu_entries(&count,&title);assert(items&&count&&title);
        for(j=0;j<count;j++) {
            const CommandHelp *info=NULL;
            if(items[j].action==MENU_SUBPAGE) {
                assert(items[j].child>=MENU_ROOT&&items[j].child<=MENU_EXIT);
                if(items[j].child==MENU_SETTINGS)covered[command_lookup("settings")-command_info]=true;
                continue;
            }
            if(items[j].action==MENU_MOVEMENT) {
                covered[command_lookup("movement")-command_info]=true;
                covered[command_lookup("edit")-command_info]=true;continue;
            }
            if(items[j].action==MENU_SETTINGS_DONE)continue; /* Finish overlay, no command. */
            if(items[j].action==MENU_WRITE)info=command_lookup("write");
            else if(items[j].action==MENU_QUIT_FORCE)info=command_lookup("quit!");
            else {
                char token[80];size_t n;
                const char *command_name=items[j].command;
                assert(command_name);
                if(!strcmp(command_name,"@cli-prompt"))continue; /* One-off prompt is not a preference. */
                if(!strcmp(command_name,"@count-dline"))command_name="dline";
                n=strcspn(command_name," ");assert(n<sizeof token);
                memcpy(token,command_name,n);token[n]=0;info=command_lookup(token);
            }
            assert(info);covered[info-command_info]=true;
        }
    }
    for(i=0;i<COMMAND_INFO_COUNT;i++)assert(covered[i]);
    menu_page=MENU_ROOT;
    printf("METRIC %zu commands: every alias is unambiguous and every command has a menu route\n",(size_t)COMMAND_INFO_COUNT);
    pass("command/menu parity, alias uniqueness and movement/edit naming remain intact");
}

static void test_review_064(const char *which) {
    if(!which||!strcmp(which,"io-budget"))test_buffered_history();
    if(!which||!strcmp(which,"short-io"))test_short_and_failed_io();
    if(!which||!strcmp(which,"clip-warning"))test_clip_warning_retained();
    if(!which||!strcmp(which,"preview-budget"))test_preview_budget();
    if(!which||!strcmp(which,"allocation"))test_allocation_failures();
    if(!which||!strcmp(which,"mouse-numbers"))test_mouse_numbers();
    if(!which||!strcmp(which,"drawing-oom"))test_drawing_oom();
    if(!which||!strcmp(which,"command-surface"))test_command_surface();
}



static void test_terminal_start_interrupted(void) {
    int master, slave, saved_in=tty_in, saved_out=tty_out;
    struct termios before, after;
    char *name;
    reset_doc("");
    master=posix_openpt(O_RDWR|O_NOCTTY);assert(master>=0);
    assert(grantpt(master)==0 && unlockpt(master)==0);
    name=ptsname(master);assert(name);
    slave=open(name,O_RDWR|O_NOCTTY);assert(slave>=0);
    tty_in=tty_out=slave;
    assert(tcgetattr(slave,&initial_termios)==0);before=initial_termios;
    fail_screen_write=1;terminal_start();
    assert(interrupted && !terminal_active && !terminated);
    assert(!previous_rows && resized);
    assert(tcgetattr(slave,&after)==0);
    assert(after.c_lflag==before.c_lflag && after.c_iflag==before.c_iflag);
    assert(after.c_cc[VINTR]==before.c_cc[VINTR] && after.c_cc[VSUSP]==before.c_cc[VSUSP]);
    interrupted=0;terminal_start();assert(terminal_active && resized);
    terminal_restore();reset_screen();
    fail_terminal_attr=1;terminal_start();
    assert(interrupted && !terminal_active && !terminated);
    assert(tcgetattr(slave,&after)==0 && after.c_lflag==before.c_lflag);
    interrupted=0;fail_terminal_attr=2;terminal_start();
    assert(terminal_active && !interrupted && !terminated);
    terminal_restore();reset_screen();
    assert(tcgetattr(slave,&after)==0 && after.c_lflag==before.c_lflag);
    close(slave);close(master);tty_in=saved_in;tty_out=saved_out;
    pass("interrupted terminal setup restores flags and permits a complete retry");
}

static void test_signals_and_exit(void) {
    char normal[24], *path;
    reset_doc("");
    assert(signal_controls==0);
    assert(hotkey_code("Ctrl+C",normal)<0 && hotkey_code("Ctrl-Z",normal)<0);
    assert(!binding_assign("Ctrl+C","quit!"));
    assert(!binding_assign("Ctrl+Z","suspend"));
    command_run("settings show");assert(!signal_controls && viewer_text && strstr(viewer_text,"OFF"));
    viewer_text=viewer_title=NULL;command_mode=false;
    command_run("toggle-signals");assert(signal_controls);
    command_run("toggle-signals nonsense");assert(signal_controls);
    command_run("toggle-signals");assert(!signal_controls);
    command_run("toggle-signals");assert(signal_controls);
    command_run("toggle-signals");assert(!signal_controls);
    signal_handler(SIGINT);assert(terminated==SIGINT && !interrupted);
    terminated=0;signal_controls=1;signal_handler(SIGINT);
    assert(interrupted && !terminated);interrupted=0;
    signal_handler(SIGTSTP);assert(suspended);suspended=0;
    signal_controls=0;signal_handler(SIGTSTP);assert(suspended);suspended=0;
    path=config_path("config",true);assert(path);
    write_bytes(path,"startup=movement\nsignal_controls=on\n",36);
    startup_config_warning=false;load_startup_config();
    assert(movement_mode && signal_controls && !startup_config_warning);
    write_bytes(path,"signal_controls = off # comment\r\n",strlen("signal_controls = off # comment\r\n"));
    load_startup_config();assert(!signal_controls);
    write_bytes(path,"signal_controls=invalid\n",strlen("signal_controls=invalid\n"));
    startup_config_warning=false;load_startup_config();
    assert(startup_config_warning && !signal_controls);
    unlink(path);free(path);
    pass("signal setting defaults OFF; config/commands valid; Ctrl-C/Z cannot bind");

    reset_doc("");menu_enter(MENU_ROOT);
    menu_key(3);menu_key(26);assert(menu_open && !suspended && !terminated);
    menu_open=false;command_mode=filename_mode=true;command_set("draft");
    command_key(3);command_key(26);
    assert(filename_mode && command_mode && !strcmp(command,"draft") && !suspended);
    filename_mode=command_mode=false;
    prompt=PROMPT_QUIT;prompt_key(26);
    assert(running && !suspended); /* just a non-Y byte when ISIG is disabled */
    pass("raw Ctrl-C/Z bytes have no hidden menu/filename lifecycle action");

    reset_doc("");command_run("quit");assert(!running && ordinary_quit);
    reset_doc("");command_run("q");assert(!running && ordinary_quit);
    reset_doc("");command_run("quit!");assert(!running && !ordinary_quit);
    reset_doc("");prompt=PROMPT_QUIT;prompt_key('Y');assert(!running && !ordinary_quit);
    reset_doc("");assert(edit(0,0,"dirty",5,false));command_run("quit");
    assert(running && !ordinary_quit);
    reset_doc("");menu_enter(MENU_EXIT);menu_selection=0;menu_run();
    assert(!running && ordinary_quit);
    reset_doc("");menu_enter(MENU_EXIT);menu_selection=1;menu_run();
    assert(!running && !ordinary_quit);
    pass("exit notice only follows successful ordinary quit, never quick/discard");
}


static void test_cli_guidance(void) {
    size_t i, initial;
    char expected[200], original_text[40];
    int before;
    reset_doc("alpha\nbeta\ngamma\n");
    assert(edit(0,0,"!",1,false)); initial=undo_depth();
    strcpy(original_text,text.s);
    command_run("list");
    assert(viewer_text==command_page && command_mode && !command_n);
    assert(strstr(viewer_text,"COMMANDS BY TASK") && !strstr(viewer_text,"narrow this list.)"));
    for(i=0;i<COMMAND_INFO_COUNT;i++) {
        assert(command_info[i].section<COMMAND_SECTION_COUNT);
        assert(*command_info[i].summary && *command_info[i].examples);
        snprintf(expected,sizeof expected,"  %s\n",command_info[i].syntax);
        assert(strstr(viewer_text,expected));
        assert(strstr(viewer_text,command_info[i].summary));
    }
    viewer_key('q');assert(!viewer_text && command_mode);
    command_key('\r');assert(!command_mode && prompt==PROMPT_NONE);
    assert(!strcmp(text.s,original_text) && undo_depth()==initial);
    pass("task guide covers every command with an explanation and resumes Command>");

    for(i=0;i<COMMAND_INFO_COUNT;i++) {
        command_help(command_info[i].name);
        assert(strstr(viewer_text,"EXAMPLES\n"));
        assert(strstr(viewer_text,command_info[i].examples));
        assert(strstr(viewer_text,command_info[i].synonyms));
        assert(strstr(viewer_text,"SYNONYMS")>strstr(viewer_text,"EXAMPLES"));
        assert(!strstr(viewer_text,"narrow this list.)"));
        viewer_key(KEY_ESCAPE);command_key('\r');
    }
    command_run("help SAVE   ");assert(strstr(viewer_text,"write notes.txt"));
    assert(!strcmp(text.s,original_text) && undo_depth()==initial && running);
    pass("all canonical help pages have examples and aliases; alias help remains read-only");

    command_run("list YaNk");
    assert(strstr(viewer_text,"copy [") && !strstr(viewer_text,"  quit\n"));
    command_run("list delete cursor");
    assert(strstr(viewer_text,"deleof") && !strstr(viewer_text,"  write ["));
    command_run("list zzz-no-such-command");assert(strstr(viewer_text,"No matching commands"));
    command_run("help clipboard history");assert(strstr(viewer_text,"cliphistory"));
    command_run("help");assert(viewer_text==help_topics && !command_n && command_mode);
    viewer_key('q');command_key(KEY_ESCAPE);assert(prompt==PROMPT_QUIT && running);
    prompt_key('n');assert(!command_mode && prompt==PROMPT_NONE);
    assert(!strcmp(text.s,original_text) && undo_depth()==initial);
    pass("topic filtering and no-match guidance; original double-Esc quit behavior retained");

    command_mode=true;command_set("he");complete_command();assert(!strcmp(command,"help"));
    command_set("sa");complete_command();assert(!strcmp(command,"save"));
    command_set("he cut");command_cursor=2;complete_command();assert(!strcmp(command,"help cut"));
    command_set("help dl");complete_command();assert(!strcmp(command,"help dline"));
    command_set("list cli");complete_command();assert(strstr(command,"list cli"));
    viewer_text=viewer_title=NULL;
    command_set("re");complete_command();assert(viewer_text && !strcmp(command,"re"));
    assert(strstr(viewer_text,"Open another file") && strstr(viewer_text,"Find and replace"));
    viewer_key('q');assert(command_mode && !strcmp(command,"re"));
    command_set("zzzz");complete_command();assert(strstr(viewer_text,"No command starts"));
    assert(!strstr(viewer_text,"More than one"));viewer_key('q');
    command_set("");complete_command();assert(viewer_text && !command_n && command_mode);
    viewer_key('q');
    request_argument("help","Command or topic> ");complete_command();
    assert(menu_argument_mode && !strcmp(menu_argument_command,"help"));
    viewer_key('q');command_set("cut");command_key('\r');
    assert(viewer_text && !menu_argument_mode && strstr(viewer_text,"cut 2"));
    assert(!strcmp(text.s,original_text) && undo_depth()==initial);
    pass("Tab descriptions, empty-prompt discovery and argument context preserved");

    viewer_text=viewer_title=NULL;
    command_run("  wirte name with spaces.txt");
    assert(command_mode && viewer_text && strstr(viewer_text,"  write\n"));
    assert(!strcmp(command,"  wirte name with spaces.txt"));
    assert(command_n==strlen(command) && command_cursor==command_n && !filename);
    viewer_key(KEY_ESCAPE);assert(command_mode && !viewer_text);
    command_run("qut!");assert(running && viewer_text && !strcmp(command,"qut!"));
    assert(strstr(viewer_text,"Nothing ran"));
    assert(command_distance("write","write")==0 && command_distance("wirte","write")==2);
    assert(!strcmp(text.s,original_text) && undo_depth()==initial);
    pass("unknown commands preserve the literal draft; suggestions never execute");

    viewer_text=viewer_title=NULL;command_run("goto");
    assert(menu_argument_mode && command_mode && !command_n && !strcmp(menu_argument_command,"goto"));
    command_set("2 2");command_key('\r');assert(cursor==numbered_line(2)+1 && !command_mode);
    command_run("goto");command_key(KEY_ESCAPE);assert(!menu_argument_mode && !command_mode);
    command_run("clipuse");assert(menu_argument_mode && !strcmp(menu_argument_command,"clipuse"));
    command_key(KEY_ESCAPE);assert(!menu_argument_mode && !command_mode);
    command_run("goto potato");assert(command_mode && viewer_text && !strcmp(command,"goto potato"));
    assert(strstr(viewer_text,"nothing moved"));
    command_run("undo 0");assert(strstr(viewer_text,"positive number") && undo_depth()==initial);
    command_run("quit! now");assert(viewer_text && command_mode && running);
    command_run("find ?");assert(search_length==1 && search_pattern[0]=='?');
    assert(!strcmp(text.s,original_text) && undo_depth()==initial);
    pass("missing arguments prompt; invalid arguments explain and keep the command; search remains literal");

    reset_doc("dirty parent\n");assert(edit(0,0,"*",1,false));
    before=descriptors();
    for(i=0;i<300;i++) {
        fail_allocation=1;
        command_help(command_info[i%COMMAND_INFO_COUNT].name);
        command_overview(i%2 ? "" : "clipboard",false);
        fail_allocation=0;
        assert(running && changed());
    }
    assert(descriptors()==before && !strcmp(text.s,"*dirty parent\n") && undo_depth()==1);
    {
        size_t used=0;
        char huge[sizeof command_page + 100];memset(huge,'x',sizeof huge-1);huge[sizeof huge-1]=0;
        guide_append(&used,"%s",huge);assert(used==sizeof command_page-1);
        assert(strstr(command_page,"Use list TOPIC") && command_page[sizeof command_page-1]==0);
        guide_append(&used,"ignored");assert(used==sizeof command_page-1);
    }
    command_n=COMMAND_SIZE;execute();assert(command_mode && !command_n && running);
    pass("guidance survives allocation failures; long pages and invalid input lengths stay bounded");

    reset_doc("parent\n");assert(edit(0,0,"*",1,false));cursor=2;initial=undo_depth();
    command_run("clipboard");assert(editing_clipboard);
    command_run("list clipboard");assert(editing_clipboard && viewer_text && command_mode);
    command_run("help paste");assert(strstr(viewer_text,"paste 2") && editing_clipboard);
    viewer_key('q');command_run("clipboard");assert(!editing_clipboard);
    assert(!strcmp(text.s,"*parent\n") && cursor==2 && undo_depth()==initial && changed());
    pass("help/list in clipboard editing preserve the dirty parent document and history");
}


/* 0.6.7 review: transactional filesystem completion and literal input. */
static void completion_directory(char dir[1024], const char *label) {
    char path[1200];
    snprintf(dir,1024,"%s/%s",test_home,label);assert(mkdir(dir,0700)==0);
    snprintf(path,sizeof path,"%s/prefix-one",dir);write_bytes(path,"1",1);
    snprintf(path,sizeof path,"%s/prefix-two",dir);write_bytes(path,"2",1);
}
static void test_completion_memory(void) {
    char dir[1024],draft[COMMAND_SIZE],path[1200],expected[COMMAND_SIZE];
    int before,i;
    reset_doc("untouched\n");completion_directory(dir,"complete-memory");
    snprintf(draft,sizeof draft,"write %s/p",dir);
    before=descriptors();
    /* entered, expanded, directory and first candidate: each failure must
     * abort discovery, not treat a later candidate as the only match. */
    for(i=0;i<80;i++) {
        command_set(draft);command_mode=true;viewer_text=NULL;
        allocation_failure=i%4;path_complete();allocation_failure=-1;
        assert(!strcmp(command,draft) && command_cursor==strlen(draft));
        assert(viewer_text && strstr(viewer_text,"unchanged"));
        assert(!strcmp(text.s,"untouched\n") && !undo_depth());
    }
    snprintf(path,sizeof path,"%s/folder",dir);assert(mkdir(path,0700)==0);
    snprintf(path,sizeof path,"%s/folder/child",dir);write_bytes(path,"x",1);
    snprintf(draft,sizeof draft,"write %s/fo",dir);
    snprintf(expected,sizeof expected,"write %s/folder/",dir);
    for(i=0;i<8;i++) {
        command_set(draft);command_mode=true;viewer_text=NULL;
        allocation_failure=i;path_complete();allocation_failure=-1;
        assert(!strcmp(command,i<5?draft:expected));
        assert(viewer_text && strstr(viewer_text,i<5?"unchanged":"No partial list"));
        assert(!strcmp(text.s,"untouched\n") && !undo_depth());
    }
    assert(descriptors()==before);
    pass("88 completion/listing allocation failures retain a valid draft and document without leaks");
}
static void test_completion_errors(void) {
    char dir[1024],draft[COMMAND_SIZE];int before;
    reset_doc("untouched\n");completion_directory(dir,"complete-errors");
    snprintf(draft,sizeof draft,"write %s/p",dir);before=descriptors();
    command_set(draft);directory_fail_after=1;path_complete();directory_fail_after=-1;
    assert(!strcmp(command,draft) && viewer_text && strstr(viewer_text,"unchanged"));
    viewer_text=NULL;command_set(draft);directory_close_fail=1;path_complete();
    assert(!strcmp(command,draft) && viewer_text);
    viewer_text=NULL;command_set(draft);directory_stop_after=1;path_complete();directory_stop_after=-1;
    assert(interrupted && !strcmp(command,draft) && viewer_text);interrupted=0;
    assert(descriptors()==before && !strcmp(text.s,"untouched\n"));
    pass("failed/incomplete/interrupted directory scans cannot complete a guessed filename");
}
static void test_completion_boundaries(void) {
    char dir[1024],path[1200],draft[COMMAND_SIZE],expected[COMMAND_SIZE];
    reset_doc("untouched\n");completion_directory(dir,"complete-bounds");
    snprintf(path,sizeof path,"%s/folderlong",dir);assert(mkdir(path,0700)==0);
    snprintf(path,sizeof path,"%s/fo",dir);
    memset(draft,' ',sizeof draft);memcpy(draft,"write",5);
    memcpy(draft+COMMAND_SIZE-2-strlen(path),path,strlen(path)+1);
    command_set(draft);path_complete();
    assert(!strcmp(command,draft) && viewer_text && strstr(viewer_text,"too long"));
    snprintf(draft,sizeof draft,"write %s/fo",dir);command_set(draft);path_complete();
    snprintf(expected,sizeof expected,"write %s/folderlong/",dir);
    assert(!strcmp(command,expected) && viewer_text && strstr(viewer_text,"DIRECTORY:"));
    pass("full command completion is atomic; directory slash follows only a complete pathname");
}
static void test_completion_unicode(void) {
    char dir[1024],path[1200],draft[COMMAND_SIZE];
    reset_doc("text\n");completion_directory(dir,"complete-unicode");
    snprintf(path,sizeof path,"%s/caf\303\251",dir);write_bytes(path,"1",1);
    snprintf(path,sizeof path,"%s/caf\303\252",dir);write_bytes(path,"2",1);
    snprintf(draft,sizeof draft,"read %s/caf",dir);command_set(draft);path_complete();
    assert(!strcmp(command,draft) && viewer_text);
    assert(strstr(viewer_text,"caf\303\251") && strstr(viewer_text,"caf\303\252"));
    snprintf(path,sizeof path,"%s/file\377one",dir);write_bytes(path,"3",1);
    snprintf(draft,sizeof draft,"read %s/file",dir);command_set(draft);path_complete();
    snprintf(draft,sizeof draft,"read %s/file\377one",dir);
    assert(!strcmp(command,draft));
    pass("common filename prefixes never split UTF-8; literal invalid filename bytes still work");
}
static void test_directory_errors(void) {
    char dir[1024];int before;
    reset_doc("text\n");completion_directory(dir,"directory-errors");before=descriptors();
    directory_fail_after=1;directory_list(dir);directory_fail_after=-1;
    assert(!viewer_text && strstr(message,"No partial list"));
    directory_stop_after=1;directory_list(dir);directory_stop_after=-1;
    assert(interrupted && !viewer_text);interrupted=0;
    directory_close_fail=1;directory_list(dir);assert(!viewer_text);
    directory_list(dir);assert(viewer_text && strstr(viewer_text,"prefix-one"));
    assert(descriptors()==before);
    pass("directory listing reports errors/cancellation rather than presenting incomplete results");
}
static void test_directory_efficiency(void) {
    char dir[1024],path[1200];size_t before,calls;int i;
    reset_doc("text\n");snprintf(dir,sizeof dir,"%s/directory-efficient",test_home);
    assert(mkdir(dir,0700)==0);
    for(i=255;i>=0;i--) {
        snprintf(path,sizeof path,"%s/item-%03d",dir,i);write_bytes(path,"x",1);
    }
    before=allocation_calls;directory_list(dir);calls=allocation_calls-before;
    printf("METRIC 256-file listing: %zu editor allocation calls\n",calls);
    assert(calls<=260 && viewer_text);
    assert(strstr(viewer_text,"item-000")<strstr(viewer_text,"item-255"));
    pass("sorted directory listing avoids a per-entry full-path allocation");
}
static void test_find_literal(void) {
    size_t depth;
    reset_doc("first beta\nsecond  beta\nlast beta \n");depth=undo_depth();
    command_run("find");command_set("  beta");command_key('\r');
    assert(!strcmp(search_pattern,"  beta") && cursor==17 && !command_mode);
    assert(!menu_argument_mode && !menu_argument_command && !menu_argument_label);
    command_run("find");command_set("beta ");command_key('\r');
    assert(!strcmp(search_pattern,"beta ") && cursor==29);
    command_run("find");command_set("  ");command_key('\r');
    assert(search_length==2 && !strcmp(search_pattern,"  ") && cursor==17);
    command_run("next");assert(cursor==17);command_run("prev");assert(cursor==17);
    command_run("find");command_key(KEY_ESCAPE);assert(!command_mode && !menu_argument_mode);
    assert(undo_depth()==depth && !changed());
    pass("Find prompt preserves leading/trailing/only spaces without altering history");
}
static void test_paste_bounds(void) {
    char path[1024],*data;int fd,oldtty;size_t n=100000,used;
    reset_doc("document\n");snprintf(path,sizeof path,"%s/command-paste",test_home);
    data=malloc(n+7);assert(data);memset(data,'x',n);memcpy(data+n,"\033[201~Z",7);
    write_bytes(path,data,n+7);free(data);fd=open(path,O_RDONLY);assert(fd>=0);
    oldtty=tty_in;tty_in=fd;input_at=input_n=0;command_set("find ");command_mode=true;
    largest_allocation=0;paste();used=largest_allocation;
    assert(!strcmp(command,"find ") && command_mode && viewer_text && strstr(viewer_text,"draft unchanged"));
    assert(byte(0)=='Z');assert(used<=COMMAND_SIZE);
    assert(!strcmp(text.s,"document\n") && !undo_depth());
    printf("METRIC 100000-byte command paste: largest editor allocation %zu bytes\n",used);
    close(fd);tty_in=oldtty;input_at=input_n=0;
    pass("oversized command paste retains draft, drains end marker and bounds buffering");
}
static void test_oversize_read(void) {
    char path[1024];int fd,before,i;Buffer b={0};struct stat st;
    reset_doc("draft\n");snprintf(path,sizeof path,"%s/oversize-read",test_home);
    fd=open(path,O_WRONLY|O_CREAT,0600);assert(fd>=0);assert(ftruncate(fd,LIMIT+1)==0);close(fd);
    before=descriptors();io_begin();largest_allocation=0;
    for(i=0;i<80;i++) {assert(!read_file(path,&b,&st));assert(errno==EFBIG);}
    track_io=0;
    printf("METRIC 80 oversized file reads: %zu bytes read, largest allocation %zu\n",io_read_bytes,largest_allocation);
    assert(io_read_bytes==0 && largest_allocation==0 && !b.s && !b.n);
    assert(descriptors()==before && !strcmp(text.s,"draft\n"));free(b.s);
    pass("known oversized regular files are refused before data reads or buffer allocation");
}
static void test_review_067(const char *which) {
    if(!which||!strcmp(which,"completion-memory"))test_completion_memory();
    if(!which||!strcmp(which,"completion-errors"))test_completion_errors();
    if(!which||!strcmp(which,"completion-bounds"))test_completion_boundaries();
    if(!which||!strcmp(which,"completion-unicode"))test_completion_unicode();
    if(!which||!strcmp(which,"directory-errors"))test_directory_errors();
    if(!which||!strcmp(which,"directory-efficiency"))test_directory_efficiency();
    if(!which||!strcmp(which,"find-literal"))test_find_literal();
    if(!which||!strcmp(which,"paste-bounds"))test_paste_bounds();
    if(!which||!strcmp(which,"oversize-read"))test_oversize_read();
}


/* 0.6.8: failed history scans must never select a clip from a partial list. */
static void setup_review_history(void) {
    char *dir=state_path("clipboard-history",true), path[2048];
    unsigned i;
    assert(dir && private_directory(dir));
    for(i=1;i<=6;i++) {
        int n=snprintf(path,sizeof path,"%s/clip-%020u.txt",dir,i);
        assert(n>0 && (size_t)n<sizeof path);
        write_bytes(path,"different historical text",25);
    }
    free(dir);
    selected_clipboard[0]=0;clip_history_enabled=false;
    assert(clipboard_set("keep this clipboard",19)==CLIP_SAVED);
}
static void test_history_scan_refusal(void) {
    Buffer clip={0};int before;
    reset_doc("untouched document\n");setup_review_history();before=descriptors();
    directory_fail_after=2;
    command_run("clipuse 1");
    directory_fail_after=-1;
    assert(clipboard_read(&clip)==1);
    printf("OBSERVED after failed clipuse scan: %s\n",clip.s);
    assert(clip.n==19 && !memcmp(clip.s,"keep this clipboard",19));
    assert(!strcmp(text.s,"untouched document\n") && !undo_depth());
    assert(descriptors()==before);free(clip.s);
    pass("failed clipboard-history scans never restore from a partial list");
}
static void test_clip_listing_errors(void) {
    reset_doc("untouched\n");setup_review_history();
    directory_fail_after=0;clip_history_list();directory_fail_after=-1;
    assert(!viewer_text && strstr(message,"failed"));
    directory_fail_after=0;clipboard_list();directory_fail_after=-1;
    assert(!viewer_text && strstr(message,"failed"));
    pass("failed clipboard listings are not displayed as empty or complete");
}
static void test_replacement_cancel(void) {
    reset_doc("one one one\n");cursor=4;
    strcpy(search_pattern,"one");search_length=3;search_mark=0;
    interrupted=1;run_replacement("one","two",true);interrupted=0;
    printf("OBSERVED interrupted replacement: %s",text.s);
    assert(!strcmp(text.s,"one one one\n") && cursor==4 && !history);
    assert(search_mark==0);
    pass("pending cancellation does not commit replace-all or change cursor/history");
}

static size_t naive_find(size_t at, bool forward, bool include_current) {
    size_t first=SIZE_MAX,last=SIZE_MAX,answer=SIZE_MAX,i;
    if(search_length>text.n)return SIZE_MAX;
    for(i=0;i<=text.n-search_length;i++) if(!memcmp(text.s+i,search_pattern,search_length)) {
        if(first==SIZE_MAX)first=i;
        last=i;
        if(forward) {
            if(answer==SIZE_MAX && (i>at || (include_current && i==at)))answer=i;
        } else if(i<at)answer=i;
    }
    return answer==SIZE_MAX ? (forward ? first : last) : answer;
}
static void test_search_reference(void) {
    char document[9],pattern[5];size_t len,code,limit,plen,pc,plimit,pos,ways,cases=0;
    static const char letters[]="ab\n";
    for(len=0,limit=1;len<=5;len++,limit*=3)for(code=0;code<limit;code++) {
        size_t t=code,i;
        for(i=0;i<len;i++) {document[i]=letters[t%3];t/=3;}document[len]=0;
        reset_doc(document);
        for(plen=1,plimit=3;plen<=3;plen++,plimit*=3)for(pc=0;pc<plimit;pc++) {
            t=pc;for(i=0;i<plen;i++){pattern[i]=letters[t%3];t/=3;}pattern[plen]=0;
            strcpy(search_pattern,pattern);search_length=plen;
            for(pos=0;pos<=len;pos++)for(ways=0;ways<3;ways++) {
                bool forward=ways<2,include=ways==0;
                size_t expected=naive_find(pos,forward,include);
                cursor=pos;search_mark=SIZE_MAX;
                assert(find_match(forward,include)==(expected!=SIZE_MAX));
                assert(cursor==(expected==SIZE_MAX?pos:expected));
                assert(search_mark==expected && !changed() && !history);
                cases++;
            }
        }
    }
    printf("METRIC exhaustive independent search comparisons: %zu\n",cases);
    pass("bounded search matches independent forward/previous/wrap/overlap reference");
}
static void test_search_cancel(void) {
    size_t i;bool forward;
    for(i=0;i<3;i++)for(forward=false;;forward=true) {
        reset_doc("one two one two\n");strcpy(search_pattern,"two");search_length=3;
        cursor=3;search_mark=0;goal_set=true;goal=9;
        if(i==0)interrupted=1;else if(i==1)suspended=1;else terminated=SIGTERM;
        assert(!find_match(forward,false));
        interrupted=suspended=terminated=0;
        assert(cursor==3 && search_mark==0 && goal_set && goal==9 && !history);
        if(forward)break;
    }
    pass("interrupt/stop/termination requests leave search cursor and mark unchanged");
}
static void test_history_failure_matrix(void) {
    Buffer b={0};size_t i;int before;
    reset_doc("parent\n");setup_review_history();before=descriptors();
    for(i=0;i<24;i++) {
        bool failed=false;
        allocation_failure=(long)i;clip_history_use(1);allocation_failure=-1;
        assert(clipboard_read(&b)==1);
        failed=b.n==19&&!memcmp(b.s,"keep this clipboard",19);
        assert(failed || (b.n==25&&!memcmp(b.s,"different historical text",25)));
        free(b.s);memset(&b,0,sizeof b);
        assert(descriptors()==before && !strcmp(text.s,"parent\n") && !history);
        assert(clipboard_set("keep this clipboard",19)==CLIP_SAVED);
    }
    for(i=0;i<4;i++) {
        if(i==0)directory_close_fail=1;
        else if(i==1)directory_stop_after=1;
        else if(i==2)directory_fail_after=1;
        else fail_directory_fd=1;
        clip_history_use(1);
        directory_close_fail=fail_directory_fd=0;directory_stop_after=directory_fail_after=-1;interrupted=0;
        assert(clipboard_read(&b)==1 && b.n==19 && !memcmp(b.s,"keep this clipboard",19));
        free(b.s);memset(&b,0,sizeof b);assert(descriptors()==before);
    }
    pass("clipboard restoration rejects allocation/scan/close/interruption errors without leaks");
}
static void test_history_prune_transaction(void) {
    ClipEntry entries[CLIP_HISTORY_MAX];char *dir,path[2048];size_t i,count;struct stat st;
    reset_doc("parent\n");dir=state_path("clipboard-history",true);assert(dir&&private_directory(dir));
    /* Isolated fresh names, much newer than other fixtures, in a fresh home
     * when run alone. All present snapshots are counted for failed cleanup. */
    for(i=0;i<72;i++) {
        snprintf(path,sizeof path,"%s/clip-%020zu.txt",dir,900000+i);
        write_bytes(path,"snapshot\n",9);
    }
    directory_fail_after=70;
    count=clip_history_entries(entries,true);
    directory_fail_after=-1;
    assert(count==SIZE_MAX);
    for(i=0;i<72;i++) {
        snprintf(path,sizeof path,"%s/clip-%020zu.txt",dir,900000+i);
        assert(lstat(path,&st)==0); /* Failed first scan prunes nothing. */
    }
    count=clip_history_entries(entries,true);assert(count==CLIP_HISTORY_MAX);
    assert(clip_history_entries(entries,false)==CLIP_HISTORY_MAX);
    free(dir);
    pass("history pruning waits for a complete scan, then retains newest 64 snapshots");
}
static void test_history_privacy(void) {
    ClipEntry entries[CLIP_HISTORY_MAX];char *dir,*alt,path[2048];size_t i,count;
    reset_doc("parent\n");setup_review_history();dir=state_path("clipboard-history",false);assert(dir);
    snprintf(path,sizeof path,"%s/clip-%020u.txt",dir,9999999u);
    write_bytes(path,"PUBLIC",6);assert(chmod(path,0644)==0);
    count=clip_history_entries(entries,false);assert(count!=SIZE_MAX);
    for(i=0;i<count;i++)assert(!strstr(entries[i].name,"00000000000009999999"));
    assert(unlink(path)==0);alt=malloc(strlen(dir)+20);assert(alt);sprintf(alt,"%s-real",dir);
    assert(rename(dir,alt)==0);assert(symlink(alt,dir)==0);
    assert(clip_history_entries(entries,false)==SIZE_MAX);
    assert(unlink(dir)==0);assert(rename(alt,dir)==0);free(alt);free(dir);
    pass("clipboard history excludes public snapshots and refuses a symlinked history directory");
}


static volatile sig_atomic_t timer_kind;
static void cancel_alarm(int signum) {
    (void)signum;
    if(timer_kind==1)suspended=1;
    else if(timer_kind==2)terminated=SIGTERM;
    else interrupted=1;
}
static void test_replace_mid_signal(void) {
    struct sigaction sa={0},prior;
    struct itimerval timer={0},stop={0};
    size_t i;
    sa.sa_handler=cancel_alarm;sigemptyset(&sa.sa_mask);
    assert(sigaction(SIGALRM,&sa,&prior)==0);
    for(i=0;i<3;i++) {
        double start;
        reset_doc("");assert(reserve(&text,LIMIT+1));
        memset(text.s,'a',LIMIT);text.n=LIMIT;text.s[text.n]=0;
        assert(copy_buffer(&saved,text.s,text.n));cursor=3;search_mark=2;
        timer_kind=(sig_atomic_t)i;timer.it_value.tv_usec=1000;
        assert(setitimer(ITIMER_REAL,&timer,NULL)==0);start=(double)clock()/CLOCKS_PER_SEC;
        run_replacement("a","b",true);
        assert(setitimer(ITIMER_REAL,&stop,NULL)==0);
        assert(interrupted || suspended || terminated);
        printf("METRIC in-progress replacement cancellation %zu: %.6f CPU seconds\n",i,
               (double)clock()/CLOCKS_PER_SEC-start);
        interrupted=suspended=terminated=0;
        assert(!changed() && cursor==3 && search_mark==2 && !history);
    }
    assert(sigaction(SIGALRM,&prior,NULL)==0);
    pass("real timed signals cancel an in-progress 8 MiB replacement without partial edits");
}
static void test_replace_reference(void) {
    char doc[9],needle[5],expected[32];
    const char *values[]={"","a","ab","aba","\n"};
    size_t len,limit,code,plen,plimit,pc,v,tests=0;
    for(len=0,limit=1;len<=6;len++,limit*=2)for(code=0;code<limit;code++) {
        size_t i;
        for(i=0;i<len;i++)doc[i]=(code&(1u<<i))?'b':'a';
        doc[len]=0;
        for(plen=1,plimit=2;plen<=3;plen++,plimit*=2)for(pc=0;pc<plimit;pc++) {
            for(i=0;i<plen;i++)needle[i]=(pc&(1u<<i))?'b':'a';
            needle[plen]=0;
            for(v=0;v<sizeof values/sizeof *values;v++) {
                size_t used=0,p=0,n=strlen(values[v]);bool different;
                while(p<len) {
                    if(plen<=len-p&&!memcmp(doc+p,needle,plen)) {
                        memcpy(expected+used,values[v],n);used+=n;p+=plen;
                    } else expected[used++]=doc[p++];
                }
                expected[used]=0;reset_doc(doc);cursor=len;
                run_replacement(needle,values[v],true);
                assert(text.n==used&&!memcmp(text.s,expected,used));
                different=strcmp(doc,expected)!=0;
                assert(undo_depth()==(size_t)different);
                if(different) {
                    assert(history_step(false));assert(!strcmp(text.s,doc));
                    assert(history_step(true));assert(!strcmp(text.s,expected));
                }
                tests++;
            }
        }
    }
    printf("METRIC independent replace-all/undo/redo comparisons: %zu\n",tests);
    pass("replace-all agrees with independent nonoverlapping model and one-step undo/redo");
}


static void test_history_preview_failure(void) {
    char *dir, path[2048];int fd,before;size_t i,calls;
    reset_doc("unchanged\n");setup_review_history();
    read_budget=0;clip_history_list();read_budget=-1;
    printf("OBSERVED unreadable preview listing: %s\n",clipboard_page);
    assert(viewer_text && strstr(clipboard_page,"1  (preview unavailable)"));
    assert(strstr(clipboard_page,"6  (preview unavailable)"));
    viewer_text=viewer_title=NULL;
    dir=state_path("clipboard-history",false);assert(dir);
    snprintf(path,sizeof path,"%s/clip-%020u.txt",dir,6u);
    fd=open(path,O_WRONLY);assert(fd>=0);assert(ftruncate(fd,LIMIT+1)==0);close(fd);
    clip_history_list();assert(strstr(clipboard_page,"1  (preview unavailable)"));
    assert(strstr(clipboard_page,"2  (25 bytes)"));
    viewer_text=viewer_title=NULL;
    before=descriptors();
    for(i=0;i<12;i++) {
        allocation_failure=(long)i;clip_history_list();allocation_failure=-1;
        if(viewer_text)assert(strstr(clipboard_page,"1  (preview unavailable)") &&
                              strstr(clipboard_page,"6  (25 bytes)"));
        else assert(strstr(message,"failed"));
        assert(!strcmp(text.s,"unchanged\n") && !history && descriptors()==before);
        viewer_text=viewer_title=NULL;
    }
    for(i=1;i<=6;i++) {
        snprintf(path,sizeof path,"%s/clip-%020zu.txt",dir,i);unlink(path);
    }
    for(i=1;i<=64;i++) {
        snprintf(path,sizeof path,"%s/clip-%020zu.txt",dir,i);write_bytes(path,"clip",4);
    }
    calls=allocation_calls;clip_history_list();calls=allocation_calls-calls;
    printf("METRIC history listing, 64 entries: %zu editor allocations\n",calls);
    assert(calls<12);assert(strstr(clipboard_page,"64  (4 bytes)"));
    viewer_text=viewer_title=NULL;
    for(i=1;i<=64;i++){snprintf(path,sizeof path,"%s/clip-%020zu.txt",dir,i);unlink(path);}
    free(dir);
    pass("unavailable clipboard previews retain numbers; bounded path reuse and failure cleanup");
}

static void test_review_068(const char *which) {
    if(!which || !strcmp(which,"history-preview-failure"))test_history_preview_failure();
    if(!which || !strcmp(which,"history-scan-refusal"))test_history_scan_refusal();
    if(!which || !strcmp(which,"clip-list-errors"))test_clip_listing_errors();
    if(!which || !strcmp(which,"replacement-cancel"))test_replacement_cancel();
    if(!which || !strcmp(which,"search-reference"))test_search_reference();
    if(!which || !strcmp(which,"search-cancel"))test_search_cancel();
    if(!which || !strcmp(which,"history-faults"))test_history_failure_matrix();
    if(!which || !strcmp(which,"history-prune"))test_history_prune_transaction();
    if(!which || !strcmp(which,"history-privacy"))test_history_privacy();
    if(!which || !strcmp(which,"replace-mid-signal"))test_replace_mid_signal();
    if(!which || !strcmp(which,"replace-reference"))test_replace_reference();
}


/* 0.6.9 startup preference regressions. Only isolated test-home data is used. */
static char startup_test_path[2048];
static void rewrite_startup_during_save(void) {
    write_bytes(startup_test_path,"# changed elsewhere\nstartup=edit\n",33);
}
static void test_startup069(void) {
    char root[1024], *path, *dir, *slash;
    struct stat before, after;
    Buffer b={0};
    int fds, i;
    size_t calls;
    const char *original_config="# keep this\r\nsignal_controls = on # signals\r\n  startup = edit  # first\r\nother=value\r\nstartup=edit";
    const char *expected_config="# keep this\r\nsignal_controls = on # signals\r\n  startup = movement  # first\r\nother=value\r\nstartup=movement";
    reset_doc("base\n");
    snprintf(root,sizeof root,"%s/startup-tests",test_home);
    assert(setenv("XDG_CONFIG_HOME",root,1)==0);
    path=config_path("config",true);assert(path);
    dir=strdup(path);assert(dir);slash=strrchr(dir,'/');*slash=0;
    assert(chmod(dir,0755)==0);
    write_bytes(path,"startup=movement\n",17);assert(chmod(path,0644)==0);
    load_startup_config();assert(movement_mode&&startup_movement&&!startup_config_warning);
    assert(stat(dir,&after)==0 && (after.st_mode&0777)==0755);
    assert(stat(path,&after)==0 && (after.st_mode&0777)==0644);
    pass("startup loads owned 0755 directory/0644 config without changing permissions");

    assert(chmod(dir,0775)==0);startup_config_warning=false;load_startup_config();
    assert(!movement_mode&&startup_config_warning&&startup_config_error==EACCES);
    assert(!save_startup_setting(0));check_bytes(path,"startup=movement\n",17);
    assert(chmod(dir,0755)==0);assert(chmod(path,0664)==0);
    load_startup_config();assert(startup_config_warning&&startup_config_error==EACCES);
    assert(chmod(path,0644)==0);
    pass("unsafe config is reported, not treated as an absent preference");

    reset_doc("base\n");assert(edit(0,0,"X",1,false));
    write_bytes(path,original_config,strlen(original_config));
    command_run("toggle-startup");assert(startup_movement&&!movement_mode&&!signal_controls);
    assert(current && !strcmp(text.s,"Xbase\n"));check_bytes(path,expected_config,strlen(expected_config));
    assert(stat(path,&before)==0);assert(save_startup_setting(1));assert(stat(path,&after)==0);
    assert(same_disk_version(&before,&after));
    assert(save_startup_setting(-1));check_bytes(path,original_config,strlen(original_config));
    assert(!startup_movement&&!movement_mode);
    assert(!command_lookup("startup-mode")&&!command_lookup("startup"));
    assert(!command_lookup("startmode")&&command_lookup("toggle-startup"));
    pass("startup persists without changing mode/text/history; preserves CRLF/comments/other settings/duplicates");

    write_bytes(path,"signal_controls=on",18);assert(save_startup_setting(1));
    check_bytes(path,"signal_controls=on\nstartup=movement\n",36);
    load_startup_config();assert(movement_mode&&signal_controls);
    write_bytes(path,"startup=edit\n",13);assert(save_startup_setting(-1));
    check_bytes(path,"startup=movement\n",17);
    pass("missing startup is appended; toggle reads current disk settings instead of stale memory");

    reset_doc("base\n");write_bytes(path,"startup=edit\n",13);startup_movement=false;
    fds=descriptors();
    for(i=0;i<30;i++) {
        fail_sync=1;assert(!save_startup_setting(1));fail_sync=0;
        check_bytes(path,"startup=edit\n",13);assert(!startup_movement);
        fail_rename=1;assert(!save_startup_setting(1));fail_rename=0;
        check_bytes(path,"startup=edit\n",13);assert(!startup_movement);
        write_budget=0;assert(!save_startup_setting(1));write_budget=-1;
        check_bytes(path,"startup=edit\n",13);assert(!startup_movement);
    }
    assert(descriptors()==fds);
    allocation_calls=0;assert(save_startup_setting(1));calls=allocation_calls;
    for(i=0;i<(int)calls;i++) {
        write_bytes(path,"startup=edit\n",13);startup_movement=false;
        allocation_failure=i;assert(!save_startup_setting(1));allocation_failure=-1;
        check_bytes(path,"startup=edit\n",13);assert(!startup_movement&&descriptors()==fds);
    }
    printf("METRIC startup-save allocation failure points: %zu\n",calls);
    pass("startup save failures preserve config/preference and release descriptors and allocations");

    snprintf(startup_test_path,sizeof startup_test_path,"%s",path);
    write_bytes(path,"startup=edit\n",13);sync_hook=rewrite_startup_during_save;
    assert(!save_startup_setting(1));assert(errno==EAGAIN);
    check_bytes(path,"# changed elsewhere\nstartup=edit\n",33);
    assert(unlink(path)==0);sync_hook=rewrite_startup_during_save;
    assert(!save_startup_setting(1));check_bytes(path,"# changed elsewhere\nstartup=edit\n",33);
    write_bytes(path,"startup=edit\n",13);
    fail_sync_after=1;assert(save_startup_setting(1));fail_sync_after=-1;
    assert(startup_sync_warning&&startup_movement);check_bytes(path,"startup=movement\n",17);
    pass("concurrent config versions survive; post-commit directory-sync failure is distinguished");

    write_bytes(path,"startup=edit\n",13);assert(chmod(path,0444)==0);
    assert(!save_startup_setting(1));check_bytes(path,"startup=edit\n",13);assert(chmod(path,0600)==0);
    assert(unlink(path)==0);assert(mkfifo(path,0600)==0);
    assert(!save_startup_setting(1));assert(unlink(path)==0);
    assert(symlink("missing",path)==0);assert(!save_startup_setting(1));assert(unlink(path)==0);
    write_bytes(path,"startup=edit\0bad",16);assert(!save_startup_setting(1));
    assert(unlink(path)==0);assert(copy_buffer(&b,"",0));assert(reserve(&b,CONFIG_LIMIT+1));
    memset(b.s,'#',CONFIG_LIMIT);b.n=CONFIG_LIMIT;b.s[b.n]=0;
    write_bytes(path,b.s,b.n);assert(!save_startup_setting(1));check_bytes(path,b.s,b.n);free(b.s);
    pass("read-only/special/link/NUL/oversized update inputs fail without destructive replacement");

    write_bytes(path,"startup=edit\n",13);startup_movement=false;
    command_run("toggle-startup bogus");assert(viewer_text&&!startup_movement);check_bytes(path,"startup=edit\n",13);
    viewer_text=viewer_title=NULL;command_mode=false;
    command_run("settings show");assert(viewer_text&&strstr(viewer_text,path)&&strstr(viewer_text,"Current mode: edit"));
    viewer_text=viewer_title=NULL;command_mode=false;
    menu_enter(MENU_SETTINGS);
    {size_t count,j;const char *title;const MenuItem *entries=menu_entries(&count,&title);
     for(j=0;j<count;j++)if(entries[j].command&&!strcmp(entries[j].command,"toggle-startup"))break;
     assert(j<count);menu_selection=j;menu_run();assert(startup_movement&&!movement_mode);}
    pass("startup help/path report and menu use the same persistent operation");
    assert(unlink(path)==0);free(path);free(dir);unsetenv("XDG_CONFIG_HOME");reset_doc("");
}
/* Single Esc preference: command/menu parity, restart and failure atomicity. */
static void test_esc069(void) {
    char root[1024], *path;
    struct stat a,b;
    int fds,i; size_t calls;
    const char *initial="# mine\r\nstartup=movement\r\nesc = cli # ui\r\nsignal_controls=off\r\nesc=cli";
    const char *menu_config="# mine\r\nstartup=movement\r\nesc = menu # ui\r\nsignal_controls=off\r\nesc=menu";
    reset_doc("parent\n");menu_preferred=false;
    snprintf(root,sizeof root,"%s/esc-tests",test_home);assert(setenv("XDG_CONFIG_HOME",root,1)==0);
    path=config_path("config",true);assert(path);
    write_bytes(path,initial,strlen(initial));load_startup_config();assert(movement_mode&&!menu_preferred);
    assert(command_lookup("menu")&&!command_lookup("cli")&&!command_lookup("mode"));
    assert(command_lookup("toggle-esc") && command_lookup("settings"));
    assert(command_lookup("options")==command_lookup("settings"));
    assert(edit(0,0,"dirty ",6,false));cursor=3;
    command_run("toggle-esc");assert(menu_preferred&&movement_mode&&cursor==3&&undo_depth()==1);
    check_bytes(path,menu_config,strlen(menu_config));assert(!strcmp(text.s,"dirty parent\n"));
    menu_preferred=false;load_startup_config();assert(menu_preferred);
    command_run("toggle-esc");assert(!menu_preferred);check_bytes(path,initial,strlen(initial));
    command_run("toggle-esc extra");assert(!menu_preferred);check_bytes(path,initial,strlen(initial));
    viewer_text=viewer_title=NULL;command_mode=false;
    pass("one Esc toggle persists, preserves config/text/history and rejects obsolete separate verbs");

    write_bytes(path,"startup=edit\nesc=cli\n",21);assert(save_preference(SETTING_ESC,1));
    assert(stat(path,&a)==0);assert(save_preference(SETTING_ESC,1));assert(stat(path,&b)==0);
    assert(same_disk_version(&a,&b));
    write_bytes(path,"startup=movement\nesc=wrong\n",27);load_startup_config();
    assert(startup_config_warning && !menu_preferred&&movement_mode);
    command_run("toggle-esc");check_bytes(path,"startup=movement\nesc=menu\n",26);
    assert(menu_preferred&&!startup_config_warning);
    pass("Esc preference no-op avoids disk rewrite; invalid values warn and are correctable");

    write_bytes(path,"startup=edit\nesc=cli\n",21);menu_preferred=false;
    fds=descriptors();
    for(i=0;i<20;i++) {
        fail_sync=1;command_run("toggle-esc");fail_sync=0;
        assert(!menu_preferred&&viewer_text);viewer_text=viewer_title=NULL;command_mode=false;
        check_bytes(path,"startup=edit\nesc=cli\n",21);
        fail_rename=1;command_run("toggle-esc");fail_rename=0;
        assert(!menu_preferred&&viewer_text);viewer_text=viewer_title=NULL;command_mode=false;
        read_budget=0;command_run("toggle-esc");read_budget=-1;
        assert(!menu_preferred);viewer_text=viewer_title=NULL;command_mode=false;
        check_bytes(path,"startup=edit\nesc=cli\n",21);
        assert(descriptors()==fds);
    }
    allocation_calls=0;assert(save_preference(SETTING_ESC,1));calls=allocation_calls;
    for(i=0;i<(int)calls;i++) {
        write_bytes(path,"startup=edit\nesc=cli\n",21);menu_preferred=false;
        allocation_failure=i;assert(!save_preference(SETTING_ESC,1));allocation_failure=-1;
        assert(!menu_preferred);check_bytes(path,"startup=edit\nesc=cli\n",21);
        assert(descriptors()==fds);
    }
    pass("Esc save failures leave live and saved choices intact with no descriptor leak");

    reset_doc("base\n");menu_preferred=false;mouse_enabled=false;signal_controls=0;
    write_bytes(path,"startup=edit\nesc=cli\n",21);
    command_run("menu");assert(menu_open && menu_page==MENU_ROOT && !menu_preferred);
    menu_back();assert(!menu_open&&!menu_preferred);
    command_run("settings");assert(menu_open && menu_page==MENU_SETTINGS && !menu_preferred);
    menu_selection=1;menu_run();assert(menu_open && menu_page==MENU_SETTINGS && menu_selection==1 && menu_preferred);
    menu_selection=0;menu_run();assert(menu_open&&startup_movement&&!movement_mode);
    menu_selection=5;menu_run();assert(menu_page==MENU_KEYS);
    menu_back();assert(menu_page==MENU_SETTINGS&&menu_selection==5);
    menu_back();assert(menu_page==MENU_HELP&&menu_selection==6);
    menu_back();assert(menu_page==MENU_ROOT&&menu_selection==6);
    menu_back();assert(!menu_open&&menu_preferred);
    command_run("settings");menu_selection=8;menu_run();
    assert(!menu_open&&menu_preferred&&!movement_mode);
    assert(stat(path,&a)==0);command_run("settings");menu_selection=8;menu_run();
    assert(stat(path,&b)==0&&same_disk_version(&a,&b));
    command_run("toggle-esc");assert(!menu_preferred);
    assert(!strcmp(text.s,"base\n")&&!history);
    pass("nested Help/Settings/hotkeys navigation and persistent toggles preserve focus and document");
    unlink(path);free(path);unsetenv("XDG_CONFIG_HOME");reset_doc("");menu_preferred=false;
}

/* Saved signal preferences share the transactional configuration writer. */
static void test_saved_signals069(void) {
    char root[1024], *path;
    const char *old="# preserve\r\nstartup=movement\r\nesc=cli\r\nsignal_controls = off # native\r\nunknown=yes\r\nsignal_controls=off";
    const char *on="# preserve\r\nstartup=movement\r\nesc=cli\r\nsignal_controls = on # native\r\nunknown=yes\r\nsignal_controls=on";
    size_t i, calls; int fds;
    struct stat a,b;
    reset_doc("base\n");menu_preferred=false;
    snprintf(root,sizeof root,"%s/saved-signals",test_home);assert(setenv("XDG_CONFIG_HOME",root,1)==0);
    path=config_path("config",true);assert(path);
    command_run("settings show");assert(!signal_controls&&access(path,F_OK)<0);
    viewer_text=viewer_title=NULL;command_mode=false;
    command_run("toggle-signals");check_bytes(path,"signal_controls=on\n",19);
    assert(signal_controls&&startup_signals&&!movement_mode&&!menu_preferred);
    signal_controls=0;load_startup_config();assert(signal_controls);
    command_run("toggle-signals");check_bytes(path,"signal_controls=off\n",20);
    signal_controls=1;load_startup_config();assert(!signal_controls);
    command_run("toggle-signals");assert(signal_controls);
    signal_controls=0;load_startup_config();assert(signal_controls);
    pass("signal changes persist and reload; a status-only query does not create config");

    write_bytes(path,old,strlen(old));load_startup_config();
    assert(movement_mode&&!signal_controls);
    assert(edit(0,0,"X",1,false));cursor=1;
    command_run("toggle-signals");assert(signal_controls&&movement_mode&&!menu_preferred);
    check_bytes(path,on,strlen(on));assert(!strcmp(text.s,"Xbase\n")&&undo_depth()==1&&cursor==1);
    assert(stat(path,&a)==0);assert(save_preference(SETTING_SIGNALS,1));assert(stat(path,&b)==0);
    assert(same_disk_version(&a,&b));
    command_run("toggle-signals invalid");assert(signal_controls&&viewer_text);
    check_bytes(path,on,strlen(on));viewer_text=viewer_title=NULL;command_mode=false;
    command_run("toggle-signals");check_bytes(path,old,strlen(old));
    command_run("settings show");assert(viewer_text&&strstr(viewer_text,"Saved signal handling: OFF")&&strstr(viewer_text,path));
    viewer_text=viewer_title=NULL;command_mode=false;
    pass("signals preserve unrelated values, CRLF, duplicates, comments, text/undo and no-op metadata");

    fds=descriptors();
    for(i=0;i<30;i++) {
        fail_sync=1;command_run("toggle-signals");fail_sync=0;
        assert(!signal_controls&&viewer_text&&strstr(viewer_text,"NOT saved"));
        viewer_text=viewer_title=NULL;command_mode=false;check_bytes(path,old,strlen(old));
        fail_rename=1;command_run("toggle-signals");fail_rename=0;
        assert(!signal_controls&&viewer_text);viewer_text=viewer_title=NULL;command_mode=false;
        write_budget=0;command_run("toggle-signals");write_budget=-1;
        assert(!signal_controls&&viewer_text);viewer_text=viewer_title=NULL;command_mode=false;
        check_bytes(path,old,strlen(old));assert(descriptors()==fds);
    }
    allocation_calls=0;assert(save_preference(SETTING_SIGNALS,1));calls=allocation_calls;
    for(i=0;i<calls;i++) {
        write_bytes(path,old,strlen(old));startup_signals=false;signal_controls=0;
        allocation_failure=(long)i;assert(!save_preference(SETTING_SIGNALS,1));allocation_failure=-1;
        assert(!startup_signals&&!signal_controls&&descriptors()==fds);check_bytes(path,old,strlen(old));
    }
    printf("METRIC signal config allocation failure points: %zu\n",calls);
    pass("signal persistence failures retain behavior/config and leak no descriptors");

    snprintf(startup_test_path,sizeof startup_test_path,"%s",path);
    sync_hook=rewrite_startup_during_save;command_run("toggle-signals");
    assert(!signal_controls&&viewer_text);check_bytes(path,"# changed elsewhere\nstartup=edit\n",33);
    viewer_text=viewer_title=NULL;command_mode=false;
    command_run("toggle-signals");assert(signal_controls);check_bytes(path,"# changed elsewhere\nstartup=edit\nsignal_controls=on\n",52);
    fail_sync_after=1;command_run("toggle-signals");fail_sync_after=-1;
    assert(!signal_controls&&startup_sync_warning&&viewer_text&&strstr(viewer_text,"Warning"));
    viewer_text=viewer_title=NULL;command_mode=false;
    load_startup_config();assert(!signal_controls);
    pass("other-session config changes survive; a committed signal preference reports directory-sync warnings");

    assert(chmod(path,0444)==0);command_run("toggle-signals");
    assert(!signal_controls&&viewer_text);viewer_text=viewer_title=NULL;command_mode=false;
    assert(chmod(path,0644)==0);menu_enter(MENU_SETTINGS);
    menu_selection=3;menu_run();assert(menu_open&&menu_page==MENU_SETTINGS&&menu_selection==3&&signal_controls);
    signal_controls=0;load_startup_config();assert(signal_controls);
    menu_selection=3;menu_run();assert(menu_open&&!signal_controls);
    assert(!strcmp(text.s,"Xbase\n")&&cursor==1&&undo_depth()==1);
    pass("Help/Settings signal toggle shares saved command operation and preserves focus and edits");
    fail_sync_after=1;menu_selection=3;menu_run();fail_sync_after=-1;
    assert(signal_controls && startup_sync_warning);
    assert(viewer_text && strstr(viewer_text,"Warning: directory sync failed"));
    viewer_key('q');assert(command_mode);command_key(KEY_ESCAPE);
    assert(!strcmp(text.s,"Xbase\n")&&undo_depth()==1);
    pass("saved-setting durability warnings remain visible instead of hidden by the menu");
    assert(unlink(path)==0);free(path);unsetenv("XDG_CONFIG_HOME");reset_doc("");menu_preferred=false;
}

/* 0.6.10: one saved switch contract across commands, menus, help and config. */
static void dismiss_test_guide(void) {
    viewer_text=viewer_title=NULL;command_mode=false;
}
static void test_toggles0610(void) {
    const char *initial="startup=edit\nesc=cli\nsignal_controls=off\nmouse=off\n";
    const char *retired[]={"startup", "startmode", "startup-mode", "toggle-mode", "toggle-interface", "mouse", "pointer", "signals", "signal-controls"};
    char root[1024], state[1024], input[96], *path, *flag;
    Buffer before={0}, after={0};struct stat st, stamp;
    size_t i,j,n,seen[SETTING_COUNT]={0}, calls, transaction;
    int fds;
    const char *title;const MenuItem *items;
    reset_doc("document\n");menu_preferred=mouse_enabled=clip_history_enabled=false;
    snprintf(root,sizeof root,"%s/toggles",test_home);
    snprintf(state,sizeof state,"%s/toggle-state",test_home);
    assert(setenv("XDG_CONFIG_HOME",root,1)==0&&setenv("XDG_STATE_HOME",state,1)==0);
    path=config_path("config",true);assert(path);write_bytes(path,initial,strlen(initial));load_startup_config();
    flag=state_path("clipboard-history.enabled",true);assert(flag);
    assert(clipboard_history_setting(false));
    assert(edit(0,0,"draft ",6,false));cursor=4;transaction=undo_depth();
    for(i=0;i<SETTING_COUNT;i++) {
        const CommandHelp *help=command_lookup(setting_toggles[i].command);
        assert(help&&!strcmp(help->syntax,help->name));
        assert(!strncmp(help->name,"toggle-",7));
        assert(!setting_enabled((int)i));
        command_run(help->name);assert(setting_enabled((int)i));
        assert(!strcmp(text.s,"draft document\n")&&cursor==4&&undo_depth()==transaction&&!movement_mode);
    }
    assert(startup_movement&&menu_preferred&&mouse_enabled&&signal_controls&&clip_history_enabled);
    assert(bind_count==0 || !binding_action(3));
    pass("five argument-free switches save and report without editing the document or changing current movement");

    assert(read_file(path,&before,&stamp));
    command_run("settings show");assert(viewer_text&&strstr(viewer_text,path)&&strstr(viewer_text,"Saved mouse: On"));
    dismiss_test_guide();assert(read_file(path,&after,&st));assert(same_disk_version(&stamp,&st)&&same_bytes(&before,&after));
    free(before.s);free(after.s);before=(Buffer){0};after=(Buffer){0};
    menu_enter(MENU_SETTINGS);items=menu_entries(&n,&title);
    for(i=0;i<n;i++) {
        int kind=setting_toggle_index(items[i].command);
        if(kind<0)continue;
        seen[kind]++;menu_selection=i;menu_run();
        assert(menu_open&&menu_selection==i&&menu_page==MENU_SETTINGS&&!setting_enabled(kind));
    }
    for(i=0;i<SETTING_COUNT;i++)assert(seen[i]==1);
    load_startup_config();clip_history_enabled=false;clipboard_history_load_setting();
    for(i=0;i<SETTING_COUNT;i++)assert(!setting_enabled((int)i));
    assert(!movement_mode&&!strcmp(text.s,"draft document\n")&&undo_depth()==transaction);
    pass("one menu row per switch, same operations and focus, read-only settings report and restart parity");

    assert(read_file(path,&before,&stamp));
    for(i=0;i<SETTING_COUNT;i++) {
        const char *tails[]={" on", " off", " toggle", " movement", " extra"};
        for(j=0;j<sizeof tails/sizeof tails[0];j++) {
            snprintf(input,sizeof input,"%s%s",setting_toggles[i].command,tails[j]);command_run(input);
            assert(viewer_text&&!setting_enabled((int)i)&&!strcmp(command,input));dismiss_test_guide();
        }
    }
    for(i=0;i<sizeof retired/sizeof retired[0];i++) {
        assert(!command_lookup(retired[i]));command_run(retired[i]);
        assert(viewer_text&&strstr(viewer_text,"NO arguments")&&!strcmp(command,retired[i]));dismiss_test_guide();
    }
    command_run("cliphistory on");assert(!clip_history_enabled&&viewer_text);dismiss_test_guide();
    assert(read_file(path,&after,&st));assert(same_bytes(&before,&after)&&same_disk_version(&stamp,&st));
    free(before.s);free(after.s);before=(Buffer){0};after=(Buffer){0};
    check_bytes(flag,"off\n",4);
    pass("obsolete names and every toggle argument refuse execution and preserve exact drafts, settings and clipboard flag");

    fds=descriptors();
    for(i=0;i<30;i++) {
        fail_sync=1;command_run("toggle-mouse");fail_sync=0;
        assert(!mouse_enabled&&!startup_mouse&&viewer_text);dismiss_test_guide();
        check_bytes(path,initial,strlen(initial));
        fail_rename=1;command_run("toggle-mouse");fail_rename=0;
        assert(!mouse_enabled&&viewer_text);dismiss_test_guide();check_bytes(path,initial,strlen(initial));
        fail_sync=1;command_run("toggle-cliphistory");fail_sync=0;
        assert(!clip_history_enabled&&viewer_text);dismiss_test_guide();check_bytes(flag,"off\n",4);
        assert(descriptors()==fds);
    }
    allocation_calls=0;assert(save_preference(SETTING_MOUSE,1));calls=allocation_calls;
    for(i=0;i<calls;i++) {
        write_bytes(path,initial,strlen(initial));startup_mouse=mouse_enabled=false;
        allocation_failure=(long)i;assert(!save_preference(SETTING_MOUSE,1));allocation_failure=-1;
        assert(!startup_mouse&&!mouse_enabled&&descriptors()==fds);check_bytes(path,initial,strlen(initial));
    }
    pass("mouse and clipboard switch save failures preserve prior choices and release all descriptors");

    menu_open=false;command_mode=false;movement_mode=false;
    menu_enter(MENU_CONTROL);items=menu_entries(&n,&title);
    j=0;for(i=0;i<n;i++)if(items[i].action==MENU_MOVEMENT)j++;
    assert(j==1&&stat(path,&stamp)==0);
    menu_selection=0;menu_run();assert(movement_mode&&menu_open);
    menu_run();assert(!movement_mode&&menu_open);
    assert(stat(path,&st)==0&&same_disk_version(&stamp,&st));
    assert(undo_depth()==transaction&&cursor==4);
    pass("current movement/edit has one menu switch but remains separate from saved startup");

    write_bytes(path,initial,strlen(initial));load_startup_config();clip_history_enabled=false;
    for(j=0;j<20;j++) {
        for(i=0;i<SETTING_COUNT;i++) {command_run(setting_toggles[i].command);assert(setting_enabled((int)i));}
        for(i=0;i<SETTING_COUNT;i++) {command_run(setting_toggles[i].command);assert(!setting_enabled((int)i));}
    }
    check_bytes(path,initial,strlen(initial));check_bytes(flag,"off\n",4);
    assert(descriptors()==fds&&!strcmp(text.s,"draft document\n")&&cursor==4&&undo_depth()==transaction);
    pass("200 mixed toggles preserve config size, document, cursor and undo without descriptor growth");
    free(path);free(flag);unsetenv("XDG_CONFIG_HOME");unsetenv("XDG_STATE_HOME");
    reset_doc("");menu_preferred=mouse_enabled=clip_history_enabled=false;
}

/* 0.6.11: terminal paste line endings are input events, not file bytes. */
static size_t feed_paste0611(const char *payload, size_t n, long fail_at) {
    char path[1024]; int fd, oldtty=tty_in; size_t before, calls;
    snprintf(path,sizeof path,"%s/paste0611-input",test_home);
    fd=open(path,O_RDWR|O_CREAT|O_TRUNC,0600);assert(fd>=0);
    assert(write_all(fd,payload,n)==0);
    assert(write_all(fd,"\033[201~Z",7)==0);assert(lseek(fd,0,SEEK_SET)==0);
    tty_in=fd;input_at=input_n=0;paste_discard=false;paste_end_matched=0;
    before=allocation_calls;allocation_failure=fail_at;
    paste();allocation_failure=-1;calls=allocation_calls-before;
    assert(byte(0)=='Z'); /* Never consume or execute the following input. */
    assert(close(fd)==0);tty_in=oldtty;input_at=input_n=0;
    return calls;
}
static void paste_style0611(bool crlf) {
    newline[0]=crlf?'\r':'\n';newline[1]=crlf?'\n':0;newline_n=crlf?2:1;
}
static void test_paste0611(void) {
    static const char raw[]=
        "ex.html\"\r    location \"/api/*\" {\r        block return 404\r    }\r"
        "    location \"/.*\" {\r        block return 404\r    }\r}";
    char wire[1024], expected[1024];size_t i,j,w,n,calls;int style,form,fds;
    for(style=0;style<2;style++) {
        for(form=0;form<3;form++) {
            w=n=0;
            for(i=0;i<sizeof raw-1;i++) {
                if(raw[i]=='\r') {
                    if(form!=1)wire[w++]='\r';
                    if(form!=0)wire[w++]='\n';
                    if(style)expected[n++]='\r';
                    expected[n++]='\n';
                } else {wire[w++]=raw[i];expected[n++]=raw[i];}
            }
            expected[n]=0;
            reset_doc("tail\n");paste_style0611(style!=0);
            feed_paste0611(wire,w,-1);
            assert(cursor==n&&text.n==n+5&&!memcmp(text.s,expected,n));
            assert(!memcmp(text.s+n,"tail\n",5)&&undo_depth()==1);
            assert(history_step(false)&&!strcmp(text.s,"tail\n")&&cursor==0);
            assert(history_step(true)&&!memcmp(text.s,expected,n)&&cursor==n);
        }
    }
    pass("reported config block: CR, LF and CRLF paste into LF/CRLF documents; one undo/redo");

    reset_doc("");
    {static const char mixed[]="\r\r\n\n\t  a\r\nb\rc\n^M \303\251\r";
     const char *want="\n\n\n\t  a\nb\nc\n^M \303\251\n";
     feed_paste0611(mixed,sizeof mixed-1,-1);assert(!strcmp(text.s,want));}
    reset_doc("");short_io=1;
    feed_paste0611("A\r\nB\rC\nD\r",9,-1);short_io=0;
    assert(!strcmp(text.s,"A\nB\nC\nD\n"));
    /* A failed marker prefix is data separating CR and LF. */
    reset_doc("");feed_paste0611("A\r\033[20\nB\r\033X\n",12,-1);
    assert(!strcmp(text.s,"A\n\033[20\nB\n\033X\n"));
    reset_doc("");feed_paste0611("\r",1,-1);feed_paste0611("\n",1,-1);
    assert(!strcmp(text.s,"\n\n")&&undo_depth()==2);
    pass("mixed endings, blank lines, tabs, UTF-8, literal ^M, fragmented CRLF and marker-prefix boundaries");

    for(style=0;style<2;style++) for(j=0;j<400;j++) {
        char model[1024];size_t len=rand32()%240, out=0, previous=0;
        for(i=0;i<len;i++) wire[i]="ABC\r\n\t ^M"[rand32()%9];
        /* Independent model: consume a CRLF pair together, otherwise one byte. */
        for(i=0;i<len;i++) {
            if(wire[i]=='\r'||wire[i]=='\n') {
                if(wire[i]=='\r'&&i+1<len&&wire[i+1]=='\n')i++;
                if(style)model[out++]='\r';
                model[out++]='\n';
            } else model[out++]=wire[i];
        }
        reset_doc("prefix\nsuffix\n");paste_style0611(style!=0);cursor=7;previous=text.n;
        feed_paste0611(wire,len,-1);
        assert(text.n==previous+out&&!memcmp(text.s,"prefix\n",7));
        assert(!memcmp(text.s+7,model,out)&&!memcmp(text.s+7+out,"suffix\n",7));
        if(out) {assert(history_step(false)&&!strcmp(text.s,"prefix\nsuffix\n"));assert(history_step(true));}
    }
    pass("800 independent mixed-ending models agree with insertion, undo and redo");

    {char *large=malloc(LIMIT);assert(large);memset(large,'x',LIMIT-1);large[LIMIT-1]=0;
     reset_doc(large);cursor=text.n;feed_paste0611("\r\n",2,-1);
     assert(text.n==LIMIT&&text.s[LIMIT-1]=='\n'&&undo_depth()==1);
     assert(history_step(false)&&text.n==LIMIT-1);
     reset_doc(large);paste_style0611(true);cursor=text.n;feed_paste0611("\n",1,-1);
     assert(text.n==LIMIT-1&&cursor==LIMIT-1&&!undo_depth());
     large[LIMIT-2]=0;reset_doc(large);paste_style0611(true);cursor=text.n;
     feed_paste0611("\r\n",2,-1);assert(text.n==LIMIT&&!memcmp(text.s+LIMIT-2,"\r\n",2));
     free(large);}
    pass("8 MiB boundary checks use inserted size: CRLF collapse fits; newline expansion refuses atomically");

    reset_doc("parent\n");assert(edit(0,0,"X",1,false));assert(history_step(false));
    feed_paste0611("line\r\n\0quit!\r",13,-1);
    assert(!strcmp(text.s,"parent\n")&&!undo_depth()&&redo_depth()==1&&running);
    for(i=0;i<3;i++) {
        reset_doc("parent\n");command_mode=true;command_set("write safe");
        const char *line=i==0?"a\rb":i==1?"a\nb":"a\r\nb";
        feed_paste0611(line,strlen(line),-1);
        assert(!strcmp(command,"write safe")&&viewer_text&&!strcmp(text.s,"parent\n")&&!undo_depth());
    }
    for(i=0;i<5;i++) {
        reset_doc("parent\n");
        if(i==0)movement_mode=true;
        else if(i==1)menu_open=true;
        else if(i==2)viewer_text="manual";
        else if(i==3)reverse_mode=true;
        else prompt=PROMPT_QUIT;
        feed_paste0611("\r\nquit!\rY",9,-1);assert(!strcmp(text.s,"parent\n")&&!undo_depth()&&running);
    }
    pass("NUL refusal, redo preservation, multiline prompt rejection and nonediting-mode paste isolation");

    reset_doc("unchanged\n");calls=feed_paste0611(raw,sizeof raw-1,-1);fds=descriptors();
    for(i=0;i<calls;i++) {
        reset_doc("unchanged\n");feed_paste0611(raw,sizeof raw-1,(long)i);
        assert(!strcmp(text.s,"unchanged\n")&&!undo_depth()&&cursor==0&&descriptors()==fds);
    }
    printf("METRIC terminal-paste allocation failures: %zu points\n",calls);
    pass("paste allocation failures keep document/cursor/history unchanged and drain the end marker");

    reset_doc("disk\r\n");attach_file("paste0611-disk.txt");paste_style0611(true);cursor=text.n;
    feed_paste0611("a\rb\r\n",5,-1);save_file(NULL,false);
    check_bytes(filename,"disk\r\na\r\nb\r\n",12);forget_history();journal_load();
    assert(history_step(false)&&!strcmp(text.s,"disk\r\n"));assert(history_step(true));
    assert(!strcmp(text.s,"disk\r\na\r\nb\r\n"));
    pass("normalized paste survives save and cross-session journal restoration as one transaction");

    reset_doc("dirty parent\n");cursor=3;assert(clipboard_choose("paste0611"));clipboard_open();
    assert(editing_clipboard);feed_paste0611("one\r\ntwo\r",9,-1);clipboard_open();
    assert(!editing_clipboard&&cursor==3&&!strcmp(text.s,"dirty parent\n"));
    {char *p=clipboard_path(false);assert(p);check_bytes(p,"one\ntwo\n",8);
     /* File-backed copy/paste is deliberately not terminal normalization. */
     write_bytes(p,"raw\rbytes\r\n",11);free(p);command_run("paste");
     assert(text.n>=11&&!memcmp(text.s,"raw\rbytes\r\n",11));command_run("undo");}
    assert(!strcmp(text.s,"dirty parent\n"));
    pass("clipboard editor normalizes terminal paste, keeps parent intact; file-backed paste preserves bytes");
    reset_doc("");
}

int main(int argc,char **argv) {
    char home[512];
    const char *root=getenv("EDITOR_TEST_ROOT");
    int n;
    (void)argc;(void)argv;
    setvbuf(stdout,NULL,_IOLBF,0);
    if (!root || *root!='/') root="/tmp";
    n=snprintf(home,sizeof home,"%s/editor-core-XXXXXX",root);
    assert(n>0 && (size_t)n<sizeof home);
    assert(mkdtemp(home));strcpy(test_home,home);assert(setenv("HOME",test_home,1)==0);
    unsetenv("XDG_CONFIG_HOME");unsetenv("XDG_STATE_HOME");
    if(argc>1) {if(!strcmp(argv[1],"paste0611"))test_paste0611();test_review(argv[1]);test_review_064(argv[1]);test_review_067(argv[1]);test_review_068(argv[1]);}
    else {
        test_modes_config();test_failures();test_commands();test_persistence();test_clipboards();test_random();
        test_review(NULL);test_review_064(NULL);test_signals_and_exit();test_terminal_start_interrupted();test_cli_guidance();test_review_067(NULL);test_review_068(NULL);test_startup069();test_esc069();test_saved_signals069();test_toggles0610();test_paste0611();
    }
    reset_doc("");free(text.s);free(saved.s);memset(&text,0,sizeof text);memset(&saved,0,sizeof saved);
    printf("PASS: %u test groups. Temporary test files: %s\n",checks,test_home);
    return 0;
}
