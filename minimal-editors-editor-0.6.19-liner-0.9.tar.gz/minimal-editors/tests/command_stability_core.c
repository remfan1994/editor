/* Development-only regressions for aliases, scripts and definition saves.
 * Hooks exercise actual staging/commit boundaries; none ship in editor. */
#if defined(__OpenBSD__)
#define _BSD_SOURCE 1
#endif
#define _XOPEN_SOURCE 700
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static void (*stage_hook)(void), (*commit_hook)(void);
static int fail_sync, fail_rename, fail_stat, fail_temp;
static char defs_path[4096], foreign_path[4096];
static int checked_sync(int fd);
static int checked_rename(const char *from, const char *to);
static int checked_lstat(const char *path, struct stat *st);
static int checked_mkstemp(char *path);
#define fsync checked_sync
#define rename checked_rename
#define lstat checked_lstat
#define mkstemp checked_mkstemp
#define main editor_main
#ifndef EDITOR_SOURCE
#define EDITOR_SOURCE "../editor.c"
#endif
#include EDITOR_SOURCE
#undef main
#undef fsync
#undef rename
#undef lstat
#undef mkstemp

static void put_file(const char *path, const char *bytes)
{
    int fd=open(path,O_WRONLY|O_CREAT|O_TRUNC,0600);
    size_t n=strlen(bytes);
    assert(fd>=0 && write_all(fd,bytes,n)==0 && close(fd)==0);
}
static void expect_file(const char *path, const char *bytes)
{
    Buffer b={0};struct stat st;
    assert(read_file(path,&b,&st));
    assert(b.n==strlen(bytes) && (!b.n || !memcmp(b.s,bytes,b.n)));
    free(b.s);
}
static int checked_sync(int fd)
{
    struct stat st;
    assert(fstat(fd,&st)==0);
    if (stage_hook && S_ISREG(st.st_mode)) {
        void (*hook)(void)=stage_hook;stage_hook=NULL;hook();
    }
    if (fail_sync) {errno=EIO;return -1;}
    return fsync(fd);
}
static int checked_rename(const char *from,const char *to)
{
    int result;
    if (fail_rename) {errno=EIO;return -1;}
    result=rename(from,to);
    if (!result && commit_hook && !strcmp(to,defs_path)) {
        void (*hook)(void)=commit_hook;commit_hook=NULL;hook();
    }
    return result;
}
static int checked_lstat(const char *path,struct stat *st)
{
    if (fail_stat && !strcmp(path,defs_path)) {
        fail_stat--;errno=EIO;return -1;
    }
    return lstat(path,st);
}
static int checked_mkstemp(char *path)
{
    if (fail_temp) {
        fail_temp=0;
        memcpy(path+strlen(path)-6,"OWNED1",6);
        put_file(path,"belongs to somebody else\n");
        assert(strlen(path)<sizeof foreign_path);
        memcpy(foreign_path,path,strlen(path)+1);
        errno=EACCES;return -1;
    }
    return mkstemp(path);
}
static void run_command(const char *s) {command_set(s);execute();}
static void define_memory(const char *name,const char *body)
{
    assert(user_command_count<USER_CMD_MAX && strlen(name)<USER_CMD_NAME &&
           strlen(body)<USER_CMD_BODY);
    memcpy(user_commands[user_command_count].name,name,strlen(name)+1);
    memcpy(user_commands[user_command_count++].body,body,strlen(body)+1);
}
static void changed_during_stage(void) {put_file(defs_path,"outside\tmovement\n");}
static void failed_after_commit(void) {fail_stat=1;}
static void changed_after_commit(void)
{
    char other[sizeof defs_path+16];
    assert(snprintf(other,sizeof other,"%s.outside",defs_path)>0);
    put_file(other,"outside\tmovement\n");
    assert(rename(other,defs_path)==0);
}
static void changed_in_place_after_commit(void)
{
    const char *outside="one\tedit\ntwo\tshell ls\n";
    struct stat before;
    struct timespec times[2];
    int fd;
    /* Preserve inode, byte count and mtime while making a real outside edit.
     * Its new ctime must never be adopted as evidence for our old table. */
    assert(lstat(defs_path,&before)==0 && (size_t)before.st_size==strlen(outside));
    times[0]=before.st_atim;times[1]=before.st_mtim;
    fd=open(defs_path,O_WRONLY|O_TRUNC);
    assert(fd>=0 && write_all(fd,outside,strlen(outside))==0);
    assert(futimens(fd,times)==0 && close(fd)==0);
}
static void stop_during_stage(void) {interrupted=1;}
static void directory_sync_failure(void) {fail_sync=1;}
static void initial_definitions(void)
{
    put_file(defs_path,"one\tedit\n");
    assert(load_user_commands());
    assert(user_command_count==1 && user_command_index("one")==0);
}
static void aliases(void)
{
    define_memory("q1","quit!");
    define_memory("stop","quit");
    define_memory("save","write");
    define_memory("bye","q1");
    define_memory("circle","circle");
    assert(edit(0,0,"unsaved",7,false));
    run_command("stop");assert(running && strstr(message,"Unsaved work"));
    run_command("save");assert(running && filename_mode);
    filename_mode=command_mode=false;
    run_command("circle");assert(running && strstr(message,"recursion limit"));
    run_command("q1 extra");assert(running && strstr(message,"takes no arguments"));
    run_command("bye");assert(!running);
    assert(command_history_n && !strcmp(command_history[0],"bye"));
}
static void script_boundary(void)
{
    define_memory("q1","quit!");
    define_memory("save","write");
    define_memory("nested","q1");
    assert(!execute_script_step("nested") && running);
    assert(strstr(message,"Not permitted in scripts"));
    assert(!execute_script_step("save") && !filename_mode);
    assert(!execute_script_step("next extra"));
    assert(strstr(message,"Invalid script arguments"));
}
static void search_failure(void)
{
    char *path=config_path("steps.editor",true);
    assert(path);
    put_file(path,"find absent\nbottom\n");
    cursor=1;
    assert(!run_script_file(path));
    assert(cursor==1 && strstr(message,"Script line 1 stopped"));
    assert(strstr(message,"No match"));
    put_file(path,"find first\nbottom\n");
    assert(run_script_file(path) && cursor==text.n);
    free(path);
}
static void save_race_existing(void)
{
    initial_definitions();stage_hook=changed_during_stage;
    assert(!change_user_command("two","movement"));
    expect_file(defs_path,"outside\tmovement\n");
    assert(user_command_count==1 && user_command_index("two")<0);
}
static void save_race_new(void)
{
    assert(load_user_commands() && user_command_count==0);
    stage_hook=changed_during_stage;
    assert(!change_user_command("two","movement"));
    expect_file(defs_path,"outside\tmovement\n");
    assert(user_command_count==0);
}
static void save_committed_stat_failure(void)
{
    initial_definitions();commit_hook=failed_after_commit;
    assert(change_user_command("two","movement"));
    assert(user_command_index("two")>=0);
    expect_file(defs_path,"one\tedit\ntwo\tmovement\n");
    assert(load_user_commands() && change_user_command("three","edit"));
}
static void save_committed_race(void)
{
    initial_definitions();commit_hook=changed_after_commit;
    assert(change_user_command("two","movement"));
    assert(!change_user_command("three","edit"));
    expect_file(defs_path,"outside\tmovement\n");
    assert(load_user_commands() && user_command_index("outside")>=0);
}
static void save_committed_inplace_race(void)
{
    initial_definitions();commit_hook=changed_in_place_after_commit;
    assert(change_user_command("two","movement"));
    expect_file(defs_path,"one\tedit\ntwo\tshell ls\n");
    assert(!change_user_command("three","edit"));
    expect_file(defs_path,"one\tedit\ntwo\tshell ls\n");
    assert(load_user_commands() && user_command_index("two")>=0);
    assert(!strcmp(user_commands[user_command_index("two")].body,"shell ls"));
}
static void save_failures(void)
{
    int before=0, after=0;
    initial_definitions();
    for (int fd=0;fd<1024;fd++) if (fcntl(fd,F_GETFD)>=0) before++;
    for (int i=0;i<32;i++) {
        fail_sync=1;assert(!change_user_command("two","edit"));fail_sync=0;
        fail_rename=1;assert(!change_user_command("two","edit"));fail_rename=0;
        stage_hook=stop_during_stage;
        assert(!change_user_command("two","edit"));interrupted=0;
    }
    for (int fd=0;fd<1024;fd++) if (fcntl(fd,F_GETFD)>=0) after++;
    assert(before==after && user_command_count==1);
    expect_file(defs_path,"one\tedit\n");
    fail_temp=1;assert(!change_user_command("two","edit"));
    expect_file(foreign_path,"belongs to somebody else\n");
    commit_hook=directory_sync_failure;
    assert(change_user_command("two","edit"));fail_sync=0;
    assert(strstr(message,"Directory synchronization unavailable"));
    expect_file(defs_path,"one\tedit\ntwo\tedit\n");
}
static void save_permissions(void)
{
    char second[sizeof defs_path+16];
    initial_definitions();assert(chmod(defs_path,0400)==0 && load_user_commands());
    assert(!change_user_command("two","edit"));
    expect_file(defs_path,"one\tedit\n");
    assert(chmod(defs_path,0600)==0);
    assert(snprintf(second,sizeof second,"%s.link",defs_path)>0);
    assert(link(defs_path,second)==0 && load_user_commands());
    assert(!change_user_command("two","edit"));
    expect_file(second,"one\tedit\n");
}
static void definition_parse(void)
{
    initial_definitions();
    put_file(defs_path,"newcmd\tedit\nnewcmd\tmovement\n");
    assert(!load_user_commands());
    assert(user_command_count==1 && user_command_index("one")>=0);
    assert(!change_user_command("two","edit"));
    assert(!user_command_name("files"));
    assert(user_command_name("dirlist") && user_command_name("q1"));
}
int main(int argc,char **argv)
{
    const struct {const char *name;void (*test)(void);} cases[]={
        {"aliases",aliases},{"script-boundary",script_boundary},
        {"search-failure",search_failure},{"save-race-existing",save_race_existing},
        {"save-race-new",save_race_new},{"save-committed-stat-failure",save_committed_stat_failure},
        {"save-committed-race",save_committed_race},{"save-failures",save_failures},
        {"save-committed-inplace-race",save_committed_inplace_race},
        {"save-permissions",save_permissions},{"definition-parse",definition_parse}
    };
    char home[4096];const char *base=getenv("EDITOR_TEST_ROOT");
    unsigned count=0;
    if (!base) base="/tmp";
    assert(snprintf(home,sizeof home,"%s/editor-commands.XXXXXX",base)>0);
    assert(mkdtemp(home));
    assert(setenv("HOME",home,1)==0 && setenv("XDG_CONFIG_HOME",home,1)==0 &&
           setenv("XDG_STATE_HOME",home,1)==0);
    for (size_t i=0;i<sizeof cases/sizeof cases[0];i++) {
        char *path;
        if (argc>1 && strcmp(cases[i].name,argv[1])) continue;
        free_changes(history);history=current=history_tail=NULL;
        free(text.s);text=(Buffer){0};free(saved.s);saved=(Buffer){0};
        assert(copy_buffer(&text,"first\nsecond\n",13) && copy_buffer(&saved,text.s,text.n));
        user_command_count=0;user_commands_loaded=true;user_commands_version_valid=false;
        cursor=top=left=0;running=true;group=false;script_depth=script_steps=0;
        search_length=0;search_mark=SIZE_MAX;search_pattern[0]=0;
        interrupted=terminated=suspended=0;stage_hook=commit_hook=NULL;
        fail_sync=fail_rename=fail_stat=fail_temp=0;
        filename_mode=command_mode=false;viewer_text=viewer_title=NULL;clear_prompt();
        path=config_path("commands.conf",true);assert(path && strlen(path)<sizeof defs_path);
        memcpy(defs_path,path,strlen(path)+1);free(path);(void)unlink(defs_path);
        cases[i].test();
        printf("PASS command-core %s\n",cases[i].name);count++;
    }
    assert(count);
    for (size_t i=0;i<command_history_n;i++) free(command_history[i]);
    free_changes(history);free(text.s);free(saved.s);clear_prompt();reset_screen();
    printf("PASS: %u command stability core groups\n",count);
    return 0;
}
