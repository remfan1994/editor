#!/usr/bin/env python3
"""Delayed paste framing regressions. Python is a development dependency only."""
from pathlib import Path
import os
import signal
import sys
import tempfile
from terminal import Session, set_config
from signals_terminal import ShellJob

BEGIN = b'\x1b[200~'
END = b'\x1b[201~'
NOTICE = b'Paste incomplete; waiting for end marker.'


def scenarios(binary, root):
    count = 0

    def run(name, fn, opt_in=False):
        nonlocal count
        home = root / name
        home.mkdir()
        doc = home / 'sample.conf'
        doc.write_bytes(b'base\n')
        if opt_in:
            set_config(home, b'signal_controls=on\n')
        s = Session(binary, home, [doc])
        try:
            fn(s, home, doc)
            if not s.exited():
                s.finish()
        except BaseException:
            print('FAIL', name, repr(bytes(s.data[-1800:])), flush=True)
            if not s.exited():
                s.kill()
            raise
        count += 1
        print('PASS', name, flush=True)

    def saved(s, doc, expected):
        s.command('write')
        s.wait_file(doc, expected)

    def timeout(s, start):
        # Wait on the actual five-second idle notice rather than a guessed
        # scheduling sleep. Long latency is the input being tested here.
        s.wait_output(NOTICE, timeout=8, start=start)

    def late_commands(s, home, doc):
        s.send(b'X')
        start = len(s.data)
        s.send(BEGIN + b'staged fragment\r')
        timeout(s, start)
        s.send(b'\x1bquit!\r' + END + b'Y')
        assert not s.exited(), 'late paste tail executed as an editor command'
        saved(s, doc, b'XYbase\n')
        s.command('undo'); saved(s, doc, b'Xbase\n')
        s.command('undo'); saved(s, doc, b'base\n')
    run('idle-paste-retains-framing-and-prior-undo', late_commands)

    def split_marker(s, home, doc):
        start = len(s.data)
        s.send(BEGIN + b'fragment' + END[:4])
        timeout(s, start)
        s.send(END[4:] + b'X')
        saved(s, doc, b'Xbase\n')
        s.command('undo'); saved(s, doc, b'base\n')
    run('idle-paste-retains-partial-end-marker', split_marker)

    def command_draft(s, home, doc):
        s.send(b'\x1bfind base')
        start = len(s.data)
        s.send(BEGIN + b'fragment')
        timeout(s, start)
        s.send(b'\rquit!\r' + END)
        assert not s.exited(), 'late paste tail executed from Command>'
        # Escape cancels the retained nonempty command draft; it cannot ask
        # to quit, which would happen if the timed-out paste erased the draft.
        s.send(b'\x1b')
        s.send(b'X')
        saved(s, doc, b'Xbase\n')
    run('idle-command-paste-retains-draft-and-rejects-late-commands', command_draft)

    def cancelled(s, home, doc):
        start = len(s.data)
        s.send(BEGIN + b'fragment')
        os.kill(s.pid, signal.SIGINT)
        s.wait_output(b'Command>', timeout=3, start=start)
        timeout(s, start)
        s.send(b'quit!\r' + END + b'\rX')
        assert not s.exited(), 'idle time cleared cancelled-paste protection'
        saved(s, doc, b'Xbase\n')
    run('cancelled-paste-stays-discarded-after-idle', cancelled, opt_in=True)

    def fresh_marker(s, home, doc):
        start = len(s.data)
        s.send(BEGIN + b'fragment')
        timeout(s, start)
        # Even an explicit opt-in interrupt does not reinterpret paste bytes.
        os.kill(s.pid, signal.SIGINT)
        s.wait_output(b'Command>', timeout=3, start=start)
        s.send(BEGIN + b'\x1bquit!\rignored' + END)
        assert not s.exited()
        s.send(b'\r')
        s.send(BEGIN + b'good\r\n' + END)
        saved(s, doc, b'good\nbase\n')
        s.command('undo'); saved(s, doc, b'base\n')
    run('fresh-paste-end-marker-recovers-incomplete-paste', fresh_marker, opt_in=True)

    def native_interrupt(s, home, doc):
        s.send(b'X')
        start = len(s.data)
        s.send(BEGIN + b'fragment')
        timeout(s, start)
        os.kill(s.pid, signal.SIGINT)
        s.finish(expected_signal=signal.SIGINT)
        assert doc.read_bytes() == b'base\n'
    run('native-interrupt-still-exits-incomplete-paste-and-restores-terminal', native_interrupt)

    home = root / 'suspend-resume'; home.mkdir()
    doc = home / 'sample.conf'; doc.write_bytes(b'base\n')
    s = ShellJob(binary, home, doc)
    try:
        s.send(BEGIN + b'fragment')
        s.stop_resume()
        s.send(b'\x1bquit!\r' + END + b'X')
        s.send(b'\x1bwrite\r'); s.wait(b'Written.')
        assert doc.read_bytes() == b'Xbase\n'
        s.finish()
    except BaseException:
        s.kill(); raise
    count += 1
    print('PASS suspended-paste-discards-late-tail-after-foreground-resume', flush=True)

    print(f'PASS: {count} delayed-paste terminal groups.', flush=True)


if __name__ == '__main__':
    with tempfile.TemporaryDirectory(prefix='editor-paste-stability-') as d:
        scenarios(Path(sys.argv[1]).resolve(), Path(d))
