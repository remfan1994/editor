#!/usr/bin/env python3
"""Held-key input on large documents retains exact cursor/edit locations."""
from pathlib import Path
import sys
import tempfile
from terminal import Session


def main():
    binary = Path(sys.argv[1]).resolve()
    with tempfile.TemporaryDirectory(prefix='editor-layout-terminal-') as tmp:
        root = Path(tmp)
        cases = 0
        for name, many_lines in [('held-down-near-EOF', True), ('held-left-right-long-line', False)]:
            home = root / name
            home.mkdir()
            path = home / 'document.txt'
            size = 8 * 1024 * 1024 - 4096
            original = (b'x' * 63 + b'\n') * (size // 64) if many_lines else b'x' * size
            path.write_bytes(original)
            session = Session(binary, home, [path])
            try:
                if many_lines:
                    line = size // 64 - 250
                    session.command('goto %d 5' % line)
                    session.send(b'\x1b[B' * 200 + b'X')
                    offset = (line - 1 + 200) * 64 + 4
                else:
                    session.command('goto 1 %d' % (size - 999))
                    session.send(b'\x1b[C' * 100 + b'\x1b[D' * 50 + b'X')
                    offset = size - 950
                expected = original[:offset] + b'X' + original[offset:]
                session.command('write')
                session.wait_file(path, expected, timeout=15)
                session.command('undo')
                session.command('write')
                session.wait_file(path, original, timeout=15)
                session.command('redo')
                session.command('write')
                session.wait_file(path, expected, timeout=15)
                session.finish()
            except BaseException:
                print('FAIL', name, repr(bytes(session.data[-1500:])), flush=True)
                session.kill()
                raise
            cases += 1
            print('PASS', name, flush=True)
        home = root / 'read-and-clipboard-context'
        home.mkdir()
        first = home / 'first.txt'
        second = home / 'second.txt'
        first.write_bytes(b'a' * 32768)
        second.write_bytes(b'first\nsecond\n')
        session = Session(binary, home, [first])
        try:
            session.command('goto 1 32000')
            session.command('read ' + str(second))
            session.command('goto 2 3')
            session.send(b'X')
            session.command('write')
            session.wait_file(second, b'first\nseXcond\n')
            session.command('clipboard')
            session.send(b'\x1b[200~' + b'z' * 8192 + b'\x1b[201~')
            session.command('clipboard')
            session.command('goto 2 3')
            session.send(b'Y')
            session.command('write')
            session.wait_file(second, b'first\nseYXcond\n')
            assert first.read_bytes() == b'a' * 32768
            session.finish()
        except BaseException:
            print('FAIL read-and-clipboard-context', repr(bytes(session.data[-1500:])), flush=True)
            session.kill()
            raise
        cases += 1
        print('PASS read-and-clipboard-context', flush=True)
    print('PASS: %d large-document terminal regression groups' % cases)


if __name__ == '__main__':
    main()
