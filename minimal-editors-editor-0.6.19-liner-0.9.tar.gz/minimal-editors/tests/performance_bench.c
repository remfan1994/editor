/* Development-only repeatable CPU timing. No added editor dependency. */
#define main editor_main
#ifndef EDITOR_SOURCE
#define EDITOR_SOURCE "../editor.c"
#endif
#include EDITOR_SOURCE
#undef main
#include <assert.h>

static double cpu_seconds(void) { return (double)clock() / CLOCKS_PER_SEC; }
static double wall_seconds(void)
{
    struct timespec now;
    assert(clock_gettime(CLOCK_MONOTONIC,&now)==0);
    return (double)now.tv_sec+(double)now.tv_nsec/1000000000.0;
}
static double started_cpu,started_wall;
static void begin_measurement(void)
{
    started_cpu=cpu_seconds();started_wall=wall_seconds();
}
static void measurement(const char *name)
{
    double elapsed_wall=wall_seconds()-started_wall;
    double elapsed_cpu=cpu_seconds()-started_cpu;
    printf("%s: %.6f CPU seconds; %.6f wall seconds\n",name,elapsed_cpu,elapsed_wall);
}

static void fixture(size_t length, bool lines)
{
    char *data=malloc(length+1);
    size_t i;
    assert(data);
    memset(data,'x',length); data[length]=0;
    if (lines) for(i=63;i<length;i+=64) data[i]='\n';
    free_changes(history); history=current=history_tail=NULL;
    assert(copy_buffer(&text,data,length));
    assert(copy_buffer(&saved,data,length));
    free(data); reset_screen();
    cursor=top=left=goal=0; group=goal_set=false;
    command_mode=menu_open=movement_mode=false;
    viewer_text=NULL; search_mark=SIZE_MAX;
}

int main(void)
{
    size_t i;
    char *block;
    tty_out=open("/dev/null",O_WRONLY); assert(tty_out>=0);
    rows=24; cols=80;
    fixture(4096,true); cursor=2048; draw();
    begin_measurement();
    for(i=0;i<1000;i++) {text_key(i%2 ? KEY_UP : KEY_DOWN);draw();}
    measurement("config-4KiB: 1000 arrow+redraw");
    fixture(LIMIT,true); cursor=LIMIT-4096;
    begin_measurement();draw();
    measurement("lines-8MiB: first draw near EOF, cold position cache");
    begin_measurement();
    for(i=0;i<200;i++) {text_key(i%2 ? KEY_UP : KEY_DOWN);draw();}
    measurement("lines-8MiB: 200 arrow+redraw near EOF");
    fixture(LIMIT,false); cursor=LIMIT-128;
    begin_measurement();draw();
    measurement("long-line-8MiB: first draw near EOF, cold position cache");
    begin_measurement();
    for(i=0;i<20;i++) {text_key(i%2 ? KEY_LEFT : KEY_RIGHT);draw();}
    measurement("long-line-8MiB: 20 arrow+redraw near EOF");
    fixture(LIMIT-4096,true); cursor=text.n-128; draw();
    begin_measurement();
    for(i=0;i<200;i++) {text_key('a');draw();}
    measurement("lines-near-8MiB: 200 typed bytes+redraw near EOF");
    fixture(LIMIT-4096,true);cursor=text.n-128;draw();
    cursor=top=left=0;draw();
    begin_measurement();
    for(i=0;i<200;i++) {text_key('a');draw();}
    measurement("lines-near-8MiB: 200 typed bytes+redraw at start");
    fixture(4*1024*1024,true); cursor=text.n/2;
    block=malloc(1024*1024); assert(block);memset(block,'p',1024*1024);
    begin_measurement();
    assert(edit(cursor,0,block,1024*1024,false));
    for(i=0;i<100;i++) {assert(history_step(false));assert(history_step(true));}
    measurement("paste-1MiB: insert + 100 undo/redo pairs");
    {
        char path[]="/tmp/editor-performance.XXXXXXXX";
        struct stat st;
        int fd;
        fixture(LIMIT,true);
        fd=mkstemp(path);assert(fd>=0);
        assert(write_all(fd,text.s,text.n)==0);assert(close(fd)==0);
        free(text.s);memset(&text,0,sizeof text);reset_screen();
        begin_measurement();
        assert(read_file(path,&text,&st));
        assert(copy_buffer(&saved,text.s,text.n));
        cursor=top=left=0;draw();
        measurement("lines-8MiB: warm-filesystem read + saved snapshot + first draw at start");
        assert(unlink(path)==0);
    }
    free(block);free_changes(history);free(text.s);free(saved.s);reset_screen();
    assert(close(tty_out)==0);
    return 0;
}
