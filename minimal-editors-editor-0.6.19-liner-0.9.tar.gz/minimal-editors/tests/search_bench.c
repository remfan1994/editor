/* Development-only reproducible local search timing; not an editor command. */
#define main editor_main
#ifndef EDITOR_SOURCE
#define EDITOR_SOURCE "../editor.c"
#endif
#include EDITOR_SOURCE
#undef main
#include <assert.h>
static double cpu(void) { return (double)clock()/CLOCKS_PER_SEC; }
int main(void) {
    size_t i;double start;
    assert(reserve(&text,LIMIT+1));
    memset(text.s,'x',LIMIT);text.n=LIMIT;text.s[text.n]=0;
    memcpy(search_pattern,"hit",4);search_length=3;
    /* Many matches at the beginning; irrelevant repetitive suffix is large. */
    for(i=0;i<200;i++)memcpy(text.s+i*8,"hit\nx\nx\n",8);
#ifdef LAYOUT_STEP
    layout_reset(); /* This benchmark bypasses edit() while making fixtures. */
#endif
    cursor=8;start=cpu();
    for(i=0;i<200;i++){assert(find_match(false,false));assert(find_match(true,false));}
    printf("400 alternating prev/next commands, 8 MiB document: %.6f CPU seconds\n",cpu()-start);
    /* Next through matches near EOF: neither search nor its position message
     * should repeatedly scan the entire prefix once it has been indexed. */
    memset(text.s,'\n',LIMIT);
    for(i=0;i<200;i++)memcpy(text.s+LIMIT-1600+i*8,"hit\nx\nx\n",8);
#ifdef LAYOUT_STEP
    layout_reset();
#endif
    cursor=LIMIT-1600;start=cpu();
    for(i=0;i<199;i++)assert(find_match(true,false));
    printf("199 next commands near EOF, 8 MiB document: %.6f CPU seconds\n",cpu()-start);
    free(text.s);return 0;
}
