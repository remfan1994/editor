/* Differential checks for cached positions and clipped rendering. */
#define main editor_main
#ifndef EDITOR_SOURCE
#define EDITOR_SOURCE "../editor.c"
#endif
#include EDITOR_SOURCE
#undef main
#include <assert.h>
#include <sys/time.h>

static unsigned checks;
static void interrupt_indexing(int sig) { (void)sig; interrupted=1; }
static uint32_t random_state=0x4c41594fu;
static uint32_t random_value(void)
{
    random_state^=random_state<<13;
    random_state^=random_state>>17;
    random_state^=random_state<<5;
    return random_state;
}
static size_t reference_start(size_t p)
{
    while(p && text.s[p-1]!='\n') p--;
    return p;
}
static size_t reference_end(size_t p)
{
    while(p<text.n && text.s[p]!='\n') p++;
    if(p<text.n && p && text.s[p-1]=='\r') p--;
    return p;
}
static size_t reference_next(size_t p)
{
    while(p<text.n && text.s[p]!='\n') p++;
    return p<text.n ? p+1 : text.n;
}
static size_t reference_line(size_t p)
{
    size_t i,line=1;
    for(i=0;i<p;i++) if(text.s[i]=='\n') line++;
    return line;
}
static size_t reference_column(size_t start,size_t p)
{
    size_t x=0;
    int cells;bool wide;char rep[32];
    while(start<p) {
        start+=representation(text.s,p,start,x,rep,&cells,&wide);
        x+=(size_t)cells;
    }
    return x;
}
static size_t reference_position(size_t start,size_t column)
{
    size_t end=reference_end(start),x=0,n;
    int cells;bool wide;char rep[32];
    while(start<end) {
        n=representation(text.s,end,start,x,rep,&cells,&wide);
        if(x+(size_t)cells>column) break;
        x+=(size_t)cells;start+=n;
    }
    return start;
}
static size_t reference_numbered(size_t number)
{
    size_t p=0,line=1;
    if(!number)return SIZE_MAX;
    if(number==1)return 0;
    for(p=0;p<text.n;p++)if(text.s[p]=='\n' && ++line==number)return p+1;
    return SIZE_MAX;
}
static void point_check(size_t p)
{
    size_t start=reference_start(p),column=(size_t)(random_value()%200);
    assert(line_start(p)==start);
    assert(line_end(p)==reference_end(p));
    assert(next_line(p)==reference_next(p));
    assert(column_at(start,p)==reference_column(start,p));
    assert(position_at(start,column)==reference_position(start,column));
    cursor=p;assert(current_line_number()==reference_line(p));
}
static void document_check(void)
{
    size_t i,total=reference_line(text.n);
    /* Fill checkpoints, then visit locations in a deliberately random order. */
    assert(line_count()==total);
    point_check(0);point_check(text.n);
    for(i=0;i<16;i++) {
        size_t line=(size_t)(random_value()%(total+2));
        point_check((size_t)(random_value()%(text.n+1)));
        assert(numbered_line(line)==reference_numbered(line));
    }
}
static void fresh(const char *data,size_t n)
{
    free_changes(history);history=current=history_tail=NULL;
    assert(copy_buffer(&text,data,n));
    assert(copy_buffer(&saved,data,n));
    cursor=top=left=goal=0;goal_set=group=false;
}
static void pass(const char *s){printf("ok %u - %s\n",++checks,s);}

int main(void)
{
    char data[32769];
    const unsigned char units[]={'a','z','\t','\r','\n',0x1b,0x7f,
        0xc3,0xa9,0xe7,0x95,0x8c,0xf0,0x9f,0x98,0x80,0xcc,0x81,0xff};
    size_t i,j;
    assert(setlocale(LC_CTYPE,"")!=NULL);
    fresh("",0);document_check();pass("empty document positions");
    for(i=0;i<sizeof data-1;i++)data[i]=(char)units[random_value()%sizeof units];
    data[sizeof data-1]=0;
    fresh(data,sizeof data-1);document_check();
    pass("mixed controls, CRLF and malformed UTF-8 positions");
    for(i=0;i<32;i++) {
        size_t at=4096+i-16;
        memset(data,'x',sizeof data-1);
        memcpy(data+at,"\xf0\x9f\x98\x80\r\n\t\xc3\xa9",9);
        fresh(data,sizeof data-1);document_check();
        for(j=at;j<at+12;j++)point_check(j);
    }
    pass("UTF-8 and CRLF around sparse checkpoint boundaries");
    for(i=0;i<sizeof data-1;i++)data[i]=(char)units[random_value()%sizeof units];
    fresh(data,sizeof data-1);
    for(i=0;i<256;i++) {
        char insertion[12];
        size_t at=(size_t)(random_value()%(text.n+1));
        size_t removed=(size_t)(random_value()%12),added=(size_t)(random_value()%12);
        if(removed>text.n-at)removed=text.n-at;
        if(!removed && !added)added=1;
        for(j=0;j<added;j++)insertion[j]=(char)units[random_value()%sizeof units];
        document_check();
        assert(edit(at,removed,insertion,added,false));document_check();
        assert(history_step(false));document_check();
        assert(history_step(true));document_check();
    }
    pass("256 random edits and undo/redo retain exact positions");
    memset(data,'x',sizeof data-1);
    for(i=0;i<sizeof data-16;i+=17)memcpy(data+i,"\t\xc3\xa9\xe7\x95\x8c\xf0\x9f\x98\x80",10);
    fresh(data,sizeof data-1);(void)layout_at(text.n);
    for(i=0;i<100;i++) {
        Buffer expected={0},actual={0};
        size_t from=random_value()%40000,width=1+random_value()%120;
        size_t p=position_at(0,from),x=column_at(0,p);
        visible(&expected,text.s,text.n,from,width);
        visible_from(&actual,text.s,text.n,from,width,p,x);
        assert(expected.n==actual.n);
        assert(!expected.n || !memcmp(expected.s,actual.s,expected.n));
        visible_match(&expected,text.s,text.n,from,width,p>2 ? p-2 : 0,
                      p+10<text.n ? p+10 : text.n,0,0);
        visible_match(&actual,text.s,text.n,from,width,p>2 ? p-2 : 0,
                      p+10<text.n ? p+10 : text.n,p,x);
        assert(expected.n==actual.n);
        assert(!expected.n || !memcmp(expected.s,actual.s,expected.n));
        free(expected.s);free(actual.s);
    }
    pass("100 clipped long-line renders and highlights match complete scans");
    {
        DocumentContext original_doc;
        document_capture(&original_doc);
        fresh("new\r\ncontext\n",13);document_check();
        document_restore(&original_doc);document_check();
        assert(text.n==sizeof data-1 && !memcmp(text.s,data,text.n));
    }
    pass("document context changes invalidate cached positions");
    fresh("one\ntwo",7);document_check();
    assert(copy_buffer(&text,"changed\nlength\n",15));document_check();
    pass("same-buffer replacement invalidates cached positions");
    {
        char path[]="/tmp/editor-layout.XXXXXXXX";
        struct stat st;
        int fd=mkstemp(path),fds[2];
        assert(fd>=0);
        assert(write_all(fd,"fresh\r\nfile\n",12)==0);assert(close(fd)==0);
        assert(read_file(path,&text,&st));assert(unlink(path)==0);
        document_check();
        assert(pipe(fds)==0);
        assert(write_all(fds[1],"stream\ninput\n",13)==0);assert(close(fds[1])==0);
        text.n=0;
        assert(read_stream(fds[0],&text));assert(close(fds[0])==0);
        document_check();
    }
    pass("file and stream reads invalidate cached positions");
    {
        char *large=malloc(LIMIT+1);
        assert(large);memset(large,'x',LIMIT);large[LIMIT]=0;
        large[4095]='\r';large[4096]='\n';
        fresh(large,LIMIT);free(large);
        document_check();
        assert(layout_count<=sizeof layout_points/sizeof *layout_points);
        assert(sizeof layout_points<=65568);
    }
    pass("8 MiB document and bounded checkpoint storage");
    {
        struct sigaction action,previous;
        struct itimerval timer={{0,0},{0,1000}},stop={{0,0},{0,0}};
        bool matched;
        size_t before=text.n-3;
        memcpy(text.s+before,"hit",3);layout_reset();
        memcpy(search_pattern,"hit",4);search_length=3;cursor=before;search_mark=17;
        memset(&action,0,sizeof action);sigemptyset(&action.sa_mask);
        action.sa_handler=interrupt_indexing;
        assert(sigaction(SIGALRM,&action,&previous)==0);
        assert(setitimer(ITIMER_REAL,&timer,NULL)==0);
        matched=find_match(true,true);
        assert(setitimer(ITIMER_REAL,&stop,NULL)==0);
        assert(sigaction(SIGALRM,&previous,NULL)==0);
        assert(interrupted && !matched && cursor==before && search_mark==17);
        interrupted=0;
    }
    pass("signal during cold cache build cancels search before cursor commit");
    free_changes(history);free(text.s);free(saved.s);reset_screen();
    printf("PASS: %u layout regression groups\n",checks);
    return 0;
}
