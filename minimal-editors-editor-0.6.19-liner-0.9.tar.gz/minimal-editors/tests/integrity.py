#!/usr/bin/env python3
"""Development-only integrity tests; no new editor runtime dependency."""
import os, random, resource, select, signal, stat, subprocess, sys, tempfile, time
from pathlib import Path
from terminal import Session

base=Path(__file__).resolve().parent.parent
editor=str(Path(sys.argv[1]).resolve())
liner=['/bin/sh',str(base/'liner.sh'),'--plain']
count=0

def check(name, ok):
    global count
    assert ok, name
    count+=1
    print('PASS '+name,flush=True)

def env(home):
    tmp=home/'tmp';tmp.mkdir(exist_ok=True)
    return dict(os.environ,HOME=str(home),XDG_CONFIG_HOME=str(home/'config'),
                XDG_STATE_HOME=str(home/'state'),TMPDIR=str(tmp),TERM='dumb',LC_ALL='C')

def recoveries(home):
    return sorted((home/'state'/'editor').glob('editor-recovery*'))+sorted((home/'tmp').glob('editor-recovery*'))

def run(cmd,home,data=b'',**kw):
    return subprocess.run(cmd,input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                          env=env(home),timeout=60,**kw)

def wait_text(proc, needle):
    data=b'';end=time.monotonic()+10
    while time.monotonic()<end:
        if select.select([proc.stdout],[],[],.1)[0]:
            part=os.read(proc.stdout.fileno(),65536)
            if not part: break
            data+=part
            if needle in data:return data
    raise AssertionError((needle,data,proc.poll()))

def send(proc,data):
    proc.stdin.write(data);proc.stdin.flush()

def wait_exit(s):
    end=time.monotonic()+6
    while not s.exited() and time.monotonic()<end:s.drain(.03)
    assert s.exited()

def compare_recovery(home,expected):
    copies=recoveries(home)
    return sorted(p.read_bytes() for p in copies)==sorted(expected) and all(stat.S_IMODE(p.stat().st_mode)==0o600 for p in copies)

with tempfile.TemporaryDirectory(prefix='integrity-') as td:
    root=Path(td)
    def home(name):
        h=root/name;h.mkdir();return h
    for sig in (signal.SIGTERM,signal.SIGHUP,signal.SIGQUIT,signal.SIGINT):
        h=home('plain-'+sig.name);p=h/'doc';p.write_bytes(b'original\r\n')
        proc=subprocess.Popen([editor,'--plain',str(p)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env(h))
        try:
            send(proc,b'change 1\naccepted\n');wait_text(proc,b'Changed.')
            proc.send_signal(sig);rc=proc.wait(timeout=6)
            check('plain '+sig.name+' recovers exact dirty bytes',rc==(-sig if sig==signal.SIGINT else 128+sig) and p.read_bytes()==b'original\r\n' and compare_recovery(h,[b'accepted\r\n']))
        finally:
            if proc.poll() is None:proc.kill();proc.wait()
            proc.stdin.close();proc.stdout.close();proc.stderr.close()
    for sig in (signal.SIGTERM,signal.SIGHUP,signal.SIGQUIT,signal.SIGINT):
        h=home('screen-'+sig.name);p=h/'doc';p.write_bytes(b'original\r\n')
        s=Session(editor,h,[p])
        try:
            s.send(b'new ');os.kill(s.pid,sig);wait_exit(s)
            check('screen '+sig.name+' recovers exact dirty bytes',p.read_bytes()==b'original\r\n' and compare_recovery(h,[b'new original\r\n']))
            if sig==signal.SIGINT:s.finish(expected_signal=sig)
            else:s.finish(expected=128+sig)
        except BaseException:s.kill();raise
    h=home('disconnect');p=h/'doc';p.write_bytes(b'base\n');s=Session(editor,h,[p])
    s.send(b'disconnected ');os.close(s.fd)
    end=time.monotonic()+6
    try:
        while not s.exited() and time.monotonic()<end:time.sleep(.025)
        check('actual PTY disconnect preserves accepted dirty bytes',s.exited() and p.read_bytes()==b'base\n' and compare_recovery(h,[b'disconnected base\n']))
    finally:
        if not s.exited():os.kill(s.pid,signal.SIGKILL);os.waitpid(s.pid,0)
    h=home('clipboard');p=h/'doc';p.write_bytes(b'original\n');s=Session(editor,h,[p])
    try:
        s.send(b'P');s.command('copy');s.command('clipboard');s.send(b'C')
        os.kill(s.pid,signal.SIGTERM);wait_exit(s)
        copies=recoveries(h)
        check('clipboard and parked parent independently recovered',len(copies)==2 and compare_recovery(h,[b'Poriginal\n',b'CPoriginal\n']) and p.read_bytes()==b'original\n')
        s.finish(expected=143)
    except BaseException:s.kill();raise
    h=home('discard');r=run([editor,'--plain'],h,b'insert 1\nprivate draft\nquit!\n')
    check('deliberate discard creates no recovery',r.returncode==0 and not recoveries(h))
    h=home('fallback');(h/'state').write_text('not a directory')
    r=run([editor,'--plain'],h,b'insert 1\nfallback\n')
    check('unavailable state directory falls back to TMPDIR',r.returncode==1 and compare_recovery(h,[b'fallback\n']))
    listed=run([editor,'--recoveries'],h).stdout
    check('fallback recovery discoverable without a terminal',os.fsencode(recoveries(h)[0]) in listed)
    h=home('list');r=run([editor,'--plain'],h,b'insert 1\nsecret\n');d=h/'state'/'editor';rec=recoveries(h)[0]
    (d/'editor-recovery.symlink').symlink_to(rec);(d/'editor-recovery.public').write_bytes(b'bad');(d/'editor-recovery.public').chmod(0o644)
    r=run([editor,'--recoveries'],h)
    check('recovery list excludes symlinks and nonprivate files; does not print content',os.fsencode(rec) in r.stdout and b'symlink' not in r.stdout and b'public' not in r.stdout and b'secret' not in r.stdout)
    h=home('kill');p=h/'doc';p.write_bytes(b'base\n')
    proc=subprocess.Popen(liner+[str(p)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env(h))
    try:
        send(proc,b'change 1\none\nchange 1\ntwo\nundo\n');wait_text(proc,b'Undone.')
        proc.kill();proc.wait(timeout=5);w=next((h/'tmp').glob('liner.*'))
        selected=(w/'CURRENT').read_text().strip()
        check('liner SIGKILL after undo selects correct snapshot',selected=='1' and (w/selected).read_bytes()==b'one\n' and (w/'2').read_bytes()==b'two\n' and p.read_bytes()==b'base\n')
    finally:
        if proc.poll() is None:proc.kill();proc.wait()
        proc.stdin.close();proc.stdout.close();proc.stderr.close()
    h=home('liner-signal');p=h/'doc';p.write_bytes(b'base\n');proc=subprocess.Popen(liner+[str(p)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env(h))
    try:
        send(proc,b'change 1\naccepted\n');wait_text(proc,b'Changed.')
        proc.send_signal(signal.SIGTERM);rc=proc.wait(timeout=6);err=proc.stderr.read();w=next((h/'tmp').glob('liner.*'));sel=(w/'CURRENT').read_text().strip()
        check('liner TERM reports committed snapshot',rc==143 and (w/sel).read_bytes()==b'accepted\n' and os.fsencode(w/sel) in err)
    finally:
        if proc.poll() is None:proc.kill();proc.wait()
        proc.stdin.close();proc.stdout.close();proc.stderr.close()
    h=home('marker-failure');p=h/'doc';p.write_bytes(b'base\n');bin=h/'bin';bin.mkdir();wrapper=bin/'mv'
    wrapper.write_text('#!/bin/sh\ncase "$2" in */CURRENT.next) if [ "$(cat "$2")" = 2 ]; then exit 1; fi;; esac\nexec /bin/mv "$@"\n');wrapper.chmod(0o755)
    e=env(h);e['PATH']=str(bin)+':'+e['PATH']
    r=subprocess.run(liner+[str(p)],input=b'change 1\none\nchange 1\ntwo\nredo\nwrite\nquit\n',stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=e,timeout=15)
    check('liner failed CURRENT publication retains prior selected bytes',r.returncode==0 and p.read_bytes()==b'one\n' and b'previous selection retained' in r.stderr and b'History cleanup failed' in r.stderr)
    h=home('liner-save-failure');p=h/'doc';p.write_bytes(b'base\n');out=h/'alternative';bin=h/'bin';bin.mkdir();wrapper=bin/'mv'
    wrapper.write_text('#!/bin/sh\ncase "$3" in */doc) exit 1;; esac\nexec /bin/mv "$@"\n');wrapper.chmod(0o755)
    e=env(h);e['PATH']=str(bin)+':'+e['PATH']
    r=subprocess.run(liner+[str(p)],input=b'change 1\nnew\nwrite\nwrite '+os.fsencode(out)+b'\nquit\n',stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=e,timeout=15)
    check('liner failed save publication preserves original and supports save-as',r.returncode==0 and p.read_bytes()==b'base\n' and out.read_bytes()==b'new\n' and b'Write failed' in r.stderr)
    h=home('liner-setid');p=h/'doc';p.write_bytes(b'base\n');p.chmod(0o6755)
    r=run(liner+[str(p)],h,b'change 1\nnew\nwrite\nquit\n')
    check('liner replacement strips set-ID bits without changing ordinary mode',r.returncode==0 and p.read_bytes()==b'new\n' and stat.S_IMODE(p.stat().st_mode)==0o755)
    h=home('editor-fsize');p=h/'doc';p.write_bytes(b'base\n');out=h/'alternative'
    def small_file():resource.setrlimit(resource.RLIMIT_FSIZE,(128,128))
    r=run([editor,'--plain',str(p)],h,b'change 1\n'+b'X'*512+b'\nwrite\nundo\nchange 1\nnew\nwrite '+os.fsencode(out)+b'\nquit\n',preexec_fn=small_file)
    check('editor RLIMIT_FSIZE save failure retains original and supports retry',r.returncode==0 and p.read_bytes()==b'base\n' and out.read_bytes()==b'new\n' and b'Write failed' in r.stdout)
    h=home('liner-fsize');p=h/'doc';p.write_bytes(b'base\n')
    r=run(liner+[str(p)],h,b'change 1\none\nchange 1\n'+b'X'*512+b'\nwrite\nquit\n',preexec_fn=small_file)
    check('liner file-size limit rejects oversized draft without losing accepted edit',r.returncode==0 and p.read_bytes()==b'one\n')
    h=home('editor-memory');p=h/'doc';p.write_bytes(b'base\n')
    def small_memory():resource.setrlimit(resource.RLIMIT_AS,(16*1024*1024,16*1024*1024))
    r=run([editor,'--plain',str(p)],h,b'change 1\n'+b'X'*(7*1024*1024)+b'\nchange 1\nretry\nwrite\nquit\n',preexec_fn=small_memory)
    check('editor constrained address space rejects large edit and retains usable session',r.returncode==0 and p.read_bytes()==b'retry\n' and (b'Not enough memory' in r.stdout or b'Input refused' in r.stdout or b'out of memory' in r.stdout.lower()))
    # A deterministic independent line model with insert/change/delete and
    # branching undo/redo. Compare exact files, including empty documents.
    rng=random.Random(20261124);ops=0
    for cycle in range(5):
        h=home('random-'+str(cycle));initial=[b'alpha',b'beta',b'gamma'];states=[initial];pos=0;cmds=[]
        for i in range(100):
            current=states[pos];choices=['insert']+(['change','delete'] if current else [])+(['undo'] if pos else [])+(['redo'] if pos+1<len(states) else [])
            op=rng.choice(choices);new=current[:];value=('line-%d-%d'%(cycle,i)).encode()
            if op=='undo':pos-=1;cmds.append(b'undo\n')
            elif op=='redo':pos+=1;cmds.append(b'redo\n')
            else:
                if op=='insert':j=rng.randrange(len(new)+1);new.insert(j,value);cmds.append(b'insert %d\n'% (j+1)+value+b'\n')
                elif op=='change':j=rng.randrange(len(new));new[j]=value;cmds.append(b'change %d\n'%(j+1)+value+b'\n')
                else:j=rng.randrange(len(new));k=rng.randrange(j,len(new));del new[j:k+1];cmds.append(b'delete %d %d\n'%(j+1,k+1))
                states=states[:pos+1]+[new];pos+=1
        expected=b''.join(x+b'\n' for x in states[pos]);data=b''.join(cmds)+b'write\nquit\n'
        for name,command in [('editor',[editor,'--plain']),('liner',liner)]:
            p=h/name;p.write_bytes(b''.join(x+b'\n' for x in initial));r=run(command+[str(p)],h,data)
            check(name+' randomized exact-byte model cycle '+str(cycle+1),r.returncode==0 and p.read_bytes()==expected and not r.stderr)
            ops+=100
    print('Randomized operations across both implementations:',ops,flush=True)
print('PASS: %d integrity checks.'%count,flush=True)
