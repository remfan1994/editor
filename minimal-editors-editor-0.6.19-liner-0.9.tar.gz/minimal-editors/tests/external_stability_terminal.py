#!/usr/bin/env python3
"""External process lifetime regressions; isolated homes and disposable files."""
import os
from pathlib import Path
import signal
import sys
import tempfile
import time
from terminal import Session, set_config


ORIGINAL = b'first\nsecond\n'


def scenarios(binary, root, only=None):
    count = 0

    def cleanup_child(home):
        try:
            pid = int((home / 'child.pid').read_text())
            if pid > 1:
                os.killpg(pid, signal.SIGKILL)
        except (FileNotFoundError, ProcessLookupError):
            pass

    def run(name, fn, cancel=True):
        nonlocal count
        if only is not None and name != only:
            return
        home = root / name
        home.mkdir()
        sample = home / 'document'
        sample.write_bytes(ORIGINAL)
        if cancel:
            set_config(home, b'signal_controls=on\n')
        session = Session(binary, home, [sample])
        try:
            expected_signal = fn(session, home, sample)
            session.finish(expected_signal=expected_signal)
        except BaseException:
            print('FAIL', name, bytes(session.data[-1600:]), flush=True)
            cleanup_child(home)
            session.kill()
            raise
        count += 1
        print('PASS', name, flush=True)

    def cancel(s, home, doc, command):
        mark = len(s.data)
        s.command(command)
        s.wait_file(home / 'started', b'', timeout=5)
        os.kill(s.pid, signal.SIGINT)
        s.wait_output(b'Command stopped; output discarded', timeout=3, start=mark)
        s.send(b'q\r')
        s.command('write')
        s.wait_file(doc, ORIGINAL)
        s.command('shell printf OK')
        s.wait_output(b'Inserted', start=mark)
        s.command('write')
        s.wait_file(doc, b'OK' + ORIGINAL)

    def closed(s, home, doc):
        cancel(s, home, doc,
               'shell echo $$ > child.pid; exec 1>&- 2>&-; '
               'touch started; sleep 30')
    run('cancel-after-both-pipes-close', closed)

    def filter_closed(s, home, doc):
        cancel(s, home, doc,
               'filter echo $$ > child.pid; printf PARTIAL; exec 1>&- 2>&-; '
               'touch started; sleep 30')
    run('cancel-filter-after-pipes-close-is-atomic', filter_closed)

    def native(s, home, doc):
        s.command('shell echo $$ > child.pid; exec 1>&- 2>&-; '
                  'touch started; sleep 30')
        s.wait_file(home / 'started', b'', timeout=5)
        os.kill(s.pid, signal.SIGINT)
        until = time.monotonic() + 3
        while not s.exited() and time.monotonic() < until:
            s.drain(.025)
        assert s.exited(), 'native interrupt blocked after process pipes closed'
        assert doc.read_bytes() == ORIGINAL
        # The runner checks terminal restoration as well as the exit status.
        return signal.SIGINT
    run('native-interrupt-after-pipes-close', native, cancel=False)

    def stderr(s, home, doc):
        cancel(s, home, doc,
               'shell echo $$ > child.pid; touch started; '
               'while :; do printf diagnostic >&2; done')
    run('cancel-continuous-stderr-and-reuse-editor', stderr)

    def exit_status(s, home, doc):
        s.command('filter printf PARTIAL; exec 1>&- 2>&-; sleep 1; exit 7')
        s.wait_output(b'Shell failed (status 7)', timeout=4)
        s.command('write')
        s.wait_file(doc, ORIGINAL)
    run('closed-pipes-still-check-final-exit-status', exit_status)

    def empty(s, home, doc):
        s.command('filter cat')
        s.wait_output(b'Filter output unchanged')
        s.command('filter :')
        s.wait_output(b'Filtered 0 bytes')
        s.command('write')
        s.wait_file(doc, b'')
        s.command('undo')
        s.command('write')
        s.wait_file(doc, ORIGINAL)
    run('empty-filter-output-remains-one-undo', empty)

    def file_limit_signal(s, home, doc):
        s.command('shell kill -XFSZ $$; printf MUST-NOT-INSERT')
        s.wait_output(b'Shell failed (status -1)')
        s.command('write')
        s.wait_file(doc, ORIGINAL)
    if hasattr(signal, 'SIGXFSZ'):
        run('child-restores-default-file-limit-signal', file_limit_signal)

    name = 'suspend-after-pipes-close-and-resume'
    if only is None or only == name:
        from signals_terminal import ShellJob
        home = root / name
        home.mkdir()
        doc = home / 'document'
        doc.write_bytes(ORIGINAL)
        job = ShellJob(binary, home, doc)
        try:
            job.send(b'\x1bshell echo $$ > child.pid; exec 1>&- 2>&-; '
                     b'touch started; sleep 30\r')
            until = time.monotonic() + 4
            while not (home / 'started').exists() and time.monotonic() < until:
                job.drain(.025)
            assert (home / 'started').exists(), 'external command did not start'
            job.stop_resume()
            job.send(b'\x1bshell printf OK\r')
            job.wait(b'Inserted')
            job.send(b'\x1bwrite\r')
            job.wait(b'Written.')
            assert doc.read_bytes() == b'OK' + ORIGINAL
            job.finish()
        except BaseException:
            cleanup_child(home)
            job.kill()
            raise
        count += 1
        print('PASS', name, flush=True)

    print(f'PASS {count} external-process stability scenarios', flush=True)


if __name__ == '__main__':
    with tempfile.TemporaryDirectory(prefix='editor-external-stability-') as root:
        scenarios(Path(sys.argv[1]).resolve(), Path(root),
                  sys.argv[2] if len(sys.argv) > 2 else None)
