#!/usr/bin/env python3
"""Terminal-native signal controls and ordinary-quit notice regressions.

The editor has no Python dependency. These tests require a C build and, for
real foreground-job suspension, bash (a test tool, never an editor dependency).
"""
import argparse
import errno
import os
from pathlib import Path
import pty
import select
import shlex
import shutil
import signal
import tempfile
import termios
import time
from terminal import Session, set_config

NOTICE = b'BLOODGUILT CURSE'
WARNING = b"Cows aren't killers, and beef is the bloodshed of the innocent.  www.bloodguiltcurse.net has the Bible study"


def wait_exit(s):
    end = time.monotonic() + 4
    while not s.exited() and time.monotonic() < end:
        s.drain(.025)
    assert s.exited(), 'signal/quit did not exit'
    s.drain(.01)


def native_interrupt(binary, root):
    contexts = ['document', 'command', 'filename', 'find', 'menu', 'manual',
                'reverse', 'confirm', 'clipboard', 'paste']
    for name in contexts:
        home = root/name
        home.mkdir()
        path = home/'document'
        path.write_bytes(b'original\n')
        s = Session(binary, home, [path])
        try:
            assert termios.tcgetattr(s.fd)[3] & termios.ISIG
            s.send(b'dirty ')
            if name == 'command':
                s.send(b'\x1bunfinished', settle=.12)
            elif name == 'filename':
                s.command('write /no/such/directory/file')
                # Read with no name opens a filename prompt only when clean.
                s.command('undo');s.command('read');s.wait_output(b'Filename>')
            elif name == 'find':
                s.command('find');s.wait_output(b'Find>')
            elif name == 'menu':
                s.command('toggle-esc');s.send(b'\x1b')
            elif name == 'manual':
                s.command('manual')
            elif name == 'reverse':
                s.command('reverse')
            elif name == 'confirm':
                s.send(b'\x1b',settle=.12);s.send(b'\x1b',settle=.12)
                s.wait_output(b'Really quit?')
            elif name == 'clipboard':
                s.command('clipboard');s.send(b'clipboard draft')
            elif name == 'paste':
                s.send(b'\x1b[200~unfinished paste',settle=.12)
            mark=len(s.data)
            s.send(b'\x03')
            wait_exit(s)
            assert path.read_bytes()==b'original\n'
            assert NOTICE not in s.data[mark:], 'signal displayed normal-quit notice'
            s.finish(expected_signal=signal.SIGINT)
        except BaseException:
            s.kill();raise


def opt_in_and_toggle(binary, home):
    set_config(home,b'signal_controls=on\n')
    path=home/'document';path.write_bytes(b'old\n')
    s=Session(binary,home,[path])
    try:
        s.send(b'new ');s.command('read');s.wait_output(b'Filename>')
        s.send(b'\x03',settle=.12)
        assert not s.exited()
        s.wait_output(b'Command>')
        s.send(b'write\r');s.wait_output(b'Written.')
        assert path.read_bytes()==b'new old\n'
        s.command('toggle-signals')
        assert termios.tcgetattr(s.fd)[3] & termios.ISIG
        s.send(b'\x03');wait_exit(s);s.finish(expected_signal=signal.SIGINT)
    except BaseException:s.kill();raise
    set_config(home,b'signal_controls=off\n')
    s=Session(binary,home,[path])
    try:
        s.command('toggle-esc');s.send(b'\x1b');s.send(b'7\r7\r')
        s.wait_output(b'Signals: Off (exit)')
        s.send(b'4\r');s.wait_output(b'Signals: On (cancel)')
        s.send(b'\x03',settle=.15)
        assert not s.exited()
        # Signal handling opens Command> regardless of preferred Esc interface.
        s.send(b'toggle-esc\r');s.command('toggle-signals')
        s.send(b'\x03');wait_exit(s);s.finish(expected_signal=signal.SIGINT)
    except BaseException:s.kill();raise


def inherited_controls(binary,home):
    path=home/'document';path.write_bytes(b'old\n')
    def remap(attr):
        attr[3] |= termios.ISIG
        attr[6][termios.VINTR]=b'\x18'
        attr[6][termios.VSUSP]=b'\x19'
    d=home/'config'/'editor';d.mkdir(parents=True);d.chmod(0o700)
    (d/'keys.conf').write_text('bind Ctrl+C quit!\nbind Ctrl+Z suspend\n')
    s=Session(binary,home,[path],terminal_setup=remap)
    try:
        a=termios.tcgetattr(s.fd)
        assert a[3]&termios.ISIG
        assert a[6][termios.VINTR]==b'\x18' and a[6][termios.VSUSP]==b'\x19'
        s.send(b'\x03\x1a',settle=.15);assert not s.exited()
        s.command('bind Ctrl+C quit!');s.wait_output(b'not supported')
        s.command('bind Ctrl+Z suspend');s.wait_output(b'not supported')
        s.send(b'\x18');wait_exit(s)
        a=termios.tcgetattr(s.fd)
        assert a[6][termios.VINTR]==b'\x18' and a[6][termios.VSUSP]==b'\x19'
        s.finish(expected_signal=signal.SIGINT)
    except BaseException:s.kill();raise

    def no_signals(attr):attr[3]&=~termios.ISIG
    s=Session(binary,home,terminal_setup=no_signals)
    try:
        assert not termios.tcgetattr(s.fd)[3]&termios.ISIG
        s.command('write');s.wait_output(b'Filename>')
        s.send(b'\x03\x1a');assert not s.exited()
        s.send(b'newfile\r');s.wait_output(b'Written.')
        assert (home/'newfile').read_bytes()==b''
        s.command('quit!');wait_exit(s)
        assert not termios.tcgetattr(s.fd)[3]&termios.ISIG
        s.finish()
    except BaseException:s.kill();raise


def quit_notice(binary,root):
    for verb in ['quit','q','exit','quit!','confirmed','menu-quit','menu-discard']:
        home=root/verb;home.mkdir()
        path=home/'document';path.write_bytes(b'original\n')
        s=Session(binary,home,[path],rows=3,cols=12)
        try:
            mark=len(s.data)
            normal=verb in ('quit','q','exit','menu-quit')
            if verb=='confirmed':
                s.send(b'\x1b',settle=.12);s.send(b'\x1b',settle=.12);s.send(b'y')
            elif verb=='menu-quit':
                s.command('toggle-esc');s.send(b'\x1b');s.send(b'9\r1\r')
            elif verb=='menu-discard':
                s.send(b'dirty ');s.command('toggle-esc');s.send(b'\x1b');s.send(b'9\r2\r\r')
            else:s.command(verb)
            wait_exit(s)
            output=bytes(s.data[mark:])
            assert (NOTICE in output)==normal, (verb,output)
            if normal:
                assert WARNING in output
                assert b'design by remfan1994' in output and b'published by ThatIAm.vip' in output
            assert path.read_bytes()==b'original\n'
            s.finish()
        except BaseException:s.kill();raise


def pipe_notice(binary,home):
    original=b'pipe bytes\r\nlast line'
    s=Session(binary,home,['-'],stdin_data=original,stdout_pipe=True)
    try:
        s.command('write -');s.wait_output(b'Text sent to stdout')
        mark=len(s.data);s.command('quit');wait_exit(s)
        assert NOTICE in s.data[mark:]
        data=b''
        while True:
            chunk=os.read(s.pipe_out,8192)
            if not chunk:break
            data+=chunk
        assert data==original,repr(data)
        s.finish()
    except BaseException:s.kill();raise


def protected_paste(binary,home):
    set_config(home,b'signal_controls=on\n')
    path=home/'document';path.write_bytes(b'original\n')
    s=Session(binary,home,[path])
    try:
        s.send(b'\x1b[200~partial paste',settle=.12)
        s.send(b'\x03',settle=.12)
        s.send(b'quit!\r\x1b[201~',settle=.12)
        assert not s.exited(), 'cancelled paste escaped into command input'
        assert path.read_bytes()==b'original\n'
        s.send(b'\x1b');s.command('write')
        assert path.read_bytes()==b'original\n'
        s.finish()
    except BaseException:s.kill();raise


def blocked_pipe_interrupt(binary,home):
    s=Session(binary,home,['-'],stdin_data=b'x'*524288,stdout_pipe=True)
    try:
        s.command('write -')
        mark=len(s.data);s.send(b'\x03');wait_exit(s)
        assert NOTICE not in s.data[mark:]
        s.finish(expected_signal=signal.SIGINT)
    except BaseException:s.kill();raise


class ShellJob:
    """Use a real job-control shell so SIGTSTP is not orphan-group-ignored."""
    def __init__(self,binary,home,path,remapped=False):
        shell=shutil.which('bash')
        if not shell:raise RuntimeError('bash required for foreground-job signal test')
        self.data=bytearray();self.status=None;self.editor_pid=None
        pid,master=pty.fork()
        if not pid:
            env=dict(os.environ,HOME=str(home),XDG_CONFIG_HOME=str(home/'config'),
                     XDG_STATE_HOME=str(home/'state'),TERM='xterm',LC_ALL='C.UTF-8',
                     PS1='TEST-SHELL> ',PROMPT_COMMAND='',BASH_ENV='/dev/null')
            os.chdir(home)
            os.execve(shell,[shell,'--noprofile','--norc','--noediting','-i'],env)
        self.pid,self.fd=pid,master
        os.set_blocking(master,False)
        self.wait(b'TEST-SHELL> ')
        prefix="stty intr '^X' susp '^Y'; " if remapped else ''
        mark=len(self.data)
        self.send((prefix+shlex.quote(str(binary))+' '+shlex.quote(str(path))+'\n').encode())
        self.wait(b'\x1b[?2004h',mark)
        self.editor_pid=os.tcgetpgrp(master)
        assert self.editor_pid!=self.pid
    def drain(self,seconds=.06):
        end=time.monotonic()+seconds
        while time.monotonic()<end:
            ready,_,_=select.select([self.fd],[],[],max(0,end-time.monotonic()))
            if not ready:break
            try:data=os.read(self.fd,65536)
            except OSError as e:
                if e.errno in (errno.EIO,errno.EAGAIN):break
                raise
            if not data:break
            self.data.extend(data)
    def wait(self,needle,start=0,timeout=4):
        end=time.monotonic()+timeout
        while needle not in self.data[start:] and time.monotonic()<end:self.drain(.025)
        assert needle in self.data[start:], (needle,bytes(self.data[-1200:]))
    def send(self,data):
        os.write(self.fd,data);self.drain(.1)
    def stop_resume(self,stop_byte=b'\x1a'):
        mark=len(self.data);self.send(stop_byte);self.wait(b'TEST-SHELL> ',mark)
        assert os.tcgetpgrp(self.fd)==self.pid,'foreground did not return to shell'
        attr=termios.tcgetattr(self.fd)
        assert attr[3]&termios.ICANON and attr[3]&termios.ECHO,'stopped editor left raw tty'
        # This is a shell job, not a terminated child; foregrounding must work.
        mark=len(self.data);self.send(b'fg\n');self.wait(b'\x1b[?1049h',mark)
        assert os.tcgetpgrp(self.fd)==self.editor_pid
        attr=termios.tcgetattr(self.fd)
        assert attr[3]&termios.ISIG and not attr[3]&termios.ICANON
    def finish(self,interrupt=b'\x03'):
        mark=len(self.data);self.send(interrupt);self.wait(b'TEST-SHELL> ',mark)
        assert NOTICE not in self.data[mark:]
        mark=len(self.data);self.send(b'printf "JOB-STATUS:%s\\n" "$?"\n')
        self.wait(b'JOB-STATUS:130',mark)
        self.send(b'exit\n')
        _,self.status=os.waitpid(self.pid,0)
        output=bytes(self.data)
        assert b'ERROR: AddressSanitizer' not in output and b'runtime error:' not in output
        assert b'LeakSanitizer' not in output
        os.close(self.fd)
    def kill(self):
        if self.editor_pid:
            try:os.killpg(self.editor_pid,signal.SIGKILL)
            except ProcessLookupError:pass
        if self.status is None:
            try:os.kill(self.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            os.waitpid(self.pid,0)
        os.close(self.fd)


def suspend_resume(binary,root):
    for remapped in (False,True):
        home=root/('remapped' if remapped else 'usual');home.mkdir()
        path=home/'document';path.write_bytes(b'old\n')
        s=ShellJob(binary,home,path,remapped=remapped)
        try:
            s.send(b'new ')
            for _ in range(4):s.stop_resume(b'\x19' if remapped else b'\x1a')
            s.send(b'\x1bwrite\r');s.wait(b'Written.');assert path.read_bytes()==b'new old\n'
            # With protection OFF, suspension preserves a pending filename.
            s.send(b'\x1bread\r');s.wait(b'Filename>')
            s.send(b'doc');s.stop_resume(b'\x19' if remapped else b'\x1a')
            s.send(b'ument\r');s.wait(b'File opened.')
            assert path.read_bytes()==b'new old\n'
            s.finish(b'\x18' if remapped else b'\x03')
        except BaseException:s.kill();raise


def protected_stop(binary,home):
    set_config(home,b'signal_controls=on\n')
    path=home/'document';path.write_bytes(b'old\n')
    s=ShellJob(binary,home,path)
    try:
        s.send(b'\x1b');s.send(b'\x1b');s.wait(b'Really quit?')
        s.stop_resume()
        # The opt-in behavior cancels the confirmation before suspension.
        s.send(b'Y');s.send(b'\x1bwrite\r');s.wait(b'Written.')
        assert path.read_bytes()==b'Yold\n'
        s.send(b'\x1btoggle-signals\r');s.finish()
    except BaseException:s.kill();raise


def main():
    p=argparse.ArgumentParser();p.add_argument('binary',type=Path)
    p.add_argument('case',nargs='?',default='all')
    args=p.parse_args();binary=args.binary.resolve()
    cases={'native-interrupt':native_interrupt,'opt-in-toggle':opt_in_and_toggle,
           'inherited-controls':inherited_controls,'quit-notice':quit_notice,
           'pipe-notice':pipe_notice,'protected-paste':protected_paste,
           'blocked-pipe-interrupt':blocked_pipe_interrupt,'suspend-resume':suspend_resume,
           'protected-stop':protected_stop}
    count=0
    with tempfile.TemporaryDirectory(prefix='editor-signals-') as root:
        for name,fn in cases.items():
            if args.case not in ('all',name):continue
            home=Path(root)/name;home.mkdir()
            fn(binary,home);count+=1;print('PASS',name,flush=True)
    print(f'PASS: {count} signal/exit terminal groups',flush=True)
if __name__=='__main__':main()
