#!/usr/bin/env python3
"""Saved signal control: commands, menu, restart, failure and actual Ctrl+C."""
import argparse
from pathlib import Path
import signal
import tempfile
from terminal import Session
from startup_terminal import config
from signals_terminal import wait_exit


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('binary')
    binary=str(Path(parser.parse_args().binary).resolve())
    count=0
    with tempfile.TemporaryDirectory(prefix='editor-saved-signals-') as tmp:
        root=Path(tmp)
        def run(name,fn):
            nonlocal count
            home=root/name;home.mkdir();fn(home)
            count+=1;print(f'ok {count} - {name}',flush=True)

        def command_restart(home):
            cfg=home/'config/editor/config';doc=home/'doc';doc.write_bytes(b'base\n')
            s=Session(binary,home,[doc])
            try:
                s.command('settings show');s.wait_output(b'Current signal handling: OFF');assert not cfg.exists();s.send(b'q\r')
                s.command('toggle-signals');s.wait_file(cfg,b'signal_controls=on\n');s.finish()
            except BaseException:s.kill();raise
            s=Session(binary,home,[doc])
            try:
                s.send(b'X');s.send(b'\x03');s.wait_output(b'Command>');assert not s.exited()
                s.send(b'write\r');s.wait_file(doc,b'Xbase\n')
                s.command('toggle-signals');s.wait_file(cfg,b'signal_controls=off\n');s.finish()
            except BaseException:s.kill();raise
            s=Session(binary,home,[doc])
            try:
                s.send(b'unsaved');s.send(b'\x03');wait_exit(s)
                assert doc.read_bytes()==b'Xbase\n';s.finish(expected_signal=signal.SIGINT)
            except BaseException:s.kill();raise
        run('command-saves-on-and-off-and-restarts-change-real-interrupt-behavior',command_restart)

        def menu_restart(home):
            cfg=config(home,b'startup=edit\nesc=cli\nsignal_controls=off\n')
            s=Session(binary,home,[])
            try:
                s.command('settings');s.wait_output(b'Signals: Off (exit)');s.send(b'4\r')
                s.wait_file(cfg,b'startup=edit\nesc=cli\nsignal_controls=on\n');s.wait_output(b'Signals: On (cancel)')
                s.send(b'hh8\rquit!\r');s.finish()
            except BaseException:s.kill();raise
            s=Session(binary,home,[])
            try:
                s.command('settings');s.wait_output(b'Signals: On (cancel)');s.send(b'4\r')
                s.wait_file(cfg,b'startup=edit\nesc=cli\nsignal_controls=off\n')
                s.send(b'hh8\rquit!\r');s.finish()
            except BaseException:s.kill();raise
        run('settings-menu-saves-and-displays-interrupt-choice-on-restart',menu_restart)

        def preserves(home):
            old=b'# custom\r\nstartup=edit\r\nesc=cli\r\nsignal_controls = off # here\r\nunknown=value\r\nsignal_controls=off'
            new=old.replace(b'= off #',b'= on #').replace(b'signal_controls=off',b'signal_controls=on')
            cfg=config(home,old);s=Session(binary,home,[],cols=180)
            try:
                s.command('toggle-signals');s.wait_file(cfg,new)
                before=cfg.stat();s.command('settings show');s.wait_output(b'Saved signal handling: ON');s.send(b'q\r')
                after=cfg.stat();assert before.st_ino==after.st_ino and before.st_mtime_ns==after.st_mtime_ns
                s.command('settings show');s.wait_output(str(cfg).encode());s.wait_output(b'Saved signal handling: ON')
                s.send(b'q\r');s.finish()
            except BaseException:s.kill();raise
        run('comments-crlf-other-values-and-read-only-report-are-preserved',preserves)

        def failure(home):
            cfg=config(home,b'signal_controls=on\n');cfg.chmod(0o444)
            s=Session(binary,home,[])
            try:
                s.command('toggle-signals');s.wait_output(b'Signal handling setting NOT saved')
                assert cfg.read_bytes()==b'signal_controls=on\n'
                s.send(b'\x03');s.wait_output(b'Command>');assert not s.exited()
                cfg.chmod(0o644);s.send(b'toggle-signals\r');s.wait_file(cfg,b'signal_controls=off\n')
                s.send(b'\x03');wait_exit(s);s.finish(expected_signal=signal.SIGINT)
            except BaseException:s.kill();raise
        run('failed-save-keeps-enabled-interrupt-cancellation-until-retry-succeeds',failure)

        def narrow(home):
            cfg=config(home,b'signal_controls=off\n');s=Session(binary,home,[],rows=3,cols=12)
            try:
                s.command('settings');s.send(b'4\r');s.wait_file(cfg,b'signal_controls=on\n');s.wait_output(b'Sig:On')
                s.send(b'4\r');s.wait_file(cfg,b'signal_controls=off\n');s.wait_output(b'Sig:Off')
                s.send(b'hh8\rquit!\r');s.finish()
            except BaseException:s.kill();raise
        run('saved-interrupt-toggle-fits-12-by-3-and-retains-menu-focus',narrow)

        def external(home):
            cfg=config(home,b'startup=edit\nesc=cli\nsignal_controls=off\n')
            doc=home/'doc';doc.write_bytes(b'base\n');s=Session(binary,home,[doc])
            try:
                cfg.write_bytes(b'# other session\nstartup=movement\nesc=menu\nsignal_controls=off\n')
                s.command('toggle-signals');s.wait_file(cfg,b'# other session\nstartup=movement\nesc=menu\nsignal_controls=on\n')
                s.send(b'X');s.command('write');s.wait_file(doc,b'Xbase\n');s.finish()
            except BaseException:s.kill();raise
            s=Session(binary,home,[doc])
            try:
                s.send(b'!');s.send(b'\x1b8\rsettings show\r');s.wait_output(b'Current signal handling: ON');s.send(b'q\r')
                s.send(b'\x1b8\rwrite\r');s.wait_file(doc,b'Xbase\n')
                s.send(b'\x1b8\rquit!\r');s.finish()
            except BaseException:s.kill();raise
        run('signal-save-keeps-other-session-config-and-does-not-switch-live-edit-or-esc',external)

        def clipboard(home):
            cfg=config(home,b'signal_controls=off\n');doc=home/'doc';doc.write_bytes(b'base\n')
            s=Session(binary,home,[doc])
            try:
                s.send(b'P');s.command('copy');s.command('clipboard');s.send(b'C')
                s.command('toggle-signals');s.wait_file(cfg,b'signal_controls=on\n')
                s.command('clipboard');s.command('write');s.wait_file(doc,b'Pbase\n')
                s.command('undo');s.command('write');s.wait_file(doc,b'base\n')
                assert (home/'state/editor/clipboard.txt').read_bytes()==b'CPbase\n';s.finish()
            except BaseException:s.kill();raise
        run('saving-signal-setting-keeps-clipboard-and-parent-history',clipboard)
    print(f'PASS: {count} saved-signal terminal groups.',flush=True)

if __name__=='__main__':main()
