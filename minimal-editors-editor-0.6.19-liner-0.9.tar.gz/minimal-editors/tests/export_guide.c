/* Developer-only export from the actual command registry.
 * cc -std=c99 -O2 tests/export_guide.c -o export-guide
 * ./export-guide > docs/commands.txt
 */
#define main editor_program_entry
#include "../editor.c"
#undef main
int main(void)
{
    size_t i;
    command_overview("", false);
    if (fputs(command_page, stdout) == EOF) return 1;
    for (i = 0; i < COMMAND_INFO_COUNT; i++) {
        if (fputs("\n\n----------------------------------------\n\n", stdout) == EOF) return 1;
        command_details(&command_info[i], NULL, false);
        if (fputs(command_page, stdout) == EOF) return 1;
    }
    return fflush(stdout) == EOF ? 1 : 0;
}
