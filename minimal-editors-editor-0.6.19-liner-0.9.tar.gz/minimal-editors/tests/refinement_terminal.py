#!/usr/bin/env python3
"""0.6.7 end-to-end literal input and filename failure-recovery regressions."""
from pathlib import Path
import sys
import tempfile
from terminal import Session


def scenarios(binary, root):
    checks = 0

    def run(name, fn):
        nonlocal checks
        home = root / name
        home.mkdir()
        doc = home / 'sample.conf'
        doc.write_bytes(b'first beta\nsecond  beta\nlast beta \n')
        session = Session(binary, home, [doc])
        try:
            fn(session, home, doc)
            session.finish()
        except BaseException:
            print('FAIL', name, repr(bytes(session.data[-1800:])), flush=True)
            session.kill()
            raise
        checks += 1
        print('PASS', name, flush=True)

    def save(s, doc, expected):
        mark = len(s.data)
        s.command('write')
        s.wait_output(b'Written.', timeout=5, start=mark)
        s.wait_file(doc, expected)

    def find_spaces(s, home, doc):
        initial = doc.read_bytes()
        s.command('find'); s.wait_output(b'Find>')
        s.send(b'  beta\rX')
        expected = initial[:17] + b'X' + initial[17:]
        save(s, doc, expected)
        s.command('undo'); save(s, doc, initial)
        s.command('find'); s.send(b'beta \rY')
        save(s, doc, initial[:29] + b'Y' + initial[29:])
        s.command('undo'); save(s, doc, initial)
        s.command('find'); s.send(b'  \r')
        s.command('next'); s.command('prev'); s.send(b'Z')
        save(s, doc, initial[:17] + b'Z' + initial[17:])
    run('literal-find-leading-trailing-and-only-spaces', find_spaces)

    def names(s, home, doc):
        folder = home / 'folder with spaces'
        folder.mkdir()
        for suffix in ('\u00e9', '\u00ea'):
            (folder / ('caf'+suffix)).write_bytes(suffix.encode()+b'\n')
        s.send(b'\x1bread fold\t'); s.wait_output(b'DIRECTORY:')
        s.send(b'qcaf\t'); s.wait_output('caf\u00ea'.encode())
        s.send('q\u00e9\r'.encode()); s.send(b'*')
        save(s, folder/'caf\u00e9', b'*'+ '\u00e9\n'.encode())
        assert doc.read_bytes()==b'first beta\nsecond  beta\nlast beta \n'
        assert (folder/'caf\u00ea').read_bytes()=='\u00ea\n'.encode()
    run('unicode-prefix-and-space-containing-directory-completion', names)

    def bad_completion(s, home, doc):
        (home/'target.conf').write_bytes(b'target\n')
        s.send(b'\x1bread nope\t')
        s.wait_output(b'No matching filename')
        s.send(b'q'+b'\x7f'*4+b'targ\t\r')
        s.send(b'X'); save(s, home/'target.conf', b'Xtarget\n')
        assert doc.read_bytes()==b'first beta\nsecond  beta\nlast beta \n'
        s.command('read'); s.wait_output(b'Filename>')
        s.send(b'absent-directory/nope\t'); s.wait_output(b'Cannot complete path')
        s.send(b'q'+b'\x7f'*len('absent-directory/nope')+b'samp\t\r')
        s.send(b'Y'); save(s, doc, b'Yfirst beta\nsecond  beta\nlast beta \n')
        assert not (home/'absent-directory').exists()
    run('visible-completion-error-preserves-command-and-filename-prompts', bad_completion)

    def full_draft(s, home, doc):
        (home/'folderlong').mkdir()
        draft = b'write' + b' '*(4094-7) + b'fo'
        assert len(draft)==4094
        s.send(b'\x1b'+draft+b'\t', settle=.2)
        s.wait_output(b'Completion is too long', timeout=5)
        s.send(b'q\x7f\x7fok\r', settle=.15)
        s.wait_file(home/'ok', doc.read_bytes())
        assert not (home/'fo').exists()
        assert not (home/'folderlong/sample.conf').exists()
    run('near-capacity-completion-keeps-draft-atomic', full_draft)

    def command_paste(s, home, doc):
        initial = doc.read_bytes()
        s.send(b'\x1bfind \x1b[200~'+b'x'*100000+b'\nquit!\r\x1b[201~', settle=.1)
        s.wait_output(b'Paste exceeds command space', timeout=5)
        assert not s.exited()
        s.send(b'qbeta\rX')
        save(s, doc, initial[:6]+b'X'+initial[6:])
        s.command('find')
        s.send(b'\x1b[200~one\ntwo\x1b[201~')
        s.wait_output(b'Paste one command line at a time')
        s.send(b'q  beta\rY')
        save(s, doc, b'first Xbeta\nsecondY  beta\nlast beta \n')
    run('oversized-and-multiline-command-paste-notices-recover', command_paste)

    def too_big(s, home, doc):
        with (home/'oversized').open('wb') as stream:
            stream.truncate(8*1024*1024+1)
        s.command('read oversized'); s.send(b'X')
        save(s, doc, b'Xfirst beta\nsecond  beta\nlast beta \n')
        assert (home/'oversized').stat().st_size==8*1024*1024+1
        for _ in range(5):
            s.send(b'\x1bwrite missing/place\t'); s.wait_output(b'Cannot complete path')
            s.send(b'q\x1b')
        s.send(b'Y'); save(s, doc, b'XYfirst beta\nsecond  beta\nlast beta \n')
    run('failed-file-reads-and-repeated-path-errors-retain-document', too_big)

    def clipboard(s, home, doc):
        initial = doc.read_bytes()
        s.send(b'X'); s.command('clipboard')
        s.send(b'  clip\nsecond\n')
        s.command('find'); s.send(b'  clip\rY')
        s.send(b'\x1bwrite absent/path\t'); s.wait_output(b'Cannot complete path')
        for rows,cols in ((3,12),(1,1),(5,20),(24,80)):
            s.resize(rows,cols); s.send(b'jkhhl')
        s.send(b'q\x1b'); s.command('clipboard')
        clip = home/'state/editor/clipboard.txt'
        s.wait_file(clip, b'Y  clip\nsecond\n')
        save(s, doc, b'X'+initial)
        s.command('undo'); save(s, doc, initial)
        assert clip.read_bytes()==b'Y  clip\nsecond\n'
    run('clipboard-parent-and-small-screen-error-viewer', clipboard)

    print(f'PASS: {checks} refinement PTY groups', flush=True)


if __name__=='__main__':
    with tempfile.TemporaryDirectory(prefix='editor-refinement-') as temp:
        scenarios(Path(sys.argv[1]).resolve(), Path(temp))
