#!/usr/bin/env python3
"""Alias and script failure regressions in isolated real terminal sessions."""
from pathlib import Path
import sys
import tempfile
import time
from terminal import Session


def check(binary, root):
    count = 0

    def run(name, fn, initial=b'first\nsecond\n', named=True):
        nonlocal count
        home = root / name
        home.mkdir()
        doc = home / 'doc.txt'
        if named:
            doc.write_bytes(initial)
        s = Session(binary, home, [doc] if named else [])
        try:
            fn(s, home, doc)
            s.finish()
        except BaseException:
            print('FAIL', name, bytes(s.data[-1800:]), flush=True)
            s.kill()
            raise
        count += 1
        print('PASS', name, flush=True)

    def expect_exit(s):
        until = time.monotonic() + 3
        while not s.exited() and time.monotonic() < until:
            s.drain(.025)
        assert s.exited(), bytes(s.data[-1000:])

    def force_alias(s, home, doc):
        s.command('define q1 quit!')
        s.wait_file(home / 'config/editor/commands.conf', b'q1\tquit!\n')
        s.send(b'UNSAVED')
        s.command('q1')
        expect_exit(s)
        assert doc.read_bytes() == b'first\nsecond\n'
    run('q1-force-quit-alias-keeps-disk-file', force_alias)

    def saved_alias(s, home, doc):
        s.command('q1')
        expect_exit(s)
    home = root / 'q1-force-quit-alias-keeps-disk-file'
    s = Session(binary, home, [home / 'doc.txt'])
    try:
        saved_alias(s, home, home / 'doc.txt')
        s.finish()
    except BaseException:
        s.kill()
        raise
    count += 1
    print('PASS q1-alias-restores-after-restart', flush=True)

    def safe_quit(s, home, doc):
        s.command('define endedit quit')
        s.send(b'X')
        s.command('endedit')
        s.wait_output(b'Unsaved work')
        assert not s.exited()
        s.command('write')
        s.wait_file(doc, b'Xfirst\nsecond\n')
        s.command('endedit')
        expect_exit(s)
    run('ordinary-quit-alias-retains-unsaved-check', safe_quit)

    def prompt_alias(s, home, doc):
        s.command('define store write')
        s.send(b'config=value\r')
        s.command('store')
        s.wait_output(b'Filename>')
        s.send(b'doc.txt\r')
        s.wait_file(doc, b'config=value\n')
        s.command('define look find')
        s.command('look')
        s.wait_output(b'Find>')
        s.send(b'value\r')
        s.wait_output(b'Match at')
    run('aliases-retain-write-and-find-prompts', prompt_alias, named=False)

    def nested_and_hotkey(s, home, doc):
        s.command('define bottommost bottom')
        s.command('define hop bottommost')
        s.command('bind F2 hop')
        s.send(b'\x1b[12~X')
        s.command('write')
        s.wait_file(doc, b'first\nsecond\nX')
        s.command('define q1 quit!')
        s.command('define endedit q1')
        s.command('endedit')
        expect_exit(s)
    run('nested-aliases-and-user-key-bindings', nested_and_hotkey)

    def restricted_script(s, home, doc):
        script = home / 'steps.editor'
        script.write_text('shell printf A\nendedit\nshell printf BAD\n')
        s.command('define q1 quit!')
        s.command('define endedit q1')
        s.command('run steps.editor')
        s.wait_output(b'Script line 2 stopped')
        s.wait_output(b'Not permitted in scripts: quit!')
        assert not s.exited()
        s.command('write')
        s.wait_file(doc, b'Afirst\nsecond\n')
        s.command('undo')
        s.command('write')
        s.wait_file(doc, b'first\nsecond\n')
    run('scripts-cannot-quit-through-nested-alias', restricted_script)

    def failed_find(s, home, doc):
        (home / 'steps.editor').write_text('find missing text\nshell printf BAD\n')
        s.command('run steps.editor')
        s.wait_output(b'Script line 1 stopped')
        s.wait_output(b'No match')
        s.command('write')
        s.wait_file(doc, b'first\nsecond\n')
    run('failed-script-find-stops-following-edit', failed_find)

    def cycles(s, home, doc):
        s.command('define cyclea cycleb')
        s.command('define cycleb cyclea')
        s.command('cyclea')
        s.wait_output(b'recursion limit')
        s.command('write')
        s.wait_file(doc, b'first\nsecond\n')
    run('interactive-alias-cycle-stops-with-editor-usable', cycles)

    print('PASS:', count, 'command stability terminal groups', flush=True)


if __name__ == '__main__':
    executable = str(Path(sys.argv[1]).resolve(strict=True))
    with tempfile.TemporaryDirectory(prefix='editor-command-pty-') as directory:
        check(executable, Path(directory))
