#!/usr/bin/env python3
"""Human command-entry workflows through a real PTY. Development use only."""
import sys
import tempfile
from pathlib import Path
from terminal import Session


def check(binary, root):
    count = 0
    def run(name, fn):
        nonlocal count
        home = root / name
        home.mkdir()
        sample = home / 'sample.conf'
        sample.write_bytes(b'alpha\nbeta\ngamma\n')
        s = Session(binary, home, [sample])
        try:
            fn(s, home, sample)
            s.finish()
        except Exception:
            print('FAIL', name, repr(bytes(s.data[-1600:])), flush=True)
            s.kill()
            raise
        count += 1
        print('PASS', name, flush=True)

    def workflow(s, home, sample):
        s.command('help'); s.wait_output(b'HELP - start here')
        s.send(b'q')  # Help goes straight back to the command prompt.
        s.send(b'list clipboard\r'); s.wait_output(b'Copy, cut and clipboards')
        s.send(b'qhelp cut\r'); s.wait_output(b'Cut document line 2')
        s.send(b'qcut 2\r'); s.command('write')
        s.wait_file(sample, b'alpha\ngamma\n')
        s.command('undo'); s.command('write')
        s.wait_file(sample, b'alpha\nbeta\ngamma\n')
    run('guide-to-real-command', workflow)

    def typo(s, home, sample):
        s.command('wrte copy with spaces.txt'); s.wait_output(b'Command not found')
        assert not (home/'copy with spaces.txt').exists()
        # Correct only the verb; the filename and spaces have not been lost.
        s.send(b'q\x1b[H\x1b[C\x1b[Ci\r')
        s.wait_file(home/'copy with spaces.txt', sample.read_bytes())
        s.command('goto 0'); s.wait_output(b'Check this command')
        s.send(b'q\x1b[F\x7f2\r')
        s.send(b'X'); s.command('write')
        s.wait_file(home/'copy with spaces.txt', b'alpha\nXbeta\ngamma\n')
        s.wait_file(sample, b'alpha\nbeta\ngamma\n')
    run('correct-command-without-retyping-path', typo)

    def completion(s, home, sample):
        s.send(b'\x1b\t'); s.wait_output(b'COMMANDS BY TASK')
        s.send(b'qhe\t\r'); s.wait_output(b'HELP - start here')
        s.send(b'qre\t'); s.wait_output(b'More than one command matches.')
        s.wait_output(b'Open another file'); s.wait_output(b'Reapply changes')
        s.send(b'qad sample.conf\r')  # re + ad; choosing, not automatic execution.
        s.command('help save'); s.wait_output(b'write notes.txt')
        s.send(b'q\r'); s.command('write')
        s.wait_file(sample, b'alpha\nbeta\ngamma\n')
    run('tab-matches-have-meaning', completion)

    def prompts(s, home, sample):
        s.command('goto'); s.wait_output(b'Line [column]>')
        s.send(b'2 2\rX'); s.command('write')
        s.wait_file(sample, b'alpha\nbXeta\ngamma\n')
        s.command('clipuse'); s.wait_output(b'History number>')
        s.send(b'\x1b'); s.command('write')
        s.wait_file(sample, b'alpha\nbXeta\ngamma\n')
        s.command('replace'); s.send(b'alpha\rquit!\r'); assert not s.exited()
        s.command('write'); s.wait_file(sample,b'quit!\nbXeta\ngamma\n')
        s.command('undo'); s.command('write')
    run('guided-arguments-and-literal-replacement', prompts)

    def small(s, home, sample):
        for r, c in [(3,12), (5,20), (24,80), (1,1), (3,12)]:
            s.resize(r,c)
            s.command('list'); s.send(b'j'*30+b'\x1b[Fhhq\r')
            s.command('help cut'); s.send(b'j'*30+b'\x1b[Fhhq\r')
        s.resize(24,80)
        s.command('help'); s.send(b'q\x1b'); s.wait_output(b'Really quit?')
        s.send(b'n'); s.command('write')
        s.wait_file(sample,b'alpha\nbeta\ngamma\n')
    run('narrow-screens-and-quit-confirmation', small)

    def clipboard(s, home, sample):
        s.send(b'*'); s.command('clipboard'); s.send(b'clip text')
        s.command('help copy'); s.send(b'qclipboard\r')
        s.command('write'); s.wait_file(sample,b'*alpha\nbeta\ngamma\n')
        s.wait_file(home/'state/editor/clipboard.txt',b'clip text')
        s.command('help'); s.send(b'\x1b[200~quit!\rwrite bad\r\x1b[201~')
        s.send(b'q\r'); assert not s.exited() and not (home/'bad').exists()
    run('clipboard-context-and-protected-guide-paste', clipboard)

    def menu(s, home, sample):
        s.command('toggle-esc');s.send(b'\x1b'); s.send(b'7\r2\r')
        s.wait_output(b'COMMANDS BY TASK'); s.send(b'qgoto\r2\rX')
        # Escape still opens the menu, not a changed preference.
        mark = len(s.data)
        s.send(b'\x1b8\rwrite\r')
        s.wait_output(b'Written.', timeout=5, start=mark)
        s.wait_file(sample, b'alpha\nXbeta\ngamma\n')
        s.send(b'\x1b8\rtoggle-esc\r')  # Finish helper expects Command> on Esc.
    run('menu-guide-resumes-cli-without-changing-preference', menu)

    def bounds(s, home, sample):
        s.send(b'\x1b'+b'z'*4095+b'\r',settle=.2)
        s.wait_output(b'Command not found'); assert not s.exited()
        s.send(b'q\x1b')  # Nonempty prompt cancels; no text is inserted.
        for _ in range(25):
            s.command('list no-such-thing'); s.send(b'q\r')
        s.command('write'); s.wait_file(sample,b'alpha\nbeta\ngamma\n')
    run('long-command-and-repeated-no-match-recovery', bounds)

    home=root/'pipe'; home.mkdir()
    s=Session(binary,home,stdin_data=b'pipe\r\nbytes',stdout_pipe=True)
    try:
        s.command('help'); s.send(b'q\r'); s.command('list save'); s.send(b'q\r')
        mark=len(s.data)
        s.command('write -');s.wait_output(b'Text sent to stdout (',start=mark)
        import os
        assert os.read(s.pipe_out,4096)==b'pipe\r\nbytes'
        s.finish()
    except Exception:
        s.kill(); raise
    count+=1; print('PASS guide-output-does-not-enter-pipeline',flush=True)
    print(f'PASS: {count} command usability PTY groups',flush=True)

if __name__=='__main__':
    with tempfile.TemporaryDirectory(prefix='editor-cli-') as tmp:
        check(Path(sys.argv[1]).resolve(),Path(tmp))
