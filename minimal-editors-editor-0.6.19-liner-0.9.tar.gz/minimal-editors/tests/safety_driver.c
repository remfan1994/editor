/* Test-only executable: inject one creation failure or one real signal just
 * after fsync succeeds. These hooks are absent from the production editor. */
#define _XOPEN_SOURCE 700
#if defined(__OpenBSD__)
#define _BSD_SOURCE 1
#endif
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static int staged_test_sync(int);
static int staged_test_temp(char *);
#define fsync staged_test_sync
#define mkstemp staged_test_temp
#ifndef EDITOR_SOURCE
#define EDITOR_SOURCE "../editor.c"
#endif
#include EDITOR_SOURCE
#undef fsync
#undef mkstemp
static int staged_test_sync(int fd)
{
    int result=fsync(fd);
    const char *fault=getenv("EDITOR_TEST_FAULT");
    if(result==0 && fault && !strcmp(fault,"sync-int")) {
        (void)unsetenv("EDITOR_TEST_FAULT");
        (void)raise(SIGINT);
    }
    return result;
}
static int staged_test_temp(char *path)
{
    const char *fault=getenv("EDITOR_TEST_FAULT");
    if(fault && !strcmp(fault,"temp-collision")) {
        size_t n=strlen(path);
        int fd;
        (void)unsetenv("EDITOR_TEST_FAULT");
        if(n<6) {errno=EINVAL;return -1;}
        memcpy(path+n-6,"INUSE1",6);
        fd=open(path,O_WRONLY|O_CREAT|O_EXCL,0600);
        if(fd>=0) {(void)write(fd,"KEEP\n",5);(void)close(fd);}
        errno=EEXIST;return -1;
    }
    return mkstemp(path);
}
